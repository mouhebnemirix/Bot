# Source Log

This file will be updated with all the sources used in the research.

[1] Jupiter API Documentation: https://dev.jup.ag/docs/api

[2] Raydium API Documentation: https://docs.raydium.io/raydium/protocol/developers/api

[3] Orca DEX API by Bitquery: https://docs.bitquery.io/docs/examples/Solana/solana-orca-dex-api/

[4] Santiment: https://app.santiment.net/social-trends

[5] LunarCrush: https://lunarcrush.com/

[6] StockGeist.ai: https://www.stockgeist.ai/crypto-sentiment-analysis/
