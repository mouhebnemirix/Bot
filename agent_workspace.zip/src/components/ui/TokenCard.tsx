import React from 'react';
import { cn } from '@/lib/utils';
import { ArrowUpIcon, ArrowDownIcon } from '@heroicons/react/24/outline';

interface TokenCardProps {
  token: {
    mint_address: string;
    symbol?: string;
    name?: string;
    price_usd?: number;
    price_change_24h?: number;
    volume_24h?: number;
    market_cap?: number;
  };
  onClick?: () => void;
}

function TokenCard({ token, onClick }: TokenCardProps) {
  const isPositive = (token.price_change_24h || 0) >= 0;

  return (
    <div 
      className={cn(
        "p-3 bg-gray-700 rounded-lg transition-all duration-200",
        onClick && "cursor-pointer hover:bg-gray-600"
      )}
      onClick={onClick}
    >
      <div className="flex items-center justify-between">
        <div className="flex-1">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-gradient-to-r from-cyan-400 to-blue-500 rounded-full flex items-center justify-center">
              <span className="text-white font-bold text-xs">
                {token.symbol?.charAt(0) || 'T'}
              </span>
            </div>
            <div>
              <div className="font-medium text-white text-sm">
                {token.symbol || 'UNKNOWN'}
              </div>
              <div className="text-xs text-gray-400 truncate max-w-24">
                {token.name || 'Unknown Token'}
              </div>
            </div>
          </div>
        </div>
        
        <div className="text-right">
          <div className="font-medium text-white text-sm">
            ${token.price_usd?.toFixed(6) || '0.000000'}
          </div>
          <div className={cn(
            "flex items-center text-xs",
            isPositive ? "text-green-400" : "text-red-400"
          )}>
            {isPositive ? (
              <ArrowUpIcon className="w-3 h-3 mr-1" />
            ) : (
              <ArrowDownIcon className="w-3 h-3 mr-1" />
            )}
            {Math.abs(token.price_change_24h || 0).toFixed(1)}%
          </div>
        </div>
      </div>
      
      {(token.volume_24h || token.market_cap) && (
        <div className="mt-2 pt-2 border-t border-gray-600">
          <div className="flex justify-between text-xs text-gray-400">
            {token.volume_24h && (
              <span>Vol: ${(token.volume_24h / 1000).toFixed(1)}K</span>
            )}
            {token.market_cap && (
              <span>MC: ${(token.market_cap / 1000).toFixed(1)}K</span>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

export default TokenCard;