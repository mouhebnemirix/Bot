import React from 'react';
import { cn } from '@/lib/utils';
import { ArrowUpIcon, ArrowDownIcon } from '@heroicons/react/24/outline';

interface TradeCardProps {
  trade: {
    id: number;
    trade_type: string;
    token_symbol?: string;
    amount: number;
    price: number;
    value_usd: number;
    created_at: string;
    confidence_score?: number;
    sentiment_score?: number;
  };
}

function TradeCard({ trade }: TradeCardProps) {
  const isBuy = trade.trade_type.toLowerCase() === 'buy';
  const tradeTime = new Date(trade.created_at).toLocaleTimeString('en-US', {
    hour: '2-digit',
    minute: '2-digit',
  });

  return (
    <div className="p-3 bg-gray-700 rounded-lg">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <div className={cn(
            "p-1 rounded-full",
            isBuy ? "bg-green-500/20" : "bg-red-500/20"
          )}>
            {isBuy ? (
              <ArrowUpIcon className="w-3 h-3 text-green-400" />
            ) : (
              <ArrowDownIcon className="w-3 h-3 text-red-400" />
            )}
          </div>
          <div>
            <div className="flex items-center space-x-1">
              <span className={cn(
                "text-sm font-medium",
                isBuy ? "text-green-400" : "text-red-400"
              )}>
                {trade.trade_type.toUpperCase()}
              </span>
              <span className="text-sm text-white">
                {trade.token_symbol || 'UNKNOWN'}
              </span>
            </div>
            <div className="text-xs text-gray-400">
              {trade.amount.toFixed(4)} @ ${trade.price.toFixed(6)}
            </div>
          </div>
        </div>
        
        <div className="text-right">
          <div className="text-sm font-medium text-white">
            ${trade.value_usd.toFixed(2)}
          </div>
          <div className="text-xs text-gray-400">
            {tradeTime}
          </div>
        </div>
      </div>
      
      {(trade.confidence_score || trade.sentiment_score) && (
        <div className="mt-2 pt-2 border-t border-gray-600">
          <div className="flex justify-between text-xs">
            {trade.confidence_score && (
              <span className="text-blue-400">
                Confidence: {(trade.confidence_score * 100).toFixed(0)}%
              </span>
            )}
            {trade.sentiment_score && (
              <span className="text-purple-400">
                Sentiment: {(trade.sentiment_score * 100).toFixed(0)}%
              </span>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

export default TradeCard;