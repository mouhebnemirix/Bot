import React from 'react';
import {
  Bars3Icon,
  BellIcon,
  WifiIcon,
} from '@heroicons/react/24/outline';
import { useWebSocket } from '@/hooks/useWebSocket';
import { useSystemStatus } from '@/hooks/useApi';
import { cn } from '@/lib/utils';

interface HeaderProps {
  sidebarOpen: boolean;
  setSidebarOpen: (open: boolean) => void;
}

function Header({ sidebarOpen, setSidebarOpen }: HeaderProps) {
  const { isConnected } = useWebSocket();
  const { data: systemStatus } = useSystemStatus();

  return (
    <header className="bg-gray-800 border-b border-gray-700 px-6 py-4">
      <div className="flex items-center justify-between">
        {/* Left section */}
        <div className="flex items-center space-x-4">
          <button
            className="lg:hidden text-gray-400 hover:text-white focus:outline-none focus:text-white"
            onClick={() => setSidebarOpen(!sidebarOpen)}
          >
            <Bars3Icon className="w-6 h-6" />
          </button>
          
          <div>
            <h1 className="text-xl font-semibold text-white">Trading Dashboard</h1>
            <p className="text-sm text-gray-400">High-Performance Solana Meme Coin Bot</p>
          </div>
        </div>

        {/* Right section */}
        <div className="flex items-center space-x-4">
          {/* Connection status */}
          <div className="flex items-center space-x-2">
            <WifiIcon 
              className={cn(
                'w-5 h-5',
                isConnected ? 'text-green-400' : 'text-red-400'
              )} 
            />
            <span className={cn(
              'text-sm font-medium',
              isConnected ? 'text-green-400' : 'text-red-400'
            )}>
              {isConnected ? 'Connected' : 'Disconnected'}
            </span>
          </div>

          {/* System status */}
          {systemStatus && (
            <div className="flex items-center space-x-2">
              <div className={cn(
                'w-2 h-2 rounded-full',
                systemStatus.status === 'operational' ? 'bg-green-400' : 'bg-red-400'
              )} />
              <span className="text-sm text-gray-300">
                {systemStatus.status === 'operational' ? 'System Online' : 'System Issues'}
              </span>
            </div>
          )}

          {/* Notifications */}
          <button className="relative p-2 text-gray-400 hover:text-white focus:outline-none focus:text-white">
            <BellIcon className="w-6 h-6" />
            <span className="absolute top-0 right-0 block h-2 w-2 rounded-full bg-cyan-400 ring-2 ring-gray-800" />
          </button>

          {/* User avatar */}
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-gradient-to-r from-cyan-400 to-blue-500 rounded-full flex items-center justify-center">
              <span className="text-white font-medium text-sm">TB</span>
            </div>
            <div className="hidden md:block">
              <p className="text-sm font-medium text-white">Trading Bot</p>
              <p className="text-xs text-gray-400">Autonomous</p>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}

export default Header;