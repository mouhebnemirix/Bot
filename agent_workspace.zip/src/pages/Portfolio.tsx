import React, { useState } from 'react';
import {
  ChartBarIcon,
  CurrencyDollarIcon,
  TrendingUpIcon,
  TrendingDownIcon,
} from '@heroicons/react/24/outline';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from 'recharts';
import {
  usePortfolioOverview,
  useActivePositions,
  usePerformanceSummary,
  usePerformanceAnalytics,
} from '@/hooks/useApi';
import { cn } from '@/lib/utils';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import StatCard from '@/components/ui/StatCard';

function Portfolio() {
  const [selectedPeriod, setSelectedPeriod] = useState('7d');
  const { data: portfolio, isLoading: portfolioLoading } = usePortfolioOverview();
  const { data: positions, isLoading: positionsLoading } = useActivePositions();
  const { data: performance } = usePerformanceSummary(7);
  const { data: analytics } = usePerformanceAnalytics(selectedPeriod);

  // Mock data for charts
  const portfolioHistory = [
    { date: '2024-01-20', value: 1.0, pnl: 0 },
    { date: '2024-01-21', value: 1.2, pnl: 0.2 },
    { date: '2024-01-22', value: 1.1, pnl: 0.1 },
    { date: '2024-01-23', value: 1.8, pnl: 0.8 },
    { date: '2024-01-24', value: 2.1, pnl: 1.1 },
    { date: '2024-01-25', value: 1.9, pnl: 0.9 },
    { date: '2024-01-26', value: 2.4, pnl: 1.4 },
    { date: '2024-01-27', value: 2.7, pnl: 1.7 },
  ];

  const positionAllocation = positions?.slice(0, 5).map((position: any, index: number) => ({
    name: position.token_symbol || 'UNKNOWN',
    value: position.amount * position.current_price,
    color: ['#06b6d4', '#3b82f6', '#8b5cf6', '#10b981', '#f59e0b'][index % 5],
  })) || [];

  if (portfolioLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <LoadingSpinner size="lg" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-white">Portfolio</h1>
          <p className="text-gray-400 mt-1">Track your trading performance and positions</p>
        </div>
        <div className="flex space-x-2">
          {['1d', '7d', '30d'].map((period) => (
            <button
              key={period}
              onClick={() => setSelectedPeriod(period)}
              className={cn(
                'px-4 py-2 rounded-lg text-sm font-medium transition-colors',
                selectedPeriod === period
                  ? 'bg-cyan-600 text-white'
                  : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
              )}
            >
              {period}
            </button>
          ))}
        </div>
      </div>

      {/* Portfolio Summary */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard
          title="Total Value"
          value={`$${portfolio?.total_value?.toFixed(2) || '0.00'}`}
          change={portfolio?.daily_return || 0}
          icon={CurrencyDollarIcon}
          trend={portfolio?.daily_return >= 0 ? "up" : "down"}
          color="blue"
        />
        <StatCard
          title="Total P&L"
          value={`$${portfolio?.total_pnl?.toFixed(2) || '0.00'}`}
          change={portfolio?.total_pnl_percentage || 0}
          icon={portfolio?.total_pnl >= 0 ? TrendingUpIcon : TrendingDownIcon}
          trend={portfolio?.total_pnl >= 0 ? "up" : "down"}
          color={portfolio?.total_pnl >= 0 ? "green" : "red"}
        />
        <StatCard
          title="Win Rate"
          value={`${portfolio?.win_rate?.toFixed(1) || '0.0'}%`}
          change={0}
          icon={ChartBarIcon}
          trend="neutral"
          color="purple"
        />
        <StatCard
          title="Sharpe Ratio"
          value={portfolio?.sharpe_ratio?.toFixed(2) || '0.00'}
          change={0}
          icon={TrendingUpIcon}
          trend="neutral"
          color="yellow"
        />
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Portfolio Performance Chart */}
        <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
          <h3 className="text-lg font-semibold text-white mb-4">Portfolio Performance</h3>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={portfolioHistory}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis 
                  dataKey="date" 
                  stroke="#9ca3af" 
                  fontSize={12}
                  tickFormatter={(value) => new Date(value).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                />
                <YAxis 
                  stroke="#9ca3af" 
                  fontSize={12}
                  tickFormatter={(value) => `$${value}`}
                />
                <Tooltip 
                  contentStyle={{
                    backgroundColor: '#1f2937',
                    border: '1px solid #374151',
                    borderRadius: '8px',
                    color: '#f9fafb'
                  }}
                  formatter={(value, name) => [`$${value}`, 'Portfolio Value']}
                  labelFormatter={(value) => new Date(value).toLocaleDateString()}
                />
                <Line
                  type="monotone"
                  dataKey="value"
                  stroke="#06b6d4"
                  strokeWidth={3}
                  dot={{ fill: '#06b6d4', strokeWidth: 2, r: 4 }}
                  activeDot={{ r: 6, stroke: '#06b6d4', strokeWidth: 2 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Position Allocation */}
        <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
          <h3 className="text-lg font-semibold text-white mb-4">Position Allocation</h3>
          {positionAllocation.length > 0 ? (
            <div className="h-80 flex items-center">
              <div className="w-1/2">
                <ResponsiveContainer width="100%" height={200}>
                  <PieChart>
                    <Pie
                      data={positionAllocation}
                      cx="50%"
                      cy="50%"
                      innerRadius={40}
                      outerRadius={80}
                      paddingAngle={5}
                      dataKey="value"
                    >
                      {positionAllocation.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip 
                      contentStyle={{
                        backgroundColor: '#1f2937',
                        border: '1px solid #374151',
                        borderRadius: '8px',
                        color: '#f9fafb'
                      }}
                      formatter={(value) => [`$${Number(value).toFixed(2)}`, 'Value']}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="w-1/2 space-y-2">
                {positionAllocation.map((item, index) => (
                  <div key={index} className="flex items-center space-x-2">
                    <div 
                      className="w-3 h-3 rounded-full"
                      style={{ backgroundColor: item.color }}
                    />
                    <span className="text-sm text-gray-300">{item.name}</span>
                    <span className="text-sm text-gray-400 ml-auto">
                      ${item.value.toFixed(2)}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="h-80 flex items-center justify-center text-gray-400">
              No active positions
            </div>
          )}
        </div>
      </div>

      {/* Active Positions Table */}
      <div className="bg-gray-800 rounded-xl border border-gray-700">
        <div className="p-6 border-b border-gray-700">
          <h3 className="text-lg font-semibold text-white">Active Positions</h3>
        </div>
        <div className="overflow-x-auto">
          {positionsLoading ? (
            <div className="flex justify-center py-12">
              <LoadingSpinner size="lg" />
            </div>
          ) : positions?.length > 0 ? (
            <table className="w-full">
              <thead className="bg-gray-700">
                <tr className="text-left">
                  <th className="px-6 py-3 text-xs font-medium text-gray-300 uppercase tracking-wider">
                    Token
                  </th>
                  <th className="px-6 py-3 text-xs font-medium text-gray-300 uppercase tracking-wider">
                    Amount
                  </th>
                  <th className="px-6 py-3 text-xs font-medium text-gray-300 uppercase tracking-wider">
                    Entry Price
                  </th>
                  <th className="px-6 py-3 text-xs font-medium text-gray-300 uppercase tracking-wider">
                    Current Price
                  </th>
                  <th className="px-6 py-3 text-xs font-medium text-gray-300 uppercase tracking-wider">
                    P&L
                  </th>
                  <th className="px-6 py-3 text-xs font-medium text-gray-300 uppercase tracking-wider">
                    %
                  </th>
                  <th className="px-6 py-3 text-xs font-medium text-gray-300 uppercase tracking-wider">
                    Value
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-700">
                {positions.map((position: any) => {
                  const unrealizedPnl = (position.current_price - position.entry_price) * position.amount;
                  const pnlPercentage = ((position.current_price - position.entry_price) / position.entry_price) * 100;
                  const currentValue = position.current_price * position.amount;
                  
                  return (
                    <tr key={position.id} className="hover:bg-gray-700/50">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <div className="w-8 h-8 bg-gradient-to-r from-cyan-400 to-blue-500 rounded-full flex items-center justify-center mr-3">
                            <span className="text-white font-bold text-xs">
                              {position.token_symbol?.charAt(0) || 'T'}
                            </span>
                          </div>
                          <div>
                            <div className="text-sm font-medium text-white">
                              {position.token_symbol || 'UNKNOWN'}
                            </div>
                            <div className="text-xs text-gray-400">
                              {position.token_name || 'Unknown Token'}
                            </div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-white">
                        {position.amount?.toFixed(4) || '0.0000'}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-white">
                        ${position.entry_price?.toFixed(6) || '0.000000'}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-white">
                        ${position.current_price?.toFixed(6) || '0.000000'}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm">
                        <span className={cn(
                          "font-medium",
                          unrealizedPnl >= 0 ? "text-green-400" : "text-red-400"
                        )}>
                          {unrealizedPnl >= 0 ? '+' : ''}${unrealizedPnl.toFixed(2)}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm">
                        <span className={cn(
                          "font-medium",
                          pnlPercentage >= 0 ? "text-green-400" : "text-red-400"
                        )}>
                          {pnlPercentage >= 0 ? '+' : ''}{pnlPercentage.toFixed(2)}%
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-white">
                        ${currentValue.toFixed(2)}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          ) : (
            <div className="text-center py-12 text-gray-400">
              <ChartBarIcon className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p>No active positions</p>
              <p className="text-sm mt-1">Positions will appear here when the bot starts trading</p>
            </div>
          )}
        </div>
      </div>

      {/* Performance Metrics */}
      {performance && (
        <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
          <h3 className="text-lg font-semibold text-white mb-4">Performance Summary (7 days)</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="text-center">
              <div className="text-2xl font-bold text-cyan-400">
                {performance.total_trades || 0}
              </div>
              <div className="text-sm text-gray-400">Total Trades</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-400">
                ${performance.total_volume?.toFixed(2) || '0.00'}
              </div>
              <div className="text-sm text-gray-400">Total Volume</div>
            </div>
            <div className="text-center">
              <div className={cn(
                "text-2xl font-bold",
                performance.total_pnl >= 0 ? "text-green-400" : "text-red-400"
              )}>
                ${performance.total_pnl?.toFixed(2) || '0.00'}
              </div>
              <div className="text-sm text-gray-400">Total P&L</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-400">
                {performance.win_rate?.toFixed(1) || '0.0'}%
              </div>
              <div className="text-sm text-gray-400">Win Rate</div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default Portfolio;