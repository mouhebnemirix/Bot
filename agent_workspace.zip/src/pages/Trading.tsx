import React, { useState } from 'react';
import {
  BoltIcon,
  ExclamationTriangleIcon,
  CheckCircleIcon,
  XCircleIcon,
} from '@heroicons/react/24/outline';
import {
  useTradingSignals,
  useRecentTrades,
  useRiskReport,
  useSystemStatus,
} from '@/hooks/useApi';
import { cn, formatTimeAgo } from '@/lib/utils';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import TradeCard from '@/components/ui/TradeCard';

function Trading() {
  const [selectedSignal, setSelectedSignal] = useState<any>(null);
  const { data: signals, isLoading: signalsLoading } = useTradingSignals(20);
  const { data: trades, isLoading: tradesLoading } = useRecentTrades(50);
  const { data: riskReport } = useRiskReport();
  const { data: systemStatus } = useSystemStatus();

  const getSignalColor = (strength: number) => {
    if (strength >= 0.8) return 'text-green-400';
    if (strength >= 0.6) return 'text-yellow-400';
    return 'text-orange-400';
  };

  const getSignalBg = (strength: number) => {
    if (strength >= 0.8) return 'bg-green-500/10 border-green-500/20';
    if (strength >= 0.6) return 'bg-yellow-500/10 border-yellow-500/20';
    return 'bg-orange-500/10 border-orange-500/20';
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-white">Trading</h1>
          <p className="text-gray-400 mt-1">AI-powered trading signals and execution</p>
        </div>
        <div className="flex items-center space-x-4">
          {riskReport && (
            <div className={cn(
              "px-4 py-2 rounded-lg flex items-center space-x-2",
              riskReport.status?.can_trade 
                ? "bg-green-900 text-green-400" 
                : "bg-red-900 text-red-400"
            )}>
              {riskReport.status?.can_trade ? (
                <CheckCircleIcon className="w-5 h-5" />
              ) : (
                <XCircleIcon className="w-5 h-5" />
              )}
              <span className="font-medium">
                {riskReport.status?.can_trade ? 'Trading Active' : 'Trading Paused'}
              </span>
            </div>
          )}
        </div>
      </div>

      {/* Trading Status */}
      {systemStatus && (
        <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
          <h3 className="text-lg font-semibold text-white mb-4">System Status</h3>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="text-center">
              <div className={cn(
                "text-2xl font-bold",
                systemStatus.services?.trading_engine === 'running' ? "text-green-400" : "text-red-400"
              )}>
                {systemStatus.services?.trading_engine === 'running' ? 'ONLINE' : 'OFFLINE'}
              </div>
              <div className="text-sm text-gray-400">Trading Engine</div>
            </div>
            <div className="text-center">
              <div className={cn(
                "text-2xl font-bold",
                systemStatus.services?.sentiment_analyzer === 'running' ? "text-green-400" : "text-red-400"
              )}>
                {systemStatus.services?.sentiment_analyzer === 'running' ? 'ACTIVE' : 'INACTIVE'}
              </div>
              <div className="text-sm text-gray-400">Sentiment Analysis</div>
            </div>
            <div className="text-center">
              <div className={cn(
                "text-2xl font-bold",
                systemStatus.services?.solana_monitor === 'running' ? "text-green-400" : "text-red-400"
              )}>
                {systemStatus.services?.solana_monitor === 'running' ? 'MONITORING' : 'STOPPED'}
              </div>
              <div className="text-sm text-gray-400">Blockchain Monitor</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-400">
                {systemStatus.config?.price_update_interval || 0}s
              </div>
              <div className="text-sm text-gray-400">Update Interval</div>
            </div>
          </div>
        </div>
      )}

      {/* Main Content */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Trading Signals */}
        <div className="lg:col-span-2">
          <div className="bg-gray-800 rounded-xl border border-gray-700">
            <div className="p-6 border-b border-gray-700">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-white">AI Trading Signals</h3>
                <div className="flex items-center space-x-2">
                  <BoltIcon className="w-5 h-5 text-yellow-400" />
                  <span className="text-sm text-gray-400">Real-time</span>
                </div>
              </div>
            </div>
            <div className="p-6">
              {signalsLoading ? (
                <div className="flex justify-center py-12">
                  <LoadingSpinner size="lg" />
                </div>
              ) : signals?.length > 0 ? (
                <div className="space-y-4">
                  {signals.map((signal: any) => (
                    <div
                      key={signal.id}
                      className={cn(
                        "p-4 rounded-lg border cursor-pointer transition-all duration-200 hover:scale-[1.02]",
                        getSignalBg(signal.strength),
                        selectedSignal?.id === signal.id && "ring-2 ring-cyan-500"
                      )}
                      onClick={() => setSelectedSignal(signal)}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center space-x-2">
                          <div className="w-8 h-8 bg-gradient-to-r from-cyan-400 to-blue-500 rounded-full flex items-center justify-center">
                            <span className="text-white font-bold text-xs">
                              {signal.mint_address?.charAt(0) || 'T'}
                            </span>
                          </div>
                          <div>
                            <div className="font-medium text-white">
                              Token: {signal.mint_address?.slice(0, 8)}...
                            </div>
                            <div className="text-sm text-gray-400">
                              {formatTimeAgo(signal.created_at)}
                            </div>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className={cn(
                            "text-lg font-bold",
                            signal.action === 'buy' ? "text-green-400" : "text-red-400"
                          )}>
                            {signal.action.toUpperCase()}
                          </div>
                          <div className={cn(
                            "text-sm font-medium",
                            getSignalColor(signal.strength)
                          )}>
                            {(signal.strength * 100).toFixed(0)}% Strength
                          </div>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-3 gap-4 text-sm">
                        <div>
                          <div className="text-gray-400">Confidence</div>
                          <div className="text-white font-medium">
                            {(signal.confidence * 100).toFixed(0)}%
                          </div>
                        </div>
                        <div>
                          <div className="text-gray-400">Target Price</div>
                          <div className="text-white font-medium">
                            ${signal.price_target?.toFixed(6) || 'N/A'}
                          </div>
                        </div>
                        <div>
                          <div className="text-gray-400">Stop Loss</div>
                          <div className="text-white font-medium">
                            ${signal.stop_loss?.toFixed(6) || 'N/A'}
                          </div>
                        </div>
                      </div>
                      
                      {signal.reasoning && (
                        <div className="mt-3 pt-3 border-t border-gray-600">
                          <div className="text-sm text-gray-300">
                            {signal.reasoning}
                          </div>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12 text-gray-400">
                  <BoltIcon className="w-12 h-12 mx-auto mb-4 opacity-50" />
                  <p>No trading signals available</p>
                  <p className="text-sm mt-1">Signals will appear when market conditions are favorable</p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Signal Details */}
          {selectedSignal && (
            <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
              <h3 className="text-lg font-semibold text-white mb-4">Signal Details</h3>
              <div className="space-y-3">
                <div>
                  <div className="text-sm text-gray-400">Signal Type</div>
                  <div className="text-white font-medium">{selectedSignal.signal_type}</div>
                </div>
                <div>
                  <div className="text-sm text-gray-400">Holding Period</div>
                  <div className="text-white font-medium">{selectedSignal.holding_period}</div>
                </div>
                <div>
                  <div className="text-sm text-gray-400">Sentiment Weight</div>
                  <div className="text-white font-medium">
                    {(selectedSignal.sentiment_weight * 100).toFixed(0)}%
                  </div>
                </div>
                <div>
                  <div className="text-sm text-gray-400">Technical Weight</div>
                  <div className="text-white font-medium">
                    {(selectedSignal.technical_weight * 100).toFixed(0)}%
                  </div>
                </div>
                <div>
                  <div className="text-sm text-gray-400">Volume Weight</div>
                  <div className="text-white font-medium">
                    {(selectedSignal.volume_weight * 100).toFixed(0)}%
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Risk Management */}
          {riskReport && (
            <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
              <h3 className="text-lg font-semibold text-white mb-4">Risk Management</h3>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-gray-400">Daily Trades</span>
                  <span className="text-white font-medium">
                    {riskReport.risk_metrics?.daily_trades || 0} / {riskReport.limits?.max_daily_trades || 0}
                  </span>
                </div>
                <div className="w-full bg-gray-700 rounded-full h-2">
                  <div 
                    className="bg-cyan-500 h-2 rounded-full"
                    style={{ 
                      width: `${Math.min(100, (riskReport.risk_metrics?.daily_trades || 0) / (riskReport.limits?.max_daily_trades || 1) * 100)}%` 
                    }}
                  />
                </div>
                
                <div className="flex justify-between items-center">
                  <span className="text-gray-400">Open Positions</span>
                  <span className="text-white font-medium">
                    {riskReport.risk_metrics?.position_count || 0} / {riskReport.limits?.max_positions || 0}
                  </span>
                </div>
                <div className="w-full bg-gray-700 rounded-full h-2">
                  <div 
                    className="bg-green-500 h-2 rounded-full"
                    style={{ 
                      width: `${Math.min(100, (riskReport.risk_metrics?.position_count || 0) / (riskReport.limits?.max_positions || 1) * 100)}%` 
                    }}
                  />
                </div>
                
                <div className="flex justify-between items-center">
                  <span className="text-gray-400">Portfolio Heat</span>
                  <span className="text-white font-medium">
                    {((riskReport.risk_metrics?.portfolio_heat || 0) * 100).toFixed(1)}%
                  </span>
                </div>
                <div className="w-full bg-gray-700 rounded-full h-2">
                  <div 
                    className="bg-yellow-500 h-2 rounded-full"
                    style={{ 
                      width: `${Math.min(100, (riskReport.risk_metrics?.portfolio_heat || 0) * 100)}%` 
                    }}
                  />
                </div>
              </div>
            </div>
          )}

          {/* Recent Trades */}
          <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
            <h3 className="text-lg font-semibold text-white mb-4">Recent Trades</h3>
            <div className="space-y-3 max-h-96 overflow-y-auto">
              {tradesLoading ? (
                <div className="flex justify-center py-8">
                  <LoadingSpinner />
                </div>
              ) : trades?.length > 0 ? (
                trades.slice(0, 10).map((trade: any) => (
                  <TradeCard key={trade.id} trade={trade} />
                ))
              ) : (
                <div className="text-center py-8 text-gray-400">
                  <ExclamationTriangleIcon className="w-8 h-8 mx-auto mb-2 opacity-50" />
                  <p className="text-sm">No recent trades</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Trading;