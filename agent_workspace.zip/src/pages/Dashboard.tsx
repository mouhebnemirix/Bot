import React from 'react';
import {
  ChartBarIcon,
  CurrencyDollarIcon,
  TrendingUpIcon,
  ExclamationTriangleIcon,
} from '@heroicons/react/24/outline';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  AreaChart,
  Area,
  BarChart,
  Bar,
} from 'recharts';
import {
  usePortfolioOverview,
  useActivePositions,
  useRecentTrades,
  useTrendingTokens,
  useRiskReport,
  useSystemStatus,
} from '@/hooks/useApi';
import { cn } from '@/lib/utils';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import StatCard from '@/components/ui/StatCard';
import TokenCard from '@/components/ui/TokenCard';
import TradeCard from '@/components/ui/TradeCard';

function Dashboard() {
  const { data: portfolio, isLoading: portfolioLoading } = usePortfolioOverview();
  const { data: positions, isLoading: positionsLoading } = useActivePositions();
  const { data: trades, isLoading: tradesLoading } = useRecentTrades(5);
  const { data: trending, isLoading: trendingLoading } = useTrendingTokens(5);
  const { data: riskReport, isLoading: riskLoading } = useRiskReport();
  const { data: systemStatus } = useSystemStatus();

  // Mock data for charts
  const portfolioData = [
    { time: '00:00', value: 1.0, pnl: 0 },
    { time: '04:00', value: 1.2, pnl: 0.2 },
    { time: '08:00', value: 1.8, pnl: 0.8 },
    { time: '12:00', value: 2.1, pnl: 1.1 },
    { time: '16:00', value: 1.9, pnl: 0.9 },
    { time: '20:00', value: 2.4, pnl: 1.4 },
    { time: '24:00', value: 2.7, pnl: 1.7 },
  ];

  const tradingActivity = [
    { name: 'Buy', value: 15, color: '#10b981' },
    { name: 'Sell', value: 12, color: '#ef4444' },
  ];

  if (portfolioLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <LoadingSpinner size="lg" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-white">Dashboard</h1>
          <p className="text-gray-400 mt-1">Real-time trading performance and analytics</p>
        </div>
        <div className="flex items-center space-x-2">
          <div className="px-3 py-1 bg-green-900 text-green-400 rounded-full text-sm font-medium">
            • Live
          </div>
          <div className="px-3 py-1 bg-blue-900 text-blue-400 rounded-full text-sm font-medium">
            Auto Trading
          </div>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard
          title="Portfolio Value"
          value={`$${portfolio?.total_value?.toFixed(2) || '0.00'}`}
          change={portfolio?.daily_return || 0}
          icon={CurrencyDollarIcon}
          trend="up"
          color="green"
        />
        <StatCard
          title="Total P&L"
          value={`$${portfolio?.total_pnl?.toFixed(2) || '0.00'}`}
          change={portfolio?.total_pnl_percentage || 0}
          icon={TrendingUpIcon}
          trend={portfolio?.total_pnl >= 0 ? "up" : "down"}
          color={portfolio?.total_pnl >= 0 ? "green" : "red"}
        />
        <StatCard
          title="Win Rate"
          value={`${portfolio?.win_rate?.toFixed(1) || '0.0'}%`}
          change={0}
          icon={ChartBarIcon}
          trend="neutral"
          color="blue"
        />
        <StatCard
          title="Active Positions"
          value={positions?.length?.toString() || '0'}
          change={0}
          icon={ExclamationTriangleIcon}
          trend="neutral"
          color="purple"
        />
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Portfolio Performance Chart */}
        <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
          <h3 className="text-lg font-semibold text-white mb-4">Portfolio Performance</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={portfolioData}>
                <defs>
                  <linearGradient id="portfolioGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#06b6d4" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis 
                  dataKey="time" 
                  stroke="#9ca3af" 
                  fontSize={12}
                />
                <YAxis 
                  stroke="#9ca3af" 
                  fontSize={12}
                  tickFormatter={(value) => `$${value}`}
                />
                <Tooltip 
                  contentStyle={{
                    backgroundColor: '#1f2937',
                    border: '1px solid #374151',
                    borderRadius: '8px',
                    color: '#f9fafb'
                  }}
                  formatter={(value) => [`$${value}`, 'Portfolio Value']}
                />
                <Area
                  type="monotone"
                  dataKey="value"
                  stroke="#06b6d4"
                  strokeWidth={2}
                  fill="url(#portfolioGradient)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Trading Activity Chart */}
        <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
          <h3 className="text-lg font-semibold text-white mb-4">Trading Activity (24h)</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={tradingActivity}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis 
                  dataKey="name" 
                  stroke="#9ca3af" 
                  fontSize={12}
                />
                <YAxis 
                  stroke="#9ca3af" 
                  fontSize={12}
                />
                <Tooltip 
                  contentStyle={{
                    backgroundColor: '#1f2937',
                    border: '1px solid #374151',
                    borderRadius: '8px',
                    color: '#f9fafb'
                  }}
                />
                <Bar
                  dataKey="value"
                  fill={(entry) => entry.color}
                  radius={[4, 4, 0, 0]}
                />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Active Positions */}
        <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-white">Active Positions</h3>
            <span className="text-sm text-gray-400">{positions?.length || 0} open</span>
          </div>
          <div className="space-y-3">
            {positionsLoading ? (
              <div className="flex justify-center py-8">
                <LoadingSpinner />
              </div>
            ) : positions?.length > 0 ? (
              positions.slice(0, 5).map((position: any) => (
                <div 
                  key={position.id} 
                  className="flex items-center justify-between p-3 bg-gray-700 rounded-lg"
                >
                  <div>
                    <div className="font-medium text-white">{position.token_symbol}</div>
                    <div className="text-sm text-gray-400">
                      ${position.amount?.toFixed(4) || '0'} @ ${position.entry_price?.toFixed(6) || '0'}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className={cn(
                      "font-medium",
                      position.unrealized_pnl >= 0 ? "text-green-400" : "text-red-400"
                    )}>
                      {position.unrealized_pnl >= 0 ? '+' : ''}${position.unrealized_pnl?.toFixed(2) || '0.00'}
                    </div>
                    <div className="text-xs text-gray-400">
                      {((position.unrealized_pnl / (position.entry_price * position.amount)) * 100)?.toFixed(1) || '0.0'}%
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-8 text-gray-400">
                No active positions
              </div>
            )}
          </div>
        </div>

        {/* Recent Trades */}
        <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-white">Recent Trades</h3>
            <span className="text-sm text-gray-400">Last 5</span>
          </div>
          <div className="space-y-3">
            {tradesLoading ? (
              <div className="flex justify-center py-8">
                <LoadingSpinner />
              </div>
            ) : trades?.length > 0 ? (
              trades.map((trade: any) => (
                <TradeCard key={trade.id} trade={trade} />
              ))
            ) : (
              <div className="text-center py-8 text-gray-400">
                No recent trades
              </div>
            )}
          </div>
        </div>

        {/* Trending Tokens */}
        <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-white">Trending Tokens</h3>
            <span className="text-sm text-gray-400">Top 5</span>
          </div>
          <div className="space-y-3">
            {trendingLoading ? (
              <div className="flex justify-center py-8">
                <LoadingSpinner />
              </div>
            ) : trending?.length > 0 ? (
              trending.map((token: any) => (
                <TokenCard key={token.mint_address} token={token} />
              ))
            ) : (
              <div className="text-center py-8 text-gray-400">
                No trending tokens
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Risk Management Panel */}
      {riskReport && (
        <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
          <h3 className="text-lg font-semibold text-white mb-4">Risk Management</h3>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-cyan-400">
                {riskReport.risk_metrics?.position_count || 0}
              </div>
              <div className="text-sm text-gray-400">Open Positions</div>
              <div className="text-xs text-gray-500">
                Max: {riskReport.limits?.max_positions || 0}
              </div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-400">
                {riskReport.risk_metrics?.daily_trades || 0}
              </div>
              <div className="text-sm text-gray-400">Daily Trades</div>
              <div className="text-xs text-gray-500">
                Max: {riskReport.limits?.max_daily_trades || 0}
              </div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-400">
                {(riskReport.risk_metrics?.portfolio_heat * 100)?.toFixed(1) || '0.0'}%
              </div>
              <div className="text-sm text-gray-400">Portfolio Heat</div>
              <div className="text-xs text-gray-500">
                Max: {(riskReport.limits?.max_portfolio_risk * 100)?.toFixed(0) || '0'}%
              </div>
            </div>
            <div className="text-center">
              <div className={cn(
                "text-2xl font-bold",
                riskReport.status?.can_trade ? "text-green-400" : "text-red-400"
              )}>
                {riskReport.status?.can_trade ? "ACTIVE" : "PAUSED"}
              </div>
              <div className="text-sm text-gray-400">Trading Status</div>
              <div className="text-xs text-gray-500">
                Real-time monitoring
              </div>
            </div>
          </div>
        </div>
      )}

      {/* System Status Footer */}
      {systemStatus && (
        <div className="bg-gray-800 rounded-xl p-4 border border-gray-700">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <div className={cn(
                  "w-3 h-3 rounded-full",
                  systemStatus.status === 'operational' ? "bg-green-400" : "bg-red-400"
                )} />
                <span className="text-sm font-medium text-white">
                  System {systemStatus.status === 'operational' ? 'Operational' : 'Issues Detected'}
                </span>
              </div>
              <div className="text-sm text-gray-400">
                Capital: ${systemStatus.config?.initial_capital || '0'} | 
                Max Position: {(systemStatus.config?.max_position_size * 100)?.toFixed(0) || '0'}% | 
                Update Interval: {systemStatus.config?.price_update_interval || '0'}s
              </div>
            </div>
            <div className="text-xs text-gray-500">
              Last updated: {new Date().toLocaleTimeString()}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default Dashboard;