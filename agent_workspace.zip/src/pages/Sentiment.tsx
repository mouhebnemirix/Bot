import React, { useState } from 'react';
import {
  ChatBubbleBottomCenterTextIcon,
  FaceSmileIcon,
  FaceFrownIcon,
  ChartBarIcon,
} from '@heroicons/react/24/outline';
import {
  useSentimentOverview,
  useTokenSentiment,
} from '@/hooks/useApi';
import { cn } from '@/lib/utils';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import TokenCard from '@/components/ui/TokenCard';

function Sentiment() {
  const [selectedToken, setSelectedToken] = useState<string | null>(null);
  const [timeRange, setTimeRange] = useState(24);
  
  const { data: overview, isLoading: overviewLoading } = useSentimentOverview();
  const { data: tokenSentiment, isLoading: tokenLoading } = useTokenSentiment(
    selectedToken || '',
    timeRange
  );

  const getSentimentColor = (score: number) => {
    if (score >= 0.7) return 'text-green-400';
    if (score >= 0.5) return 'text-yellow-400';
    return 'text-red-400';
  };

  const getSentimentBg = (score: number) => {
    if (score >= 0.7) return 'bg-green-500/10 border-green-500/20';
    if (score >= 0.5) return 'bg-yellow-500/10 border-yellow-500/20';
    return 'bg-red-500/10 border-red-500/20';
  };

  const getSentimentLabel = (score: number) => {
    if (score >= 0.7) return 'Bullish';
    if (score >= 0.5) return 'Neutral';
    return 'Bearish';
  };

  // Mock sentiment data for different platforms
  const platformSentiment = [
    { platform: 'Twitter', score: 0.75, mentions: 156, color: '#1da1f2' },
    { platform: 'Reddit', score: 0.68, mentions: 89, color: '#ff4500' },
    { platform: 'Telegram', score: 0.82, mentions: 234, color: '#0088cc' },
    { platform: 'Discord', score: 0.71, mentions: 67, color: '#5865f2' },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-white">Sentiment Analysis</h1>
          <p className="text-gray-400 mt-1">AI-powered social media sentiment tracking</p>
        </div>
        <div className="flex items-center space-x-2">
          <div className="px-3 py-1 bg-blue-900 text-blue-400 rounded-full text-sm font-medium">
            • Live Monitoring
          </div>
        </div>
      </div>

      {/* Overall Sentiment */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400">Overall Sentiment</p>
              <p className="text-2xl font-bold text-green-400">Bullish</p>
              <p className="text-xs text-gray-500 mt-1">85% Positive</p>
            </div>
            <div className="p-3 bg-green-500/10 rounded-lg">
              <FaceSmileIcon className="w-6 h-6 text-green-400" />
            </div>
          </div>
        </div>
        
        <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400">Total Mentions</p>
              <p className="text-2xl font-bold text-white">2,456</p>
              <p className="text-xs text-green-400 mt-1">+12% vs yesterday</p>
            </div>
            <div className="p-3 bg-blue-500/10 rounded-lg">
              <ChatBubbleBottomCenterTextIcon className="w-6 h-6 text-blue-400" />
            </div>
          </div>
        </div>
        
        <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400">Trending Tokens</p>
              <p className="text-2xl font-bold text-white">{overview?.trending_tokens?.length || 0}</p>
              <p className="text-xs text-gray-500 mt-1">High sentiment</p>
            </div>
            <div className="p-3 bg-purple-500/10 rounded-lg">
              <ChartBarIcon className="w-6 h-6 text-purple-400" />
            </div>
          </div>
        </div>
        
        <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400">Confidence Score</p>
              <p className="text-2xl font-bold text-white">87%</p>
              <p className="text-xs text-gray-500 mt-1">AI accuracy</p>
            </div>
            <div className="p-3 bg-cyan-500/10 rounded-lg">
              <ChartBarIcon className="w-6 h-6 text-cyan-400" />
            </div>
          </div>
        </div>
      </div>

      {/* Platform Sentiment */}
      <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
        <h3 className="text-lg font-semibold text-white mb-4">Platform Sentiment</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {platformSentiment.map((platform) => (
            <div key={platform.platform} className="bg-gray-700 rounded-lg p-4">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center space-x-2">
                  <div 
                    className="w-3 h-3 rounded-full"
                    style={{ backgroundColor: platform.color }}
                  />
                  <span className="text-white font-medium">{platform.platform}</span>
                </div>
                <span className={cn(
                  "text-sm font-medium",
                  getSentimentColor(platform.score)
                )}>
                  {getSentimentLabel(platform.score)}
                </span>
              </div>
              <div className="mb-2">
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-gray-400">Sentiment</span>
                  <span className="text-white">{(platform.score * 100).toFixed(0)}%</span>
                </div>
                <div className="w-full bg-gray-600 rounded-full h-2">
                  <div 
                    className={cn(
                      "h-2 rounded-full",
                      platform.score >= 0.7 ? "bg-green-500" :
                      platform.score >= 0.5 ? "bg-yellow-500" : "bg-red-500"
                    )}
                    style={{ width: `${platform.score * 100}%` }}
                  />
                </div>
              </div>
              <div className="text-sm text-gray-400">
                {platform.mentions} mentions
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Trending Tokens */}
        <div className="bg-gray-800 rounded-xl border border-gray-700">
          <div className="p-6 border-b border-gray-700">
            <h3 className="text-lg font-semibold text-white">Trending by Sentiment</h3>
          </div>
          <div className="p-6">
            {overviewLoading ? (
              <div className="flex justify-center py-8">
                <LoadingSpinner />
              </div>
            ) : overview?.trending_tokens?.length > 0 ? (
              <div className="space-y-3">
                {overview.trending_tokens.slice(0, 10).map((token: any) => (
                  <div
                    key={token.mint_address}
                    className={cn(
                      "p-3 rounded-lg border cursor-pointer transition-all duration-200 hover:scale-[1.02]",
                      getSentimentBg(token.avg_sentiment),
                      selectedToken === token.mint_address && "ring-2 ring-cyan-500"
                    )}
                    onClick={() => setSelectedToken(token.mint_address)}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <div className="w-8 h-8 bg-gradient-to-r from-cyan-400 to-blue-500 rounded-full flex items-center justify-center">
                          <span className="text-white font-bold text-xs">
                            {token.mint_address?.charAt(0) || 'T'}
                          </span>
                        </div>
                        <div>
                          <div className="font-medium text-white text-sm">
                            {token.mint_address?.slice(0, 8)}...
                          </div>
                          <div className="text-xs text-gray-400">
                            {token.mention_count} mentions
                          </div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className={cn(
                          "text-sm font-medium",
                          getSentimentColor(token.avg_sentiment)
                        )}>
                          {getSentimentLabel(token.avg_sentiment)}
                        </div>
                        <div className="text-xs text-gray-400">
                          {(token.avg_sentiment * 100).toFixed(0)}%
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-gray-400">
                <ChatBubbleBottomCenterTextIcon className="w-12 h-12 mx-auto mb-4 opacity-50" />
                <p>No trending tokens</p>
                <p className="text-sm mt-1">Sentiment data will appear here</p>
              </div>
            )}
          </div>
        </div>

        {/* Token Sentiment Details */}
        <div className="bg-gray-800 rounded-xl border border-gray-700">
          <div className="p-6 border-b border-gray-700">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold text-white">Token Sentiment</h3>
              <div className="flex space-x-2">
                {[24, 72, 168].map((hours) => (
                  <button
                    key={hours}
                    onClick={() => setTimeRange(hours)}
                    className={cn(
                      'px-3 py-1 rounded text-xs font-medium',
                      timeRange === hours
                        ? 'bg-cyan-600 text-white'
                        : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
                    )}
                  >
                    {hours}h
                  </button>
                ))}
              </div>
            </div>
          </div>
          <div className="p-6">
            {!selectedToken ? (
              <div className="text-center py-8 text-gray-400">
                <FaceSmileIcon className="w-12 h-12 mx-auto mb-4 opacity-50" />
                <p>Select a token to view sentiment details</p>
              </div>
            ) : tokenLoading ? (
              <div className="flex justify-center py-8">
                <LoadingSpinner />
              </div>
            ) : (
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center">
                    <div className={cn(
                      "text-2xl font-bold",
                      getSentimentColor(tokenSentiment?.avg_sentiment || 0)
                    )}>
                      {((tokenSentiment?.avg_sentiment || 0) * 100).toFixed(0)}%
                    </div>
                    <div className="text-sm text-gray-400">Avg Sentiment</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-white">
                      {tokenSentiment?.mention_count || 0}
                    </div>
                    <div className="text-sm text-gray-400">Total Mentions</div>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-400">Confidence</span>
                    <span className="text-white">
                      {((tokenSentiment?.avg_confidence || 0) * 100).toFixed(0)}%
                    </span>
                  </div>
                  <div className="w-full bg-gray-700 rounded-full h-2">
                    <div 
                      className="bg-blue-500 h-2 rounded-full"
                      style={{ width: `${(tokenSentiment?.avg_confidence || 0) * 100}%` }}
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-400">Total Engagement</span>
                    <span className="text-white">
                      {tokenSentiment?.total_engagement || 0}
                    </span>
                  </div>
                </div>
                
                {tokenSentiment?.platforms && (
                  <div className="pt-4 border-t border-gray-700">
                    <div className="text-sm text-gray-400 mb-2">Active Platforms</div>
                    <div className="flex flex-wrap gap-2">
                      {tokenSentiment.platforms.map((platform: string) => (
                        <span 
                          key={platform}
                          className="px-2 py-1 bg-gray-700 text-gray-300 rounded text-xs"
                        >
                          {platform.charAt(0).toUpperCase() + platform.slice(1)}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Recent Sentiment Activity */}
      <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
        <h3 className="text-lg font-semibold text-white mb-4">Recent Sentiment Activity</h3>
        <div className="space-y-3">
          {/* Mock recent activity */}
          {[
            { platform: 'Twitter', content: 'This new Solana meme coin is absolutely pumping! 🚀', sentiment: 0.9, time: '2 minutes ago' },
            { platform: 'Reddit', content: 'Found this gem early, already 300% up! DYOR but looking bullish 📈', sentiment: 0.85, time: '5 minutes ago' },
            { platform: 'Telegram', content: 'Market looking bearish today, might be time to take some profits', sentiment: 0.3, time: '8 minutes ago' },
            { platform: 'Discord', content: 'Great project with strong fundamentals and active community', sentiment: 0.75, time: '12 minutes ago' },
          ].map((activity, index) => (
            <div key={index} className="flex items-start space-x-3 p-3 bg-gray-700 rounded-lg">
              <div className={cn(
                "p-2 rounded-full",
                getSentimentBg(activity.sentiment)
              )}>
                {activity.sentiment >= 0.7 ? (
                  <FaceSmileIcon className="w-4 h-4 text-green-400" />
                ) : (
                  <FaceFrownIcon className="w-4 h-4 text-red-400" />
                )}
              </div>
              <div className="flex-1">
                <div className="flex items-center space-x-2 mb-1">
                  <span className="text-sm font-medium text-white">{activity.platform}</span>
                  <span className={cn(
                    "text-xs px-2 py-1 rounded",
                    getSentimentBg(activity.sentiment)
                  )}>
                    {getSentimentLabel(activity.sentiment)}
                  </span>
                  <span className="text-xs text-gray-400">{activity.time}</span>
                </div>
                <p className="text-sm text-gray-300">{activity.content}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default Sentiment;