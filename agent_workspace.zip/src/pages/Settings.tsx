import React, { useState } from 'react';
import {
  CogIcon,
  BellIcon,
  ShieldCheckIcon,
  DatabaseIcon,
  WifiIcon,
  ExclamationTriangleIcon,
} from '@heroicons/react/24/outline';
import {
  useSystemStatus,
  useRiskReport,
  useTestTelegram,
} from '@/hooks/useApi';
import { cn } from '@/lib/utils';
import LoadingSpinner from '@/components/ui/LoadingSpinner';

function Settings() {
  const [activeTab, setActiveTab] = useState('general');
  const { data: systemStatus } = useSystemStatus();
  const { data: riskReport } = useRiskReport();
  const testTelegram = useTestTelegram();

  const tabs = [
    { id: 'general', name: 'General', icon: CogIcon },
    { id: 'trading', name: 'Trading', icon: DatabaseIcon },
    { id: 'notifications', name: 'Notifications', icon: BellIcon },
    { id: 'risk', name: 'Risk Management', icon: ShieldCheckIcon },
    { id: 'system', name: 'System', icon: WifiIcon },
  ];

  // Mock settings state
  const [settings, setSettings] = useState({
    // General settings
    autoTrading: true,
    darkMode: true,
    language: 'en',
    
    // Trading settings
    maxPositionSize: 10,
    stopLossPercentage: 5,
    takeProfitPercentage: 20,
    maxDailyTrades: 50,
    minConfidenceScore: 70,
    
    // Notification settings
    telegramEnabled: true,
    emailEnabled: false,
    tradeAlerts: true,
    profitAlerts: true,
    lossAlerts: true,
    systemAlerts: true,
    
    // Risk settings
    maxDrawdown: 15,
    portfolioHeatLimit: 20,
    emergencyStop: true,
  });

  const handleSettingChange = (key: string, value: any) => {
    setSettings(prev => ({ ...prev, [key]: value }));
  };

  const renderGeneralSettings = () => (
    <div className="space-y-6">
      <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
        <h3 className="text-lg font-semibold text-white mb-4">General Settings</h3>
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <label className="text-white font-medium">Auto Trading</label>
              <p className="text-sm text-gray-400">Enable automatic trade execution</p>
            </div>
            <button
              onClick={() => handleSettingChange('autoTrading', !settings.autoTrading)}
              className={cn(
                'relative inline-flex h-6 w-11 items-center rounded-full transition-colors',
                settings.autoTrading ? 'bg-cyan-600' : 'bg-gray-600'
              )}
            >
              <span
                className={cn(
                  'inline-block h-4 w-4 transform rounded-full bg-white transition-transform',
                  settings.autoTrading ? 'translate-x-6' : 'translate-x-1'
                )}
              />
            </button>
          </div>
          
          <div className="flex items-center justify-between">
            <div>
              <label className="text-white font-medium">Dark Mode</label>
              <p className="text-sm text-gray-400">Use dark theme interface</p>
            </div>
            <button
              onClick={() => handleSettingChange('darkMode', !settings.darkMode)}
              className={cn(
                'relative inline-flex h-6 w-11 items-center rounded-full transition-colors',
                settings.darkMode ? 'bg-cyan-600' : 'bg-gray-600'
              )}
            >
              <span
                className={cn(
                  'inline-block h-4 w-4 transform rounded-full bg-white transition-transform',
                  settings.darkMode ? 'translate-x-6' : 'translate-x-1'
                )}
              />
            </button>
          </div>
          
          <div>
            <label className="block text-white font-medium mb-2">Language</label>
            <select
              value={settings.language}
              onChange={(e) => handleSettingChange('language', e.target.value)}
              className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
            >
              <option value="en">English</option>
              <option value="zh">中文</option>
              <option value="ja">日本語</option>
            </select>
          </div>
        </div>
      </div>
    </div>
  );

  const renderTradingSettings = () => (
    <div className="space-y-6">
      <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
        <h3 className="text-lg font-semibold text-white mb-4">Trading Parameters</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-white font-medium mb-2">Max Position Size (%)</label>
            <input
              type="number"
              value={settings.maxPositionSize}
              onChange={(e) => handleSettingChange('maxPositionSize', Number(e.target.value))}
              className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
              min="1"
              max="50"
            />
          </div>
          
          <div>
            <label className="block text-white font-medium mb-2">Stop Loss (%)</label>
            <input
              type="number"
              value={settings.stopLossPercentage}
              onChange={(e) => handleSettingChange('stopLossPercentage', Number(e.target.value))}
              className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
              min="1"
              max="20"
            />
          </div>
          
          <div>
            <label className="block text-white font-medium mb-2">Take Profit (%)</label>
            <input
              type="number"
              value={settings.takeProfitPercentage}
              onChange={(e) => handleSettingChange('takeProfitPercentage', Number(e.target.value))}
              className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
              min="5"
              max="100"
            />
          </div>
          
          <div>
            <label className="block text-white font-medium mb-2">Max Daily Trades</label>
            <input
              type="number"
              value={settings.maxDailyTrades}
              onChange={(e) => handleSettingChange('maxDailyTrades', Number(e.target.value))}
              className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
              min="1"
              max="200"
            />
          </div>
          
          <div className="md:col-span-2">
            <label className="block text-white font-medium mb-2">Min Confidence Score (%)</label>
            <input
              type="range"
              value={settings.minConfidenceScore}
              onChange={(e) => handleSettingChange('minConfidenceScore', Number(e.target.value))}
              className="w-full"
              min="50"
              max="95"
            />
            <div className="flex justify-between text-sm text-gray-400 mt-1">
              <span>50%</span>
              <span className="text-cyan-400">{settings.minConfidenceScore}%</span>
              <span>95%</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  const renderNotificationSettings = () => (
    <div className="space-y-6">
      <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
        <h3 className="text-lg font-semibold text-white mb-4">Notification Channels</h3>
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <label className="text-white font-medium">Telegram Notifications</label>
              <p className="text-sm text-gray-400">Send alerts to Telegram bot</p>
            </div>
            <div className="flex items-center space-x-2">
              <button
                onClick={() => testTelegram.mutate()}
                disabled={testTelegram.isPending}
                className="px-3 py-1 bg-blue-600 text-white rounded text-sm hover:bg-blue-700 disabled:opacity-50"
              >
                {testTelegram.isPending ? 'Testing...' : 'Test'}
              </button>
              <button
                onClick={() => handleSettingChange('telegramEnabled', !settings.telegramEnabled)}
                className={cn(
                  'relative inline-flex h-6 w-11 items-center rounded-full transition-colors',
                  settings.telegramEnabled ? 'bg-cyan-600' : 'bg-gray-600'
                )}
              >
                <span
                  className={cn(
                    'inline-block h-4 w-4 transform rounded-full bg-white transition-transform',
                    settings.telegramEnabled ? 'translate-x-6' : 'translate-x-1'
                  )}
                />
              </button>
            </div>
          </div>
          
          <div className="flex items-center justify-between">
            <div>
              <label className="text-white font-medium">Email Notifications</label>
              <p className="text-sm text-gray-400">Send alerts via email</p>
            </div>
            <button
              onClick={() => handleSettingChange('emailEnabled', !settings.emailEnabled)}
              className={cn(
                'relative inline-flex h-6 w-11 items-center rounded-full transition-colors',
                settings.emailEnabled ? 'bg-cyan-600' : 'bg-gray-600'
              )}
            >
              <span
                className={cn(
                  'inline-block h-4 w-4 transform rounded-full bg-white transition-transform',
                  settings.emailEnabled ? 'translate-x-6' : 'translate-x-1'
                )}
              />
            </button>
          </div>
        </div>
      </div>
      
      <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
        <h3 className="text-lg font-semibold text-white mb-4">Alert Types</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {[
            { key: 'tradeAlerts', label: 'Trade Executions', desc: 'Buy/sell notifications' },
            { key: 'profitAlerts', label: 'Profit Alerts', desc: 'Successful trade notifications' },
            { key: 'lossAlerts', label: 'Loss Alerts', desc: 'Stop loss notifications' },
            { key: 'systemAlerts', label: 'System Alerts', desc: 'Bot status notifications' },
          ].map((alert) => (
            <div key={alert.key} className="flex items-center justify-between p-3 bg-gray-700 rounded-lg">
              <div>
                <label className="text-white font-medium">{alert.label}</label>
                <p className="text-sm text-gray-400">{alert.desc}</p>
              </div>
              <button
                onClick={() => handleSettingChange(alert.key, !settings[alert.key as keyof typeof settings])}
                className={cn(
                  'relative inline-flex h-6 w-11 items-center rounded-full transition-colors',
                  settings[alert.key as keyof typeof settings] ? 'bg-cyan-600' : 'bg-gray-600'
                )}
              >
                <span
                  className={cn(
                    'inline-block h-4 w-4 transform rounded-full bg-white transition-transform',
                    settings[alert.key as keyof typeof settings] ? 'translate-x-6' : 'translate-x-1'
                  )}
                />
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const renderRiskSettings = () => (
    <div className="space-y-6">
      <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
        <h3 className="text-lg font-semibold text-white mb-4">Risk Management</h3>
        <div className="space-y-4">
          <div>
            <label className="block text-white font-medium mb-2">Max Drawdown (%)</label>
            <input
              type="range"
              value={settings.maxDrawdown}
              onChange={(e) => handleSettingChange('maxDrawdown', Number(e.target.value))}
              className="w-full"
              min="5"
              max="30"
            />
            <div className="flex justify-between text-sm text-gray-400 mt-1">
              <span>5%</span>
              <span className="text-red-400">{settings.maxDrawdown}%</span>
              <span>30%</span>
            </div>
          </div>
          
          <div>
            <label className="block text-white font-medium mb-2">Portfolio Heat Limit (%)</label>
            <input
              type="range"
              value={settings.portfolioHeatLimit}
              onChange={(e) => handleSettingChange('portfolioHeatLimit', Number(e.target.value))}
              className="w-full"
              min="10"
              max="50"
            />
            <div className="flex justify-between text-sm text-gray-400 mt-1">
              <span>10%</span>
              <span className="text-yellow-400">{settings.portfolioHeatLimit}%</span>
              <span>50%</span>
            </div>
          </div>
          
          <div className="flex items-center justify-between">
            <div>
              <label className="text-white font-medium">Emergency Stop</label>
              <p className="text-sm text-gray-400">Auto-stop trading on major losses</p>
            </div>
            <button
              onClick={() => handleSettingChange('emergencyStop', !settings.emergencyStop)}
              className={cn(
                'relative inline-flex h-6 w-11 items-center rounded-full transition-colors',
                settings.emergencyStop ? 'bg-red-600' : 'bg-gray-600'
              )}
            >
              <span
                className={cn(
                  'inline-block h-4 w-4 transform rounded-full bg-white transition-transform',
                  settings.emergencyStop ? 'translate-x-6' : 'translate-x-1'
                )}
              />
            </button>
          </div>
        </div>
      </div>
      
      {riskReport && (
        <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
          <h3 className="text-lg font-semibold text-white mb-4">Current Risk Status</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="text-center p-4 bg-gray-700 rounded-lg">
              <div className="text-2xl font-bold text-cyan-400">
                {((riskReport.risk_metrics?.portfolio_heat || 0) * 100).toFixed(1)}%
              </div>
              <div className="text-sm text-gray-400">Current Portfolio Heat</div>
            </div>
            <div className="text-center p-4 bg-gray-700 rounded-lg">
              <div className="text-2xl font-bold text-green-400">
                {riskReport.risk_metrics?.position_count || 0}
              </div>
              <div className="text-sm text-gray-400">Open Positions</div>
            </div>
            <div className="text-center p-4 bg-gray-700 rounded-lg">
              <div className="text-2xl font-bold text-blue-400">
                {riskReport.risk_metrics?.daily_trades || 0}
              </div>
              <div className="text-sm text-gray-400">Daily Trades</div>
            </div>
            <div className="text-center p-4 bg-gray-700 rounded-lg">
              <div className={cn(
                "text-2xl font-bold",
                riskReport.status?.can_trade ? "text-green-400" : "text-red-400"
              )}>
                {riskReport.status?.can_trade ? "ACTIVE" : "PAUSED"}
              </div>
              <div className="text-sm text-gray-400">Trading Status</div>
            </div>
          </div>
        </div>
      )}
    </div>
  );

  const renderSystemSettings = () => (
    <div className="space-y-6">
      <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
        <h3 className="text-lg font-semibold text-white mb-4">System Status</h3>
        {systemStatus ? (
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {Object.entries(systemStatus.services || {}).map(([service, status]) => (
                <div key={service} className="flex items-center justify-between p-3 bg-gray-700 rounded-lg">
                  <div>
                    <div className="font-medium text-white capitalize">
                      {service.replace('_', ' ')}
                    </div>
                    <div className="text-sm text-gray-400">Service status</div>
                  </div>
                  <div className={cn(
                    "px-2 py-1 rounded text-sm font-medium",
                    status === 'running' || status === 'connected' 
                      ? "bg-green-900 text-green-400" 
                      : "bg-red-900 text-red-400"
                  )}>
                    {status}
                  </div>
                </div>
              ))}
            </div>
            
            <div className="border-t border-gray-700 pt-4">
              <h4 className="text-md font-medium text-white mb-3">Configuration</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-400">Initial Capital:</span>
                  <span className="text-white">${systemStatus.config?.initial_capital}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Max Position Size:</span>
                  <span className="text-white">{(systemStatus.config?.max_position_size * 100)?.toFixed(0)}%</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Max Daily Trades:</span>
                  <span className="text-white">{systemStatus.config?.max_daily_trades}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Update Interval:</span>
                  <span className="text-white">{systemStatus.config?.price_update_interval}s</span>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="flex justify-center py-8">
            <LoadingSpinner />
          </div>
        )}
      </div>
      
      <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
        <h3 className="text-lg font-semibold text-white mb-4">System Actions</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <button className="flex items-center justify-center space-x-2 p-3 bg-cyan-600 text-white rounded-lg hover:bg-cyan-700 transition-colors">
            <DatabaseIcon className="w-5 h-5" />
            <span>Backup Data</span>
          </button>
          <button className="flex items-center justify-center space-x-2 p-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
            <WifiIcon className="w-5 h-5" />
            <span>Test Connection</span>
          </button>
          <button className="flex items-center justify-center space-x-2 p-3 bg-yellow-600 text-white rounded-lg hover:bg-yellow-700 transition-colors">
            <ExclamationTriangleIcon className="w-5 h-5" />
            <span>Reset Settings</span>
          </button>
          <button className="flex items-center justify-center space-x-2 p-3 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors">
            <ExclamationTriangleIcon className="w-5 h-5" />
            <span>Emergency Stop</span>
          </button>
        </div>
      </div>
    </div>
  );

  const renderTabContent = () => {
    switch (activeTab) {
      case 'general':
        return renderGeneralSettings();
      case 'trading':
        return renderTradingSettings();
      case 'notifications':
        return renderNotificationSettings();
      case 'risk':
        return renderRiskSettings();
      case 'system':
        return renderSystemSettings();
      default:
        return renderGeneralSettings();
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-white">Settings</h1>
        <p className="text-gray-400 mt-1">Configure your trading bot parameters</p>
      </div>

      {/* Tabs */}
      <div className="flex space-x-1 bg-gray-800 rounded-lg p-1 overflow-x-auto">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={cn(
                'flex items-center space-x-2 px-4 py-2 rounded-md text-sm font-medium transition-colors whitespace-nowrap',
                activeTab === tab.id
                  ? 'bg-gray-700 text-white'
                  : 'text-gray-400 hover:text-white hover:bg-gray-700'
              )}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.name}</span>
            </button>
          );
        })}
      </div>

      {/* Tab Content */}
      {renderTabContent()}

      {/* Save Button */}
      <div className="flex justify-end">
        <button className="px-6 py-2 bg-cyan-600 text-white rounded-lg hover:bg-cyan-700 transition-colors font-medium">
          Save Settings
        </button>
      </div>
    </div>
  );
}

export default Settings;