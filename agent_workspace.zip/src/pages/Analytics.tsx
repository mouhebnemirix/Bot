import React, { useState } from 'react';
import {
  ChartBarIcon,
  TrendingUpIcon,
  CurrencyDollarIcon,
  ClockIcon,
} from '@heroicons/react/24/outline';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  AreaChart,
  Area,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
} from 'recharts';
import {
  usePerformanceAnalytics,
  usePortfolioOverview,
} from '@/hooks/useApi';
import { cn } from '@/lib/utils';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import StatCard from '@/components/ui/StatCard';

function Analytics() {
  const [selectedPeriod, setSelectedPeriod] = useState('7d');
  const { data: analytics, isLoading: analyticsLoading } = usePerformanceAnalytics(selectedPeriod);
  const { data: portfolio } = usePortfolioOverview();

  // Mock data for comprehensive analytics
  const performanceData = [
    { date: '2024-01-20', portfolio: 1.0, benchmark: 1.0, trades: 3 },
    { date: '2024-01-21', portfolio: 1.2, benchmark: 1.05, trades: 5 },
    { date: '2024-01-22', portfolio: 1.1, benchmark: 1.02, trades: 2 },
    { date: '2024-01-23', portfolio: 1.8, benchmark: 1.12, trades: 8 },
    { date: '2024-01-24', portfolio: 2.1, benchmark: 1.18, trades: 6 },
    { date: '2024-01-25', portfolio: 1.9, benchmark: 1.15, trades: 4 },
    { date: '2024-01-26', portfolio: 2.4, benchmark: 1.22, trades: 7 },
    { date: '2024-01-27', portfolio: 2.7, benchmark: 1.28, trades: 9 },
  ];

  const riskMetrics = [
    { metric: 'Max Drawdown', value: -5.2, target: -10 },
    { metric: 'Volatility', value: 12.3, target: 15 },
    { metric: 'Sharpe Ratio', value: 2.4, target: 2.0 },
    { metric: 'Win Rate', value: 68, target: 60 },
  ];

  const tradingPatterns = [
    { hour: '00', trades: 2, success: 1 },
    { hour: '06', trades: 8, success: 6 },
    { hour: '12', trades: 15, success: 11 },
    { hour: '18', trades: 12, success: 8 },
  ];

  const tokenPerformance = [
    { name: 'DOGES', allocation: 25, performance: 45.2, color: '#06b6d4' },
    { name: 'PEPES', allocation: 20, performance: 32.1, color: '#3b82f6' },
    { name: 'BONKS', allocation: 18, performance: -8.5, color: '#8b5cf6' },
    { name: 'FLOKIS', allocation: 15, performance: 28.7, color: '#10b981' },
    { name: 'Others', allocation: 22, performance: 12.4, color: '#f59e0b' },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-white">Analytics</h1>
          <p className="text-gray-400 mt-1">Comprehensive trading performance analysis</p>
        </div>
        <div className="flex space-x-2">
          {['1d', '7d', '30d', '90d'].map((period) => (
            <button
              key={period}
              onClick={() => setSelectedPeriod(period)}
              className={cn(
                'px-4 py-2 rounded-lg text-sm font-medium transition-colors',
                selectedPeriod === period
                  ? 'bg-cyan-600 text-white'
                  : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
              )}
            >
              {period}
            </button>
          ))}
        </div>
      </div>

      {/* Key Performance Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard
          title="Total Return"
          value={`${((portfolio?.total_value || 1) - 1) * 100 > 0 ? '+' : ''}${(((portfolio?.total_value || 1) - 1) * 100).toFixed(1)}%`}
          change={0}
          icon={TrendingUpIcon}
          trend={portfolio?.total_value >= 1 ? "up" : "down"}
          color={portfolio?.total_value >= 1 ? "green" : "red"}
        />
        <StatCard
          title="Sharpe Ratio"
          value={portfolio?.sharpe_ratio?.toFixed(2) || '2.40'}
          change={0}
          icon={ChartBarIcon}
          trend="up"
          color="blue"
        />
        <StatCard
          title="Max Drawdown"
          value={`${portfolio?.max_drawdown?.toFixed(1) || '-5.2'}%`}
          change={0}
          icon={TrendingUpIcon}
          trend="neutral"
          color="yellow"
        />
        <StatCard
          title="Avg Trade Time"
          value="4.2h"
          change={0}
          icon={ClockIcon}
          trend="neutral"
          color="purple"
        />
      </div>

      {/* Performance vs Benchmark */}
      <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
        <h3 className="text-lg font-semibold text-white mb-4">Performance vs Benchmark</h3>
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={performanceData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis 
                dataKey="date" 
                stroke="#9ca3af" 
                fontSize={12}
                tickFormatter={(value) => new Date(value).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
              />
              <YAxis 
                stroke="#9ca3af" 
                fontSize={12}
                tickFormatter={(value) => `${((value - 1) * 100).toFixed(0)}%`}
              />
              <Tooltip 
                contentStyle={{
                  backgroundColor: '#1f2937',
                  border: '1px solid #374151',
                  borderRadius: '8px',
                  color: '#f9fafb'
                }}
                formatter={(value, name) => [
                  `${((Number(value) - 1) * 100).toFixed(1)}%`, 
                  name === 'portfolio' ? 'Trading Bot' : 'SOL Benchmark'
                ]}
                labelFormatter={(value) => new Date(value).toLocaleDateString()}
              />
              <Line
                type="monotone"
                dataKey="portfolio"
                stroke="#06b6d4"
                strokeWidth={3}
                dot={{ fill: '#06b6d4', strokeWidth: 2, r: 4 }}
                name="portfolio"
              />
              <Line
                type="monotone"
                dataKey="benchmark"
                stroke="#6b7280"
                strokeWidth={2}
                strokeDasharray="5 5"
                dot={{ fill: '#6b7280', strokeWidth: 2, r: 3 }}
                name="benchmark"
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Analytics Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Risk Metrics */}
        <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
          <h3 className="text-lg font-semibold text-white mb-4">Risk Metrics</h3>
          <div className="space-y-4">
            {riskMetrics.map((metric, index) => {
              const isGood = metric.metric === 'Max Drawdown' ? 
                metric.value > metric.target : metric.value >= metric.target;
              
              return (
                <div key={index} className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-gray-400">{metric.metric}</span>
                    <div className="text-right">
                      <span className={cn(
                        "font-medium",
                        isGood ? "text-green-400" : "text-yellow-400"
                      )}>
                        {metric.value > 0 ? 
                          (metric.metric === 'Win Rate' ? `${metric.value}%` : metric.value.toFixed(1)) :
                          `${metric.value}%`
                        }
                      </span>
                      <div className="text-xs text-gray-500">
                        Target: {metric.target > 0 ? 
                          (metric.metric === 'Win Rate' ? `${metric.target}%` : metric.target.toFixed(1)) :
                          `${metric.target}%`
                        }
                      </div>
                    </div>
                  </div>
                  <div className="w-full bg-gray-700 rounded-full h-2">
                    <div 
                      className={cn(
                        "h-2 rounded-full",
                        isGood ? "bg-green-500" : "bg-yellow-500"
                      )}
                      style={{ 
                        width: `${Math.min(100, Math.abs(metric.value / metric.target) * 100)}%` 
                      }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Trading Patterns */}
        <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
          <h3 className="text-lg font-semibold text-white mb-4">Trading Patterns by Time</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={tradingPatterns}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis 
                  dataKey="hour" 
                  stroke="#9ca3af" 
                  fontSize={12}
                  tickFormatter={(value) => `${value}:00`}
                />
                <YAxis 
                  stroke="#9ca3af" 
                  fontSize={12}
                />
                <Tooltip 
                  contentStyle={{
                    backgroundColor: '#1f2937',
                    border: '1px solid #374151',
                    borderRadius: '8px',
                    color: '#f9fafb'
                  }}
                  formatter={(value, name) => [
                    value,
                    name === 'trades' ? 'Total Trades' : 'Successful Trades'
                  ]}
                />
                <Bar
                  dataKey="trades"
                  fill="#374151"
                  radius={[2, 2, 0, 0]}
                />
                <Bar
                  dataKey="success"
                  fill="#06b6d4"
                  radius={[2, 2, 0, 0]}
                />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Token Performance Analysis */}
      <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
        <h3 className="text-lg font-semibold text-white mb-4">Token Performance Analysis</h3>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Allocation Pie Chart */}
          <div>
            <h4 className="text-md font-medium text-white mb-3">Portfolio Allocation</h4>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={tokenPerformance}
                    cx="50%"
                    cy="50%"
                    innerRadius={50}
                    outerRadius={100}
                    paddingAngle={5}
                    dataKey="allocation"
                  >
                    {tokenPerformance.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip 
                    contentStyle={{
                      backgroundColor: '#1f2937',
                      border: '1px solid #374151',
                      borderRadius: '8px',
                      color: '#f9fafb'
                    }}
                    formatter={(value) => [`${value}%`, 'Allocation']}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Performance Table */}
          <div>
            <h4 className="text-md font-medium text-white mb-3">Token Performance</h4>
            <div className="space-y-3">
              {tokenPerformance.map((token, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-gray-700 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div 
                      className="w-4 h-4 rounded-full"
                      style={{ backgroundColor: token.color }}
                    />
                    <div>
                      <div className="font-medium text-white">{token.name}</div>
                      <div className="text-sm text-gray-400">{token.allocation}% allocation</div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className={cn(
                      "font-medium",
                      token.performance >= 0 ? "text-green-400" : "text-red-400"
                    )}>
                      {token.performance >= 0 ? '+' : ''}{token.performance.toFixed(1)}%
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Trading Distribution */}
      {analytics && (
        <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
          <h3 className="text-lg font-semibold text-white mb-4">Trading Distribution</h3>
          {analyticsLoading ? (
            <div className="flex justify-center py-8">
              <LoadingSpinner size="lg" />
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="text-center">
                <div className="text-2xl font-bold text-cyan-400">
                  {analytics.summary?.trading_days || 0}
                </div>
                <div className="text-sm text-gray-400">Active Trading Days</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-green-400">
                  {analytics.summary?.total_metrics || 0}
                </div>
                <div className="text-sm text-gray-400">Performance Snapshots</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-blue-400">
                  {analytics.trade_distribution?.reduce((sum: number, day: any) => sum + day.trade_count, 0) || 0}
                </div>
                <div className="text-sm text-gray-400">Total Trades</div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

export default Analytics;