import React, { useState } from 'react';
import {
  MagnifyingGlassIcon,
  FireIcon,
  SparklesIcon,
  ArrowUpIcon,
  ArrowDownIcon,
} from '@heroicons/react/24/outline';
import {
  useTokens,
  useTrendingTokens,
  useNewTokens,
} from '@/hooks/useApi';
import { cn, formatNumber, formatTimeAgo } from '@/lib/utils';
import LoadingSpinner from '@/components/ui/LoadingSpinner';
import TokenCard from '@/components/ui/TokenCard';

function Market() {
  const [selectedTab, setSelectedTab] = useState('all');
  const [sortBy, setSortBy] = useState('volume_24h');
  const [searchTerm, setSearchTerm] = useState('');
  
  const { data: allTokens, isLoading: tokensLoading } = useTokens(100, true, sortBy);
  const { data: trending, isLoading: trendingLoading } = useTrendingTokens(20);
  const { data: newTokens, isLoading: newLoading } = useNewTokens(24, 30);

  const tabs = [
    { id: 'all', name: 'All Tokens', icon: MagnifyingGlassIcon },
    { id: 'trending', name: 'Trending', icon: FireIcon },
    { id: 'new', name: 'New Tokens', icon: SparklesIcon },
  ];

  const sortOptions = [
    { value: 'volume_24h', label: 'Volume (24h)' },
    { value: 'market_cap', label: 'Market Cap' },
    { value: 'price_change_24h', label: 'Price Change' },
  ];

  const filteredTokens = (tokens: any[]) => {
    if (!searchTerm) return tokens;
    return tokens?.filter((token: any) => 
      token.symbol?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      token.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      token.mint_address?.toLowerCase().includes(searchTerm.toLowerCase())
    ) || [];
  };

  const getCurrentTokens = () => {
    switch (selectedTab) {
      case 'trending':
        return filteredTokens(trending || []);
      case 'new':
        return filteredTokens(newTokens || []);
      default:
        return filteredTokens(allTokens || []);
    }
  };

  const getCurrentLoading = () => {
    switch (selectedTab) {
      case 'trending':
        return trendingLoading;
      case 'new':
        return newLoading;
      default:
        return tokensLoading;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-white">Market</h1>
          <p className="text-gray-400 mt-1">Discover and analyze Solana meme coins</p>
        </div>
      </div>

      {/* Market Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400">Total Tokens</p>
              <p className="text-2xl font-bold text-white">{allTokens?.length || 0}</p>
            </div>
            <div className="p-3 bg-blue-500/10 rounded-lg">
              <MagnifyingGlassIcon className="w-6 h-6 text-blue-400" />
            </div>
          </div>
        </div>
        
        <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400">Trending Now</p>
              <p className="text-2xl font-bold text-white">{trending?.length || 0}</p>
            </div>
            <div className="p-3 bg-orange-500/10 rounded-lg">
              <FireIcon className="w-6 h-6 text-orange-400" />
            </div>
          </div>
        </div>
        
        <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400">New Today</p>
              <p className="text-2xl font-bold text-white">{newTokens?.length || 0}</p>
            </div>
            <div className="p-3 bg-green-500/10 rounded-lg">
              <SparklesIcon className="w-6 h-6 text-green-400" />
            </div>
          </div>
        </div>
        
        <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400">Avg. Volume</p>
              <p className="text-2xl font-bold text-white">
                ${formatNumber(allTokens?.reduce((sum: number, token: any) => sum + (token.volume_24h || 0), 0) / (allTokens?.length || 1) || 0)}
              </p>
            </div>
            <div className="p-3 bg-purple-500/10 rounded-lg">
              <ArrowUpIcon className="w-6 h-6 text-purple-400" />
            </div>
          </div>
        </div>
      </div>

      {/* Filters and Search */}
      <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
          {/* Tabs */}
          <div className="flex space-x-1 bg-gray-700 rounded-lg p-1">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setSelectedTab(tab.id)}
                  className={cn(
                    'flex items-center space-x-2 px-4 py-2 rounded-md text-sm font-medium transition-colors',
                    selectedTab === tab.id
                      ? 'bg-gray-600 text-white'
                      : 'text-gray-400 hover:text-white hover:bg-gray-600'
                  )}
                >
                  <Icon className="w-4 h-4" />
                  <span>{tab.name}</span>
                </button>
              );
            })}
          </div>

          {/* Search and Sort */}
          <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-4">
            {/* Search */}
            <div className="relative">
              <MagnifyingGlassIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input
                type="text"
                placeholder="Search tokens..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 pr-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-transparent"
              />
            </div>

            {/* Sort */}
            {selectedTab === 'all' && (
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="px-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-transparent"
              >
                {sortOptions.map((option) => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
            )}
          </div>
        </div>
      </div>

      {/* Token List */}
      <div className="bg-gray-800 rounded-xl border border-gray-700">
        <div className="p-6 border-b border-gray-700">
          <h3 className="text-lg font-semibold text-white">
            {tabs.find(tab => tab.id === selectedTab)?.name} ({getCurrentTokens().length})
          </h3>
        </div>
        
        <div className="overflow-x-auto">
          {getCurrentLoading() ? (
            <div className="flex justify-center py-12">
              <LoadingSpinner size="lg" />
            </div>
          ) : getCurrentTokens().length > 0 ? (
            <table className="w-full">
              <thead className="bg-gray-700">
                <tr className="text-left">
                  <th className="px-6 py-3 text-xs font-medium text-gray-300 uppercase tracking-wider">
                    Token
                  </th>
                  <th className="px-6 py-3 text-xs font-medium text-gray-300 uppercase tracking-wider">
                    Price
                  </th>
                  <th className="px-6 py-3 text-xs font-medium text-gray-300 uppercase tracking-wider">
                    24h Change
                  </th>
                  <th className="px-6 py-3 text-xs font-medium text-gray-300 uppercase tracking-wider">
                    Volume (24h)
                  </th>
                  <th className="px-6 py-3 text-xs font-medium text-gray-300 uppercase tracking-wider">
                    Market Cap
                  </th>
                  <th className="px-6 py-3 text-xs font-medium text-gray-300 uppercase tracking-wider">
                    Holders
                  </th>
                  {selectedTab === 'new' && (
                    <th className="px-6 py-3 text-xs font-medium text-gray-300 uppercase tracking-wider">
                      Created
                    </th>
                  )}
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-700">
                {getCurrentTokens().map((token: any) => {
                  const isPositive = (token.price_change_24h || 0) >= 0;
                  
                  return (
                    <tr key={token.mint_address} className="hover:bg-gray-700/50 cursor-pointer">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <div className="w-8 h-8 bg-gradient-to-r from-cyan-400 to-blue-500 rounded-full flex items-center justify-center mr-3">
                            <span className="text-white font-bold text-xs">
                              {token.symbol?.charAt(0) || 'T'}
                            </span>
                          </div>
                          <div>
                            <div className="text-sm font-medium text-white">
                              {token.symbol || 'UNKNOWN'}
                            </div>
                            <div className="text-xs text-gray-400 max-w-32 truncate">
                              {token.name || 'Unknown Token'}
                            </div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-white">
                        ${token.price_usd?.toFixed(8) || '0.00000000'}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm">
                        <div className={cn(
                          "flex items-center",
                          isPositive ? "text-green-400" : "text-red-400"
                        )}>
                          {isPositive ? (
                            <ArrowUpIcon className="w-4 h-4 mr-1" />
                          ) : (
                            <ArrowDownIcon className="w-4 h-4 mr-1" />
                          )}
                          {Math.abs(token.price_change_24h || 0).toFixed(2)}%
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-white">
                        ${formatNumber(token.volume_24h || 0)}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-white">
                        ${formatNumber(token.market_cap || 0)}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-white">
                        {formatNumber(token.holders_count || 0, 0)}
                      </td>
                      {selectedTab === 'new' && (
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-400">
                          {formatTimeAgo(token.created_at)}
                        </td>
                      )}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          ) : (
            <div className="text-center py-12 text-gray-400">
              <MagnifyingGlassIcon className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p>No tokens found</p>
              <p className="text-sm mt-1">
                {searchTerm ? 'Try adjusting your search terms' : 'Tokens will appear here when discovered'}
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default Market;