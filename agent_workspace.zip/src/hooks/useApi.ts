import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import axios from 'axios';
import toast from 'react-hot-toast';

const API_BASE_URL = 'http://localhost:8000/api/v1';

// Configure axios
const api = axios.create({
  baseURL: API_BASE_URL,
  timeout: 10000,
});

// Request interceptor
api.interceptors.request.use(
  (config) => {
    console.log(`API Request: ${config.method?.toUpperCase()} ${config.url}`);
    return config;
  },
  (error) => {
    console.error('API Request Error:', error);
    return Promise.reject(error);
  }
);

// Response interceptor
api.interceptors.response.use(
  (response) => {
    return response;
  },
  (error) => {
    console.error('API Response Error:', error);
    if (error.response?.status === 503) {
      toast.error('Service temporarily unavailable');
    } else if (error.response?.status >= 500) {
      toast.error('Server error occurred');
    } else if (error.code === 'ECONNREFUSED') {
      toast.error('Cannot connect to trading bot backend');
    }
    return Promise.reject(error);
  }
);

// Portfolio hooks
export const usePortfolioOverview = () => {
  return useQuery({
    queryKey: ['portfolio', 'overview'],
    queryFn: async () => {
      const response = await api.get('/portfolio/overview');
      return response.data.data;
    },
    refetchInterval: 30000, // Refetch every 30 seconds
  });
};

export const useActivePositions = (walletId?: number) => {
  return useQuery({
    queryKey: ['portfolio', 'positions', walletId],
    queryFn: async () => {
      const response = await api.get('/portfolio/positions', {
        params: walletId ? { wallet_id: walletId } : {},
      });
      return response.data.data;
    },
    refetchInterval: 15000, // Refetch every 15 seconds
  });
};

export const usePerformanceSummary = (days: number = 7) => {
  return useQuery({
    queryKey: ['portfolio', 'performance', days],
    queryFn: async () => {
      const response = await api.get('/portfolio/performance', {
        params: { days },
      });
      return response.data.data;
    },
    refetchInterval: 60000, // Refetch every minute
  });
};

// Trading hooks
export const useTradingSignals = (limit: number = 10) => {
  return useQuery({
    queryKey: ['trading', 'signals', limit],
    queryFn: async () => {
      const response = await api.get('/trading/signals', {
        params: { limit },
      });
      return response.data.data;
    },
    refetchInterval: 30000,
  });
};

export const useRecentTrades = (limit: number = 20, walletId?: number) => {
  return useQuery({
    queryKey: ['trading', 'trades', limit, walletId],
    queryFn: async () => {
      const response = await api.get('/trading/trades', {
        params: {
          limit,
          ...(walletId && { wallet_id: walletId }),
        },
      });
      return response.data.data;
    },
    refetchInterval: 15000,
  });
};

// Market data hooks
export const useTokens = (
  limit: number = 50,
  memeOnly: boolean = true,
  sortBy: string = 'volume_24h'
) => {
  return useQuery({
    queryKey: ['market', 'tokens', limit, memeOnly, sortBy],
    queryFn: async () => {
      const response = await api.get('/market/tokens', {
        params: { limit, meme_only: memeOnly, sort_by: sortBy },
      });
      return response.data.data;
    },
    refetchInterval: 30000,
  });
};

export const useTokenDetails = (mintAddress: string) => {
  return useQuery({
    queryKey: ['market', 'token', mintAddress],
    queryFn: async () => {
      const response = await api.get(`/market/tokens/${mintAddress}`);
      return response.data.data;
    },
    enabled: !!mintAddress,
    refetchInterval: 15000,
  });
};

export const useTrendingTokens = (limit: number = 10) => {
  return useQuery({
    queryKey: ['market', 'trending', limit],
    queryFn: async () => {
      const response = await api.get('/market/trending', {
        params: { limit },
      });
      return response.data.data;
    },
    refetchInterval: 60000,
  });
};

export const useNewTokens = (hours: number = 24, limit: number = 20) => {
  return useQuery({
    queryKey: ['market', 'new-tokens', hours, limit],
    queryFn: async () => {
      const response = await api.get('/market/new-tokens', {
        params: { hours, limit },
      });
      return response.data.data;
    },
    refetchInterval: 120000, // Refetch every 2 minutes
  });
};

// Sentiment hooks
export const useSentimentOverview = () => {
  return useQuery({
    queryKey: ['sentiment', 'overview'],
    queryFn: async () => {
      const response = await api.get('/sentiment/overview');
      return response.data.data;
    },
    refetchInterval: 60000,
  });
};

export const useTokenSentiment = (mintAddress: string, hours: number = 24) => {
  return useQuery({
    queryKey: ['sentiment', 'token', mintAddress, hours],
    queryFn: async () => {
      const response = await api.get(`/sentiment/tokens/${mintAddress}`, {
        params: { hours },
      });
      return response.data.data;
    },
    enabled: !!mintAddress,
    refetchInterval: 60000,
  });
};

// Risk management hooks
export const useRiskReport = () => {
  return useQuery({
    queryKey: ['risk', 'report'],
    queryFn: async () => {
      const response = await api.get('/risk/report');
      return response.data.data;
    },
    refetchInterval: 30000,
  });
};

// System hooks
export const useSystemStatus = () => {
  return useQuery({
    queryKey: ['system', 'status'],
    queryFn: async () => {
      const response = await api.get('/system/status');
      return response.data.data;
    },
    refetchInterval: 30000,
  });
};

// Analytics hooks
export const usePerformanceAnalytics = (period: string = '7d') => {
  return useQuery({
    queryKey: ['analytics', 'performance', period],
    queryFn: async () => {
      const response = await api.get('/analytics/performance', {
        params: { period },
      });
      return response.data.data;
    },
    refetchInterval: 60000,
  });
};

// Mutations
export const useTestTelegram = () => {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async () => {
      const response = await api.post('/system/test-telegram');
      return response.data;
    },
    onSuccess: (data) => {
      if (data.success) {
        toast.success('Telegram test message sent successfully');
      } else {
        toast.error('Failed to send Telegram test message');
      }
    },
    onError: (error) => {
      console.error('Telegram test error:', error);
      toast.error('Failed to test Telegram connection');
    },
  });
};

// Export the axios instance for custom requests
export { api };