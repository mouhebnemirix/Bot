import aiohttp
import asyncio
import logging
from typing import Dict, Optional, Any, List
import json
from datetime import datetime

from utils.config import config

logger = logging.getLogger(__name__)

class JupiterClient:
    """Client for Jupiter DEX aggregator"""
    
    def __init__(self):
        self.api_url = config.JUPITER_API_URL
        self.session = None
    
    async def _get_session(self):
        """Get or create aiohttp session"""
        if not self.session:
            self.session = aiohttp.ClientSession()
        return self.session
    
    async def close(self):
        """Close aiohttp session"""
        if self.session:
            await self.session.close()
    
    async def get_quote(self, input_mint: str, output_mint: str, amount: float, slippage_bps: int = 50) -> Optional[Dict]:
        """Get swap quote from Jupiter"""
        try:
            session = await self._get_session()
            
            # Convert amount to lamports (for SOL) or smallest unit
            if input_mint == "So11111111111111111111111111111111111111112":  # SOL
                amount_lamports = int(amount * 1_000_000_000)  # Convert SOL to lamports
            else:
                amount_lamports = int(amount * 1_000_000_000)  # Assume 9 decimals
            
            params = {
                'inputMint': input_mint,
                'outputMint': output_mint,
                'amount': str(amount_lamports),
                'slippageBps': str(slippage_bps)
            }
            
            async with session.get(f"{self.api_url}/quote", params=params) as response:
                if response.status == 200:
                    data = await response.json()
                    return self._process_quote_response(data)
                else:
                    logger.error(f"Jupiter quote failed: {response.status} - {await response.text()}")
                    return None
                    
        except Exception as e:
            logger.error(f"Error getting Jupiter quote: {e}")
            return None
    
    async def execute_swap(self, input_mint: str, output_mint: str, amount: float, wallet_address: str) -> Optional[Dict]:
        """Execute swap via Jupiter (simulation for free version)"""
        try:
            # For the free version, we'll simulate the swap
            # In production, this would use actual Solana transactions
            
            quote = await self.get_quote(input_mint, output_mint, amount)
            if not quote:
                return None
            
            # Simulate execution delay
            await asyncio.sleep(0.1)
            
            # Calculate simulated results
            output_amount = float(quote.get('outAmount', 0)) / 1_000_000_000  # Convert from lamports
            price = amount / output_amount if output_amount > 0 else 0
            fee = amount * 0.003  # 0.3% fee simulation
            slippage = 0.5  # 0.5% slippage simulation
            
            # Generate mock transaction signature
            mock_signature = f"sim_{int(datetime.utcnow().timestamp())}_{hash(wallet_address)%1000000}"
            
            result = {
                'signature': mock_signature,
                'output_amount': output_amount,
                'price': price,
                'fee': fee,
                'slippage': slippage,
                'success': True,
                'simulation': True  # Mark as simulation
            }
            
            logger.info(f"Simulated swap: {amount} {input_mint[:8]}... -> {output_amount:.6f} {output_mint[:8]}...")
            return result
            
        except Exception as e:
            logger.error(f"Error executing swap: {e}")
            return None
    
    async def get_token_price(self, mint_address: str) -> Optional[float]:
        """Get current token price"""
        try:
            session = await self._get_session()
            
            # Get price via Jupiter's price API
            params = {
                'ids': mint_address
            }
            
            async with session.get(f"{self.api_url}/price", params=params) as response:
                if response.status == 200:
                    data = await response.json()
                    price_data = data.get('data', {}).get(mint_address)
                    if price_data:
                        return float(price_data.get('price', 0))
                
                # Fallback: simulate price movement
                import random
                base_price = 0.001  # Base price for simulation
                return base_price * (0.8 + random.random() * 0.4)  # ±20% variation
                
        except Exception as e:
            logger.error(f"Error getting token price: {e}")
            return None
    
    async def get_token_info(self, mint_address: str) -> Optional[Dict]:
        """Get token information"""
        try:
            session = await self._get_session()
            
            # For simulation, return mock data
            # In production, this would fetch real token metadata
            return {
                'mint': mint_address,
                'symbol': f"TOKEN{mint_address[-4:].upper()}",
                'name': f"Meme Token {mint_address[-4:]}",
                'decimals': 9,
                'supply': 1000000000,
                'price': await self.get_token_price(mint_address),
                'simulation': True
            }
            
        except Exception as e:
            logger.error(f"Error getting token info: {e}")
            return None
    
    def _process_quote_response(self, data: Dict) -> Dict:
        """Process Jupiter quote response"""
        try:
            return {
                'inputMint': data.get('inputMint'),
                'outputMint': data.get('outputMint'),
                'inAmount': data.get('inAmount'),
                'outAmount': data.get('outAmount'),
                'priceImpactPct': data.get('priceImpactPct', 0),
                'routePlan': data.get('routePlan', []),
                'slippageBps': data.get('slippageBps', 50)
            }
        except Exception as e:
            logger.error(f"Error processing quote response: {e}")
            return {}
    
    async def get_supported_tokens(self) -> List[Dict]:
        """Get list of supported tokens"""
        try:
            session = await self._get_session()
            
            async with session.get(f"{self.api_url}/tokens") as response:
                if response.status == 200:
                    data = await response.json()
                    return data
                else:
                    logger.error(f"Failed to get supported tokens: {response.status}")
                    return []
                    
        except Exception as e:
            logger.error(f"Error getting supported tokens: {e}")
            return []