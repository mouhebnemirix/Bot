import asyncio
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
import json
import aiohttp
import random

from database.connection import Database
from utils.websocket_manager import WebSocketManager
from utils.config import config
from blockchain.jupiter_integration import JupiterClient

logger = logging.getLogger(__name__)

class SolanaMonitor:
    """Monitor Solana blockchain for new meme coins and market data"""
    
    def __init__(self, db: Database, websocket_manager: WebSocketManager):
        self.db = db
        self.websocket_manager = websocket_manager
        self.jupiter_client = JupiterClient()
        self.session = None
        self.is_running = False
        
        # Track discovered tokens
        self.monitored_tokens = set()
        self.new_token_queue = asyncio.Queue()
        
        logger.info("Solana monitor initialized")
    
    async def start_monitoring(self):
        """Start monitoring Solana blockchain"""
        self.is_running = True
        self.session = aiohttp.ClientSession()
        
        logger.info("Starting Solana blockchain monitoring...")
        
        # Start monitoring tasks
        asyncio.create_task(self._monitor_new_tokens())
        asyncio.create_task(self._monitor_market_data())
        asyncio.create_task(self._process_new_tokens())
        asyncio.create_task(self._simulate_new_token_discovery())
        
        await self.websocket_manager.broadcast_alert({
            "type": "info",
            "message": "Solana blockchain monitoring started",
            "timestamp": datetime.utcnow().isoformat()
        })
    
    async def stop(self):
        """Stop monitoring"""
        self.is_running = False
        if self.session:
            await self.session.close()
        await self.jupiter_client.close()
        logger.info("Solana monitoring stopped")
    
    async def _monitor_new_tokens(self):
        """Monitor for new token creation"""
        while self.is_running:
            try:
                # In a real implementation, this would monitor Solana transactions
                # for InitializeMint instructions and new liquidity pool creation
                
                # For now, we'll simulate new token discovery
                await asyncio.sleep(30)  # Check every 30 seconds
                
            except Exception as e:
                logger.error(f"Error monitoring new tokens: {e}")
                await asyncio.sleep(60)
    
    async def _simulate_new_token_discovery(self):
        """Simulate discovering new meme coins (for demo purposes)"""
        sample_tokens = [
            {
                "mint_address": "DogeCoinSol123456789012345678901234567890",
                "symbol": "DOGES",
                "name": "Doge Coin Solana",
                "decimals": 9,
                "initial_liquidity": 25000,
                "creator": "DogeTeamSOL"
            },
            {
                "mint_address": "PepeCoinSol123456789012345678901234567890",
                "symbol": "PEPES",
                "name": "Pepe on Solana",
                "decimals": 9,
                "initial_liquidity": 15000,
                "creator": "PepeArmy"
            },
            {
                "mint_address": "ShibaCoinSol12345678901234567890123456789",
                "symbol": "SHIBAS",
                "name": "Shiba Solana Inu",
                "decimals": 9,
                "initial_liquidity": 40000,
                "creator": "ShibaSOLTeam"
            },
            {
                "mint_address": "FlokiCoinSol12345678901234567890123456789",
                "symbol": "FLOKIS",
                "name": "Floki Solana",
                "decimals": 9,
                "initial_liquidity": 18000,
                "creator": "FlokiSOL"
            },
            {
                "mint_address": "BonkCoinSol123456789012345678901234567890",
                "symbol": "BONKS",
                "name": "Bonk Solana Meme",
                "decimals": 9,
                "initial_liquidity": 35000,
                "creator": "BonkSOLTeam"
            }
        ]
        
        while self.is_running:
            try:
                # Randomly "discover" a new token
                if random.random() < 0.3:  # 30% chance every interval
                    token = random.choice(sample_tokens)
                    
                    # Check if we've already discovered this token
                    existing = await self.db.get_token_by_mint(token["mint_address"])
                    if not existing:
                        await self.new_token_queue.put(token)
                        logger.info(f"New token discovered: {token['symbol']} ({token['name']})")
                
                await asyncio.sleep(120)  # Check every 2 minutes
                
            except Exception as e:
                logger.error(f"Error in token discovery simulation: {e}")
                await asyncio.sleep(300)
    
    async def _process_new_tokens(self):
        """Process newly discovered tokens"""
        while self.is_running:
            try:
                # Get new token from queue
                token_data = await asyncio.wait_for(self.new_token_queue.get(), timeout=10)
                
                # Process the new token
                await self._analyze_new_token(token_data)
                
            except asyncio.TimeoutError:
                continue
            except Exception as e:
                logger.error(f"Error processing new token: {e}")
                await asyncio.sleep(30)
    
    async def _analyze_new_token(self, token_data: Dict):
        """Analyze a newly discovered token"""
        try:
            mint_address = token_data["mint_address"]
            
            # Get initial market data
            market_data = await self._fetch_token_market_data(mint_address)
            
            # Determine if it's likely a meme coin
            is_meme_coin = self._classify_as_meme_coin(token_data, market_data)
            
            # Create token record
            token_record = {
                "mint_address": mint_address,
                "symbol": token_data.get("symbol"),
                "name": token_data.get("name"),
                "decimals": token_data.get("decimals", 9),
                "total_supply": market_data.get("total_supply", 1000000000),
                "market_cap": market_data.get("market_cap", 0),
                "price_usd": market_data.get("price_usd", 0.001),
                "volume_24h": market_data.get("volume_24h", 0),
                "holders_count": market_data.get("holders_count", 1),
                "is_verified": False,
                "is_meme_coin": is_meme_coin,
                "liquidity_usd": token_data.get("initial_liquidity", 0),
                "metadata": {
                    "creator": token_data.get("creator"),
                    "discovery_time": datetime.utcnow().isoformat(),
                    "initial_analysis": market_data
                }
            }
            
            # Save to database
            token_id = await self.db.insert_token(token_record)
            
            # Add to monitoring list
            self.monitored_tokens.add(mint_address)
            
            # Broadcast new token alert
            await self.websocket_manager.broadcast_alert({
                "type": "new_token",
                "data": {
                    **token_record,
                    "token_id": token_id
                },
                "message": f"New {'meme coin' if is_meme_coin else 'token'} discovered: {token_data.get('symbol')}",
                "timestamp": datetime.utcnow().isoformat()
            })
            
            logger.info(f"New token analyzed and saved: {token_data.get('symbol')} (ID: {token_id})")
            
        except Exception as e:
            logger.error(f"Error analyzing new token: {e}")
    
    async def _fetch_token_market_data(self, mint_address: str) -> Dict:
        """Fetch market data for a token"""
        try:
            # Get price from Jupiter
            price = await self.jupiter_client.get_token_price(mint_address)
            
            # Simulate other market data
            market_data = {
                "price_usd": price or random.uniform(0.0001, 0.01),
                "volume_24h": random.uniform(1000, 50000),
                "market_cap": random.uniform(10000, 500000),
                "price_change_1h": random.uniform(-10, 10),
                "price_change_24h": random.uniform(-25, 25),
                "liquidity_usd": random.uniform(5000, 100000),
                "holders_count": random.randint(50, 1000),
                "total_supply": 1000000000,  # 1B tokens typical for meme coins
                "dex_name": "Raydium",
                "pool_address": f"pool_{mint_address[:8]}"
            }
            
            return market_data
            
        except Exception as e:
            logger.error(f"Error fetching market data: {e}")
            return {}
    
    def _classify_as_meme_coin(self, token_data: Dict, market_data: Dict) -> bool:
        """Classify if token is likely a meme coin"""
        try:
            # Meme coin indicators
            name = token_data.get("name", "").lower()
            symbol = token_data.get("symbol", "").lower()
            
            meme_keywords = [
                "doge", "pepe", "shiba", "inu", "floki", "bonk",
                "moon", "rocket", "meme", "dog", "cat", "frog",
                "elon", "safe", "baby", "mini", "x", "coin"
            ]
            
            # Check for meme keywords
            has_meme_keywords = any(keyword in name or keyword in symbol for keyword in meme_keywords)
            
            # Check token characteristics
            has_high_supply = market_data.get("total_supply", 0) >= 100000000  # 100M+
            has_low_price = market_data.get("price_usd", 1) < 0.01  # Less than 1 cent
            
            # Classify as meme coin if it has meme characteristics
            is_meme = has_meme_keywords or (has_high_supply and has_low_price)
            
            return is_meme
            
        except Exception as e:
            logger.error(f"Error classifying token: {e}")
            return True  # Default to meme coin for our bot
    
    async def _monitor_market_data(self):
        """Monitor market data for tracked tokens"""
        while self.is_running:
            try:
                # Get all tokens we're monitoring
                tokens = await self.db.execute_query(
                    "SELECT mint_address FROM tokens WHERE is_meme_coin = 1 LIMIT 50"
                )
                
                # Update market data for each token
                for token in tokens:
                    if not self.is_running:
                        break
                    
                    await self._update_token_market_data(token["mint_address"])
                    await asyncio.sleep(1)  # Small delay between updates
                
                await asyncio.sleep(config.PRICE_UPDATE_INTERVAL)
                
            except Exception as e:
                logger.error(f"Error monitoring market data: {e}")
                await asyncio.sleep(30)
    
    async def _update_token_market_data(self, mint_address: str):
        """Update market data for a specific token"""
        try:
            # Fetch current market data
            market_data = await self._fetch_token_market_data(mint_address)
            
            if not market_data:
                return
            
            # Save market data snapshot
            await self.db.execute_insert(
                """
                INSERT INTO market_data 
                (mint_address, price_usd, volume_24h, market_cap, price_change_1h,
                 price_change_24h, liquidity_usd, holders_count, dex_name, pool_address)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    mint_address,
                    market_data.get("price_usd"),
                    market_data.get("volume_24h"),
                    market_data.get("market_cap"),
                    market_data.get("price_change_1h"),
                    market_data.get("price_change_24h"),
                    market_data.get("liquidity_usd"),
                    market_data.get("holders_count"),
                    market_data.get("dex_name"),
                    market_data.get("pool_address")
                )
            )
            
            # Update token's current price
            await self.db.execute_update(
                """
                UPDATE tokens 
                SET price_usd = ?, volume_24h = ?, market_cap = ?, 
                    holders_count = ?, liquidity_usd = ?, updated_at = CURRENT_TIMESTAMP
                WHERE mint_address = ?
                """,
                (
                    market_data.get("price_usd"),
                    market_data.get("volume_24h"),
                    market_data.get("market_cap"),
                    market_data.get("holders_count"),
                    market_data.get("liquidity_usd"),
                    mint_address
                )
            )
            
            # Broadcast price update
            await self.websocket_manager.broadcast_price_update({
                "mint_address": mint_address,
                "price_usd": market_data.get("price_usd"),
                "price_change_24h": market_data.get("price_change_24h"),
                "volume_24h": market_data.get("volume_24h"),
                "market_cap": market_data.get("market_cap"),
                "timestamp": datetime.utcnow().isoformat()
            })
            
        except Exception as e:
            logger.error(f"Error updating market data for {mint_address}: {e}")
    
    async def get_trending_tokens(self, limit: int = 10) -> List[Dict]:
        """Get trending tokens by volume and price movement"""
        try:
            cutoff_time = datetime.utcnow() - timedelta(hours=6)
            
            trending = await self.db.execute_query(
                """
                SELECT t.*, md.price_change_24h, md.volume_24h
                FROM tokens t
                LEFT JOIN market_data md ON t.mint_address = md.mint_address
                WHERE t.is_meme_coin = 1 
                AND md.timestamp >= ?
                AND md.volume_24h > 5000
                ORDER BY (md.price_change_24h * md.volume_24h) DESC
                LIMIT ?
                """,
                (cutoff_time, limit)
            )
            
            return trending
            
        except Exception as e:
            logger.error(f"Error getting trending tokens: {e}")
            return []
    
    async def get_new_tokens(self, hours: int = 24, limit: int = 20) -> List[Dict]:
        """Get recently discovered tokens"""
        try:
            cutoff_time = datetime.utcnow() - timedelta(hours=hours)
            
            new_tokens = await self.db.execute_query(
                """
                SELECT * FROM tokens 
                WHERE is_meme_coin = 1 AND created_at >= ?
                ORDER BY created_at DESC
                LIMIT ?
                """,
                (cutoff_time, limit)
            )
            
            return new_tokens
            
        except Exception as e:
            logger.error(f"Error getting new tokens: {e}")
            return []
    
    async def analyze_token_potential(self, mint_address: str) -> Dict[str, Any]:
        """Analyze a token's potential based on various metrics"""
        try:
            # Get token info
            token = await self.db.get_token_by_mint(mint_address)
            if not token:
                return {"error": "Token not found"}
            
            # Get recent market data
            market_data = await self.db.execute_query(
                """
                SELECT * FROM market_data 
                WHERE mint_address = ? 
                ORDER BY timestamp DESC LIMIT 24
                """,
                (mint_address,)
            )
            
            if not market_data:
                return {"error": "No market data available"}
            
            latest = market_data[0]
            
            # Calculate trend metrics
            price_trend = self._calculate_price_trend(market_data)
            volume_trend = self._calculate_volume_trend(market_data)
            
            # Liquidity analysis
            liquidity_score = min(latest.get('liquidity_usd', 0) / 100000, 1.0)  # Score out of 1.0
            
            # Holder growth (simulated)
            holder_score = min(latest.get('holders_count', 0) / 10000, 1.0)
            
            # Overall potential score
            potential_score = (
                price_trend * 0.3 +
                volume_trend * 0.3 +
                liquidity_score * 0.2 +
                holder_score * 0.2
            )
            
            return {
                "mint_address": mint_address,
                "symbol": token.get('symbol'),
                "name": token.get('name'),
                "potential_score": potential_score,
                "price_trend": price_trend,
                "volume_trend": volume_trend,
                "liquidity_score": liquidity_score,
                "holder_score": holder_score,
                "current_price": latest.get('price_usd'),
                "market_cap": latest.get('market_cap'),
                "volume_24h": latest.get('volume_24h'),
                "analysis_time": datetime.utcnow().isoformat()
            }
            
        except Exception as e:
            logger.error(f"Error analyzing token potential: {e}")
            return {"error": str(e)}
    
    def _calculate_price_trend(self, market_data: List[Dict]) -> float:
        """Calculate price trend score (0-1)"""
        try:
            if len(market_data) < 2:
                return 0.5
            
            prices = [float(md.get('price_usd', 0)) for md in market_data]
            
            # Calculate simple moving average trend
            if len(prices) >= 6:
                recent_avg = sum(prices[:6]) / 6
                older_avg = sum(prices[6:12]) / min(6, len(prices) - 6) if len(prices) > 6 else recent_avg
                
                if older_avg > 0:
                    trend = (recent_avg - older_avg) / older_avg
                    return max(0, min(1, 0.5 + trend))  # Normalize to 0-1
            
            return 0.5
            
        except Exception:
            return 0.5
    
    def _calculate_volume_trend(self, market_data: List[Dict]) -> float:
        """Calculate volume trend score (0-1)"""
        try:
            if len(market_data) < 2:
                return 0.5
            
            volumes = [float(md.get('volume_24h', 0)) for md in market_data]
            
            # Check if volume is increasing
            if len(volumes) >= 3:
                recent_volume = sum(volumes[:3]) / 3
                older_volume = sum(volumes[3:6]) / min(3, len(volumes) - 3) if len(volumes) > 3 else recent_volume
                
                if older_volume > 0:
                    volume_growth = (recent_volume - older_volume) / older_volume
                    return max(0, min(1, 0.5 + volume_growth * 0.5))
            
            return 0.5
            
        except Exception:
            return 0.5