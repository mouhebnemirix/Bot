from fastapi import APIRouter, HTTPException, Query, Path
from typing import Dict, List, Optional, Any
from datetime import datetime, timedelta
import logging

from database.connection import Database
from trading.engine import TradingEngine
from sentiment.analyzer import SentimentAnalyzer
from blockchain.solana_monitor import SolanaMonitor
from trading.portfolio_manager import PortfolioManager
from trading.risk_manager import RiskManager
from notifications.telegram_bot import TelegramNotifier
from utils.config import config

logger = logging.getLogger(__name__)

router = APIRouter()

# Global instances (will be injected from main.py)
db: Database = None
trading_engine: TradingEngine = None
sentiment_analyzer: SentimentAnalyzer = None
solana_monitor: SolanaMonitor = None
portfolio_manager: PortfolioManager = None
risk_manager: RiskManager = None
telegram_notifier: TelegramNotifier = None

# Portfolio endpoints
@router.get("/portfolio/overview")
async def get_portfolio_overview():
    """Get portfolio overview with current stats"""
    try:
        if not portfolio_manager:
            raise HTTPException(status_code=503, detail="Portfolio manager not available")
        
        # Get current portfolio stats
        stats = await portfolio_manager._calculate_portfolio_stats()
        
        return {
            "success": True,
            "data": {
                "total_value": stats.total_value,
                "total_pnl": stats.total_pnl,
                "total_pnl_percentage": stats.total_pnl_percentage,
                "win_rate": stats.win_rate,
                "total_trades": stats.total_trades,
                "winning_trades": stats.winning_trades,
                "losing_trades": stats.losing_trades,
                "largest_win": stats.largest_win,
                "largest_loss": stats.largest_loss,
                "sharpe_ratio": stats.sharpe_ratio,
                "max_drawdown": stats.max_drawdown,
                "daily_return": stats.daily_return,
                "timestamp": datetime.utcnow().isoformat()
            }
        }
    except Exception as e:
        logger.error(f"Error getting portfolio overview: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/portfolio/positions")
async def get_active_positions(
    wallet_id: Optional[int] = Query(None, description="Filter by wallet ID")
):
    """Get active positions"""
    try:
        if not db:
            raise HTTPException(status_code=503, detail="Database not available")
        
        positions = await db.get_active_positions(wallet_id)
        
        # Enhance with token information
        enhanced_positions = []
        for position in positions:
            # Get token info
            token = await db.get_token_by_mint(position['mint_address'])
            
            enhanced_position = {
                **position,
                "token_symbol": token.get('symbol') if token else 'UNKNOWN',
                "token_name": token.get('name') if token else 'Unknown Token',
                "unrealized_pnl": (position.get('current_price', 0) - position.get('entry_price', 0)) * position.get('amount', 0)
            }
            enhanced_positions.append(enhanced_position)
        
        return {
            "success": True,
            "data": enhanced_positions,
            "count": len(enhanced_positions)
        }
    except Exception as e:
        logger.error(f"Error getting active positions: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/portfolio/performance")
async def get_performance_summary(
    days: int = Query(7, ge=1, le=365, description="Number of days to analyze")
):
    """Get performance summary for specified period"""
    try:
        if not portfolio_manager:
            raise HTTPException(status_code=503, detail="Portfolio manager not available")
        
        summary = await portfolio_manager.get_performance_summary(days)
        
        return {
            "success": True,
            "data": summary
        }
    except Exception as e:
        logger.error(f"Error getting performance summary: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# Trading endpoints
@router.get("/trading/signals")
async def get_trading_signals(
    limit: int = Query(10, ge=1, le=50, description="Number of signals to return")
):
    """Get latest trading signals"""
    try:
        if not db:
            raise HTTPException(status_code=503, detail="Database not available")
        
        signals = await db.execute_query(
            """
            SELECT * FROM trading_signals 
            WHERE expires_at > CURRENT_TIMESTAMP OR expires_at IS NULL
            ORDER BY created_at DESC
            LIMIT ?
            """,
            (limit,)
        )
        
        return {
            "success": True,
            "data": signals,
            "count": len(signals)
        }
    except Exception as e:
        logger.error(f"Error getting trading signals: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/trading/trades")
async def get_recent_trades(
    limit: int = Query(20, ge=1, le=100, description="Number of trades to return"),
    wallet_id: Optional[int] = Query(None, description="Filter by wallet ID")
):
    """Get recent trades"""
    try:
        if not db:
            raise HTTPException(status_code=503, detail="Database not available")
        
        query = "SELECT * FROM trades"
        params = []
        
        if wallet_id:
            query += " WHERE wallet_id = ?"
            params.append(wallet_id)
        
        query += " ORDER BY created_at DESC LIMIT ?"
        params.append(limit)
        
        trades = await db.execute_query(query, tuple(params))
        
        # Enhance with token information
        enhanced_trades = []
        for trade in trades:
            token = await db.get_token_by_mint(trade['mint_address'])
            
            enhanced_trade = {
                **trade,
                "token_symbol": token.get('symbol') if token else 'UNKNOWN',
                "token_name": token.get('name') if token else 'Unknown Token'
            }
            enhanced_trades.append(enhanced_trade)
        
        return {
            "success": True,
            "data": enhanced_trades,
            "count": len(enhanced_trades)
        }
    except Exception as e:
        logger.error(f"Error getting recent trades: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# Market data endpoints
@router.get("/market/tokens")
async def get_tokens(
    limit: int = Query(50, ge=1, le=200, description="Number of tokens to return"),
    meme_only: bool = Query(True, description="Only return meme coins"),
    sort_by: str = Query("volume_24h", description="Sort by: volume_24h, market_cap, price_change_24h")
):
    """Get tokens with market data"""
    try:
        if not db:
            raise HTTPException(status_code=503, detail="Database not available")
        
        # Build query based on parameters
        query = "SELECT * FROM tokens"
        params = []
        
        if meme_only:
            query += " WHERE is_meme_coin = 1"
        
        # Add sorting
        if sort_by in ["volume_24h", "market_cap", "price_usd"]:
            query += f" ORDER BY {sort_by} DESC"
        else:
            query += " ORDER BY updated_at DESC"
        
        query += " LIMIT ?"
        params.append(limit)
        
        tokens = await db.execute_query(query, tuple(params))
        
        return {
            "success": True,
            "data": tokens,
            "count": len(tokens)
        }
    except Exception as e:
        logger.error(f"Error getting tokens: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/market/tokens/{mint_address}")
async def get_token_details(mint_address: str = Path(..., description="Token mint address")):
    """Get detailed token information"""
    try:
        if not db:
            raise HTTPException(status_code=503, detail="Database not available")
        
        # Get token info
        token = await db.get_token_by_mint(mint_address)
        if not token:
            raise HTTPException(status_code=404, detail="Token not found")
        
        # Get recent market data
        market_data = await db.execute_query(
            """
            SELECT * FROM market_data 
            WHERE mint_address = ? 
            ORDER BY timestamp DESC LIMIT 24
            """,
            (mint_address,)
        )
        
        # Get sentiment data
        sentiment_data = await sentiment_analyzer.get_token_sentiment(mint_address) if sentiment_analyzer else {}
        
        # Get trading activity
        recent_trades = await db.execute_query(
            "SELECT * FROM trades WHERE mint_address = ? ORDER BY created_at DESC LIMIT 10",
            (mint_address,)
        )
        
        return {
            "success": True,
            "data": {
                "token": token,
                "market_data": market_data,
                "sentiment": sentiment_data,
                "recent_trades": recent_trades
            }
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting token details: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/market/trending")
async def get_trending_tokens(
    limit: int = Query(10, ge=1, le=50, description="Number of trending tokens")
):
    """Get trending tokens"""
    try:
        if not solana_monitor:
            raise HTTPException(status_code=503, detail="Solana monitor not available")
        
        trending = await solana_monitor.get_trending_tokens(limit)
        
        return {
            "success": True,
            "data": trending,
            "count": len(trending)
        }
    except Exception as e:
        logger.error(f"Error getting trending tokens: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/market/new-tokens")
async def get_new_tokens(
    hours: int = Query(24, ge=1, le=168, description="Hours to look back"),
    limit: int = Query(20, ge=1, le=100, description="Number of tokens to return")
):
    """Get newly discovered tokens"""
    try:
        if not solana_monitor:
            raise HTTPException(status_code=503, detail="Solana monitor not available")
        
        new_tokens = await solana_monitor.get_new_tokens(hours, limit)
        
        return {
            "success": True,
            "data": new_tokens,
            "count": len(new_tokens)
        }
    except Exception as e:
        logger.error(f"Error getting new tokens: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# Sentiment endpoints
@router.get("/sentiment/overview")
async def get_sentiment_overview():
    """Get overall sentiment overview"""
    try:
        if not sentiment_analyzer:
            raise HTTPException(status_code=503, detail="Sentiment analyzer not available")
        
        trending_tokens = await sentiment_analyzer.get_trending_tokens(10)
        
        return {
            "success": True,
            "data": {
                "trending_tokens": trending_tokens,
                "timestamp": datetime.utcnow().isoformat()
            }
        }
    except Exception as e:
        logger.error(f"Error getting sentiment overview: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/sentiment/tokens/{mint_address}")
async def get_token_sentiment(
    mint_address: str = Path(..., description="Token mint address"),
    hours: int = Query(24, ge=1, le=168, description="Hours to analyze")
):
    """Get sentiment analysis for specific token"""
    try:
        if not sentiment_analyzer:
            raise HTTPException(status_code=503, detail="Sentiment analyzer not available")
        
        sentiment = await sentiment_analyzer.get_token_sentiment(mint_address, hours)
        
        return {
            "success": True,
            "data": sentiment
        }
    except Exception as e:
        logger.error(f"Error getting token sentiment: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# Risk management endpoints
@router.get("/risk/report")
async def get_risk_report():
    """Get comprehensive risk report"""
    try:
        if not risk_manager:
            raise HTTPException(status_code=503, detail="Risk manager not available")
        
        report = await risk_manager.get_risk_report()
        
        return {
            "success": True,
            "data": report
        }
    except Exception as e:
        logger.error(f"Error getting risk report: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# System endpoints
@router.get("/system/status")
async def get_system_status():
    """Get system status and health"""
    try:
        return {
            "success": True,
            "data": {
                "status": "operational",
                "services": {
                    "database": "connected" if db else "disconnected",
                    "trading_engine": "running" if trading_engine and trading_engine.is_running else "stopped",
                    "sentiment_analyzer": "running" if sentiment_analyzer and sentiment_analyzer.is_running else "stopped",
                    "solana_monitor": "running" if solana_monitor and solana_monitor.is_running else "stopped",
                    "telegram_notifier": "enabled" if telegram_notifier and telegram_notifier.enabled else "disabled"
                },
                "config": {
                    "initial_capital": config.INITIAL_CAPITAL,
                    "max_position_size": config.MAX_POSITION_SIZE,
                    "max_daily_trades": config.MAX_DAILY_TRADES,
                    "price_update_interval": config.PRICE_UPDATE_INTERVAL
                },
                "timestamp": datetime.utcnow().isoformat()
            }
        }
    except Exception as e:
        logger.error(f"Error getting system status: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/system/test-telegram")
async def test_telegram_connection():
    """Test Telegram notification"""
    try:
        if not telegram_notifier:
            raise HTTPException(status_code=503, detail="Telegram notifier not available")
        
        success = await telegram_notifier.test_connection()
        
        return {
            "success": success,
            "message": "Test message sent successfully" if success else "Failed to send test message"
        }
    except Exception as e:
        logger.error(f"Error testing Telegram: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# Analytics endpoints
@router.get("/analytics/performance")
async def get_performance_analytics(
    period: str = Query("7d", description="Time period: 1d, 7d, 30d"),
):
    """Get detailed performance analytics"""
    try:
        if not db:
            raise HTTPException(status_code=503, detail="Database not available")
        
        # Parse period
        period_map = {
            "1d": 1,
            "7d": 7,
            "30d": 30
        }
        
        days = period_map.get(period, 7)
        cutoff_date = datetime.utcnow() - timedelta(days=days)
        
        # Get portfolio metrics
        metrics = await db.execute_query(
            "SELECT * FROM portfolio_metrics WHERE timestamp >= ? ORDER BY timestamp",
            (cutoff_date,)
        )
        
        # Get trade distribution
        trade_distribution = await db.execute_query(
            """
            SELECT 
                DATE(created_at) as trade_date,
                COUNT(*) as trade_count,
                SUM(CASE WHEN trade_type = 'buy' THEN value_usd ELSE 0 END) as buy_volume,
                SUM(CASE WHEN trade_type = 'sell' THEN value_usd ELSE 0 END) as sell_volume
            FROM trades 
            WHERE created_at >= ?
            GROUP BY DATE(created_at)
            ORDER BY trade_date
            """,
            (cutoff_date,)
        )
        
        return {
            "success": True,
            "data": {
                "period": period,
                "metrics_history": metrics,
                "trade_distribution": trade_distribution,
                "summary": {
                    "total_metrics": len(metrics),
                    "trading_days": len(trade_distribution)
                }
            }
        }
    except Exception as e:
        logger.error(f"Error getting performance analytics: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# Initialize global instances (called from main.py)
def init_routes(
    database: Database,
    engine: TradingEngine,
    analyzer: SentimentAnalyzer,
    monitor: SolanaMonitor,
    portfolio_mgr: PortfolioManager,
    risk_mgr: RiskManager,
    notifier: TelegramNotifier
):
    """Initialize route dependencies"""
    global db, trading_engine, sentiment_analyzer, solana_monitor
    global portfolio_manager, risk_manager, telegram_notifier
    
    db = database
    trading_engine = engine
    sentiment_analyzer = analyzer
    solana_monitor = monitor
    portfolio_manager = portfolio_mgr
    risk_manager = risk_mgr
    telegram_notifier = notifier
    
    logger.info("API routes initialized with dependencies")