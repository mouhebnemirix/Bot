from fastapi import WebSocket
from typing import List, Dict, Any
import json
import logging
import asyncio
from datetime import datetime

logger = logging.getLogger(__name__)

class WebSocketManager:
    def __init__(self):
        self.active_connections: List[WebSocket] = []
        self.connection_info: Dict[WebSocket, Dict] = {}
    
    async def connect(self, websocket: WebSocket):
        """Accept a new WebSocket connection"""
        await websocket.accept()
        self.active_connections.append(websocket)
        self.connection_info[websocket] = {
            "connected_at": datetime.utcnow(),
            "last_ping": datetime.utcnow()
        }
        logger.info(f"New WebSocket connection. Total: {len(self.active_connections)}")
        
        # Send welcome message
        await self.send_to_connection(websocket, {
            "type": "connection",
            "status": "connected",
            "timestamp": datetime.utcnow().isoformat()
        })
    
    def disconnect(self, websocket: WebSocket):
        """Remove a WebSocket connection"""
        if websocket in self.active_connections:
            self.active_connections.remove(websocket)
            if websocket in self.connection_info:
                del self.connection_info[websocket]
            logger.info(f"WebSocket disconnected. Total: {len(self.active_connections)}")
    
    async def send_to_connection(self, websocket: WebSocket, data: Dict[str, Any]):
        """Send data to a specific WebSocket connection"""
        try:
            await websocket.send_text(json.dumps(data))
        except Exception as e:
            logger.error(f"Error sending data to WebSocket: {e}")
            self.disconnect(websocket)
    
    async def broadcast(self, data: Dict[str, Any]):
        """Broadcast data to all connected WebSocket clients"""
        if not self.active_connections:
            return
        
        # Add timestamp if not present
        if "timestamp" not in data:
            data["timestamp"] = datetime.utcnow().isoformat()
        
        disconnected = []
        for connection in self.active_connections:
            try:
                await connection.send_text(json.dumps(data))
            except Exception as e:
                logger.error(f"Error broadcasting to WebSocket: {e}")
                disconnected.append(connection)
        
        # Remove disconnected connections
        for connection in disconnected:
            self.disconnect(connection)
    
    async def broadcast_trade_update(self, trade_data: Dict[str, Any]):
        """Broadcast trade update to all clients"""
        await self.broadcast({
            "type": "trade_update",
            "data": trade_data
        })
    
    async def broadcast_price_update(self, price_data: Dict[str, Any]):
        """Broadcast price update to all clients"""
        await self.broadcast({
            "type": "price_update",
            "data": price_data
        })
    
    async def broadcast_portfolio_update(self, portfolio_data: Dict[str, Any]):
        """Broadcast portfolio update to all clients"""
        await self.broadcast({
            "type": "portfolio_update",
            "data": portfolio_data
        })
    
    async def broadcast_sentiment_update(self, sentiment_data: Dict[str, Any]):
        """Broadcast sentiment update to all clients"""
        await self.broadcast({
            "type": "sentiment_update",
            "data": sentiment_data
        })
    
    async def broadcast_signal_update(self, signal_data: Dict[str, Any]):
        """Broadcast trading signal to all clients"""
        await self.broadcast({
            "type": "signal_update",
            "data": signal_data
        })
    
    async def broadcast_alert(self, alert_data: Dict[str, Any]):
        """Broadcast alert to all clients"""
        await self.broadcast({
            "type": "alert",
            "data": alert_data
        })
    
    async def ping_all_connections(self):
        """Send ping to all connections to keep them alive"""
        ping_data = {
            "type": "ping",
            "timestamp": datetime.utcnow().isoformat()
        }
        await self.broadcast(ping_data)
    
    def get_connection_count(self) -> int:
        """Get number of active connections"""
        return len(self.active_connections)
    
    def get_connection_stats(self) -> Dict[str, Any]:
        """Get connection statistics"""
        return {
            "total_connections": len(self.active_connections),
            "connections": [
                {
                    "connected_at": info["connected_at"].isoformat(),
                    "last_ping": info["last_ping"].isoformat()
                }
                for info in self.connection_info.values()
            ]
        }