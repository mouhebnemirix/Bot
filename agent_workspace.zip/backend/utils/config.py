import os
from typing import Dict, Any
from dataclasses import dataclass
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

@dataclass
class Config:
    """Configuration settings for the trading bot"""
    
    # Database settings
    DATABASE_URL: str = "data/trading_bot.db"
    
    # Solana settings
    SOLANA_RPC_URL: str = os.getenv("SOLANA_RPC_URL", "https://api.mainnet-beta.solana.com")
    SOLANA_WS_URL: str = os.getenv("SOLANA_WS_URL", "wss://api.mainnet-beta.solana.com")
    
    # Trading settings
    INITIAL_CAPITAL: float = float(os.getenv("INITIAL_CAPITAL", "1.0"))  # $1 starting capital
    MAX_POSITION_SIZE: float = float(os.getenv("MAX_POSITION_SIZE", "0.1"))  # 10% max per position
    STOP_LOSS_PERCENTAGE: float = float(os.getenv("STOP_LOSS_PERCENTAGE", "0.05"))  # 5% stop loss
    TAKE_PROFIT_PERCENTAGE: float = float(os.getenv("TAKE_PROFIT_PERCENTAGE", "0.20"))  # 20% take profit
    
    # Risk management
    MAX_DAILY_TRADES: int = int(os.getenv("MAX_DAILY_TRADES", "50"))
    MAX_CONCURRENT_POSITIONS: int = int(os.getenv("MAX_CONCURRENT_POSITIONS", "10"))
    RISK_PER_TRADE: float = float(os.getenv("RISK_PER_TRADE", "0.02"))  # 2% risk per trade
    
    # Sentiment analysis settings
    MIN_SENTIMENT_SCORE: float = float(os.getenv("MIN_SENTIMENT_SCORE", "0.6"))
    MIN_CONFIDENCE_SCORE: float = float(os.getenv("MIN_CONFIDENCE_SCORE", "0.7"))
    SENTIMENT_WEIGHT: float = float(os.getenv("SENTIMENT_WEIGHT", "0.4"))
    TECHNICAL_WEIGHT: float = float(os.getenv("TECHNICAL_WEIGHT", "0.4"))
    VOLUME_WEIGHT: float = float(os.getenv("VOLUME_WEIGHT", "0.2"))
    
    # Social media settings
    TWITTER_BEARER_TOKEN: str = os.getenv("TWITTER_BEARER_TOKEN", "")
    REDDIT_CLIENT_ID: str = os.getenv("REDDIT_CLIENT_ID", "")
    REDDIT_CLIENT_SECRET: str = os.getenv("REDDIT_CLIENT_SECRET", "")
    REDDIT_USER_AGENT: str = os.getenv("REDDIT_USER_AGENT", "SolanaBot:v1.0")
    
    # Telegram settings
    TELEGRAM_BOT_TOKEN: str = os.getenv("TELEGRAM_BOT_TOKEN", "")
    TELEGRAM_CHAT_ID: str = os.getenv("TELEGRAM_CHAT_ID", "")
    
    # API settings
    JUPITER_API_URL: str = "https://quote-api.jup.ag/v6"
    RAYDIUM_API_URL: str = "https://api.raydium.io/v2"
    COINGECKO_API_URL: str = "https://api.coingecko.com/api/v3"
    
    # Monitoring settings
    PRICE_UPDATE_INTERVAL: int = int(os.getenv("PRICE_UPDATE_INTERVAL", "5"))  # seconds
    SENTIMENT_UPDATE_INTERVAL: int = int(os.getenv("SENTIMENT_UPDATE_INTERVAL", "60"))  # seconds
    PORTFOLIO_UPDATE_INTERVAL: int = int(os.getenv("PORTFOLIO_UPDATE_INTERVAL", "30"))  # seconds
    
    # Logging settings
    LOG_LEVEL: str = os.getenv("LOG_LEVEL", "INFO")
    LOG_FILE: str = os.getenv("LOG_FILE", "logs/trading_bot.log")
    
    @classmethod
    def load_from_file(cls, file_path: str = ".env"):
        """Load configuration from file"""
        load_dotenv(file_path)
        return cls()
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert config to dictionary"""
        return {
            key: getattr(self, key)
            for key in dir(self)
            if not key.startswith('_') and not callable(getattr(self, key))
        }
    
    def validate(self) -> bool:
        """Validate configuration"""
        required_fields = [
            'SOLANA_RPC_URL',
            'INITIAL_CAPITAL',
        ]
        
        for field in required_fields:
            if not getattr(self, field):
                raise ValueError(f"Missing required configuration: {field}")
        
        return True

# Global config instance
config = Config()
config.validate()