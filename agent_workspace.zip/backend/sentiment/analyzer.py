import asyncio
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
import aiohttp
import json
from dataclasses import dataclass
import re
from urllib.parse import urljoin, urlparse

from textblob import TextBlob
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer

from database.connection import Database
from utils.websocket_manager import WebSocketManager
from utils.config import config

logger = logging.getLogger(__name__)

@dataclass
class SentimentResult:
    platform: str
    content: str
    sentiment_score: float
    confidence: float
    engagement_score: int
    author: str
    url: str
    mentions_count: int
    timestamp: datetime

class SentimentAnalyzer:
    """AI-powered sentiment analysis from multiple social platforms"""
    
    def __init__(self, db: Database, websocket_manager: WebSocketManager):
        self.db = db
        self.websocket_manager = websocket_manager
        self.is_running = False
        
        # Initialize sentiment analyzers
        self.vader_analyzer = SentimentIntensityAnalyzer()
        
        # Platform scrapers
        self.session = None
        
        # Tracking data
        self.monitored_tokens = set()
        self.last_analysis_time = {}
        
        logger.info("Sentiment analyzer initialized")
    
    async def start_monitoring(self):
        """Start sentiment monitoring"""
        self.is_running = True
        self.session = aiohttp.ClientSession()
        
        logger.info("Starting sentiment monitoring...")
        
        # Start monitoring tasks
        asyncio.create_task(self._monitor_twitter())
        asyncio.create_task(self._monitor_reddit())
        asyncio.create_task(self._monitor_telegram())
        asyncio.create_task(self._monitor_discord())
        asyncio.create_task(self._update_monitored_tokens())
        
        await self.websocket_manager.broadcast_alert({
            "type": "info",
            "message": "Sentiment monitoring started",
            "timestamp": datetime.utcnow().isoformat()
        })
    
    async def stop(self):
        """Stop sentiment monitoring"""
        self.is_running = False
        if self.session:
            await self.session.close()
        logger.info("Sentiment monitoring stopped")
    
    async def _update_monitored_tokens(self):
        """Update list of tokens to monitor"""
        while self.is_running:
            try:
                # Get tokens with recent activity or new tokens
                tokens = await self.db.execute_query(
                    """
                    SELECT DISTINCT mint_address FROM tokens 
                    WHERE created_at >= datetime('now', '-7 days')
                    OR updated_at >= datetime('now', '-1 day')
                    LIMIT 100
                    """
                )
                
                self.monitored_tokens = {token['mint_address'] for token in tokens}
                logger.info(f"Monitoring {len(self.monitored_tokens)} tokens for sentiment")
                
                await asyncio.sleep(300)  # Update every 5 minutes
                
            except Exception as e:
                logger.error(f"Error updating monitored tokens: {e}")
                await asyncio.sleep(60)
    
    async def _monitor_twitter(self):
        """Monitor Twitter for meme coin mentions"""
        while self.is_running:
            try:
                # Twitter web scraping (free alternative to API)
                await self._scrape_twitter_mentions()
                await asyncio.sleep(config.SENTIMENT_UPDATE_INTERVAL)
                
            except Exception as e:
                logger.error(f"Error monitoring Twitter: {e}")
                await asyncio.sleep(120)
    
    async def _monitor_reddit(self):
        """Monitor Reddit for meme coin discussions"""
        while self.is_running:
            try:
                await self._scrape_reddit_mentions()
                await asyncio.sleep(config.SENTIMENT_UPDATE_INTERVAL)
                
            except Exception as e:
                logger.error(f"Error monitoring Reddit: {e}")
                await asyncio.sleep(120)
    
    async def _monitor_telegram(self):
        """Monitor Telegram for meme coin discussions"""
        while self.is_running:
            try:
                await self._scrape_telegram_mentions()
                await asyncio.sleep(config.SENTIMENT_UPDATE_INTERVAL)
                
            except Exception as e:
                logger.error(f"Error monitoring Telegram: {e}")
                await asyncio.sleep(120)
    
    async def _monitor_discord(self):
        """Monitor Discord for meme coin discussions"""
        while self.is_running:
            try:
                await self._scrape_discord_mentions()
                await asyncio.sleep(config.SENTIMENT_UPDATE_INTERVAL)
                
            except Exception as e:
                logger.error(f"Error monitoring Discord: {e}")
                await asyncio.sleep(120)
    
    async def _scrape_twitter_mentions(self):
        """Scrape Twitter for crypto mentions"""
        try:
            # Simulate Twitter scraping with realistic data
            # In production, use tools like snscrape or selenium
            
            sample_tweets = [
                {
                    "content": "🚀 This new Solana meme coin is absolutely pumping! Best investment I've made this year! #SolanaGems #MemeCoins",
                    "author": "CryptoTrader2024",
                    "engagement": 156,
                    "timestamp": datetime.utcnow(),
                    "mentions": ["SOL", "Solana"]
                },
                {
                    "content": "Not feeling good about the meme coin market right now. Too much speculation and not enough utility. Be careful out there!",
                    "author": "DefiAnalyst",
                    "engagement": 89,
                    "timestamp": datetime.utcnow(),
                    "mentions": ["meme coin"]
                },
                {
                    "content": "Solana ecosystem is growing so fast! New meme coins launching every day. Found some gems today 💎",
                    "author": "SolanaHunter",
                    "engagement": 234,
                    "timestamp": datetime.utcnow(),
                    "mentions": ["Solana", "SOL"]
                }
            ]
            
            for tweet in sample_tweets:
                await self._process_social_mention("twitter", tweet)
            
            logger.debug(f"Processed {len(sample_tweets)} Twitter mentions")
            
        except Exception as e:
            logger.error(f"Error scraping Twitter: {e}")
    
    async def _scrape_reddit_mentions(self):
        """Scrape Reddit for crypto discussions"""
        try:
            # Simulate Reddit scraping
            sample_posts = [
                {
                    "content": "Found this new Solana meme coin with crazy potential. Team seems legit and the tokenomics are interesting. DYOR but this could 100x",
                    "author": "SolanaGem_Hunter",
                    "engagement": 45,
                    "timestamp": datetime.utcnow(),
                    "mentions": ["Solana", "meme coin"]
                },
                {
                    "content": "Be very careful with new meme coins on Solana. Lots of rug pulls happening. Only invest what you can afford to lose.",
                    "author": "DefiSafety",
                    "engagement": 78,
                    "timestamp": datetime.utcnow(),
                    "mentions": ["Solana", "meme coins"]
                }
            ]
            
            for post in sample_posts:
                await self._process_social_mention("reddit", post)
            
            logger.debug(f"Processed {len(sample_posts)} Reddit mentions")
            
        except Exception as e:
            logger.error(f"Error scraping Reddit: {e}")
    
    async def _scrape_telegram_mentions(self):
        """Scrape Telegram for crypto discussions"""
        try:
            # Simulate Telegram scraping
            sample_messages = [
                {
                    "content": "🔥🔥🔥 NEW GEM ALERT 🔥🔥🔥 Solana meme coin about to explode! Get in early!",
                    "author": "CryptoSignals_VIP",
                    "engagement": 312,
                    "timestamp": datetime.utcnow(),
                    "mentions": ["Solana", "meme coin"]
                },
                {
                    "content": "Market looking bearish for meme coins. Might be time to take profits and wait for better entry.",
                    "author": "MarketAnalyzer",
                    "engagement": 156,
                    "timestamp": datetime.utcnow(),
                    "mentions": ["meme coins"]
                }
            ]
            
            for message in sample_messages:
                await self._process_social_mention("telegram", message)
            
            logger.debug(f"Processed {len(sample_messages)} Telegram mentions")
            
        except Exception as e:
            logger.error(f"Error scraping Telegram: {e}")
    
    async def _scrape_discord_mentions(self):
        """Scrape Discord for crypto discussions"""
        try:
            # Simulate Discord scraping
            sample_messages = [
                {
                    "content": "Just aped into this new Solana meme coin. The community is growing fast and devs are active.",
                    "author": "DegenTrader",
                    "engagement": 23,
                    "timestamp": datetime.utcnow(),
                    "mentions": ["Solana", "meme coin"]
                }
            ]
            
            for message in sample_messages:
                await self._process_social_mention("discord", message)
            
            logger.debug(f"Processed {len(sample_messages)} Discord mentions")
            
        except Exception as e:
            logger.error(f"Error scraping Discord: {e}")
    
    async def _process_social_mention(self, platform: str, mention_data: Dict):
        """Process a social media mention and extract sentiment"""
        try:
            content = mention_data['content']
            
            # Clean and analyze text
            cleaned_content = self._clean_text(content)
            
            # Calculate sentiment scores
            sentiment_score, confidence = self._analyze_sentiment(cleaned_content)
            
            # Extract mentioned tokens (for now, we'll use general meme coin sentiment)
            mentioned_tokens = self._extract_token_mentions(content)
            
            # If no specific tokens mentioned, apply to general meme coin sentiment
            if not mentioned_tokens:
                mentioned_tokens = ['GENERAL_MEME_SENTIMENT']
            
            # Save sentiment data for each mentioned token
            for token_ref in mentioned_tokens:
                # For simulation, create sample mint addresses
                mint_address = self._get_or_create_sample_mint(token_ref)
                
                sentiment_data = {
                    'mint_address': mint_address,
                    'platform': platform,
                    'content': content[:1000],  # Limit content length
                    'sentiment_score': sentiment_score,
                    'confidence': confidence,
                    'engagement_score': mention_data.get('engagement', 0),
                    'author': mention_data.get('author', ''),
                    'url': mention_data.get('url', ''),
                    'mentions_count': len(mentioned_tokens)
                }
                
                await self._save_sentiment_data(sentiment_data)
            
        except Exception as e:
            logger.error(f"Error processing social mention: {e}")
    
    def _clean_text(self, text: str) -> str:
        """Clean text for sentiment analysis"""
        # Remove URLs
        text = re.sub(r'http\S+|www\S+|https\S+', '', text, flags=re.MULTILINE)
        
        # Remove special characters but keep emojis
        text = re.sub(r'[^\w\s\U0001F600-\U0001F64F\U0001F300-\U0001F5FF\U0001F680-\U0001F6FF\U0001F1E0-\U0001F1FF]', ' ', text)
        
        # Remove extra whitespace
        text = ' '.join(text.split())
        
        return text
    
    def _analyze_sentiment(self, text: str) -> tuple[float, float]:
        """Analyze sentiment using multiple methods"""
        try:
            # VADER sentiment analysis
            vader_scores = self.vader_analyzer.polarity_scores(text)
            vader_compound = vader_scores['compound']
            
            # TextBlob sentiment analysis
            blob = TextBlob(text)
            textblob_polarity = blob.sentiment.polarity
            
            # Combine scores (weighted average)
            combined_score = (vader_compound * 0.6 + textblob_polarity * 0.4)
            
            # Normalize to 0-1 scale
            normalized_score = (combined_score + 1) / 2
            
            # Calculate confidence based on agreement between methods
            agreement = 1 - abs(vader_compound - textblob_polarity) / 2
            confidence = min(agreement + 0.3, 1.0)  # Boost confidence slightly
            
            return normalized_score, confidence
            
        except Exception as e:
            logger.error(f"Error analyzing sentiment: {e}")
            return 0.5, 0.5  # Neutral sentiment with low confidence
    
    def _extract_token_mentions(self, text: str) -> List[str]:
        """Extract token mentions from text"""
        mentions = []
        
        # Common crypto terms that might indicate meme coins
        crypto_terms = [
            'solana', 'sol', 'meme coin', 'memecoin', 'gem', 'pump', 'moon',
            'rocket', 'diamond hands', 'hodl', 'ape', 'degen', 'shitcoin'
        ]
        
        text_lower = text.lower()
        
        for term in crypto_terms:
            if term in text_lower:
                mentions.append(term.upper())
        
        # Look for potential token symbols (3-5 uppercase letters)
        token_pattern = r'\b[A-Z]{3,5}\b'
        token_matches = re.findall(token_pattern, text)
        mentions.extend(token_matches)
        
        return list(set(mentions))  # Remove duplicates
    
    def _get_or_create_sample_mint(self, token_ref: str) -> str:
        """Get or create sample mint address for simulation"""
        # For simulation, create deterministic mint addresses
        import hashlib
        
        hash_obj = hashlib.md5(token_ref.encode())
        hash_hex = hash_obj.hexdigest()
        
        # Create a Solana-like address (44 characters)
        mint_address = hash_hex + '1' * (44 - len(hash_hex))
        
        return mint_address
    
    async def _save_sentiment_data(self, sentiment_data: Dict):
        """Save sentiment data to database"""
        try:
            await self.db.execute_insert(
                """
                INSERT INTO sentiment_data 
                (mint_address, platform, content, sentiment_score, confidence, 
                 engagement_score, author, url, mentions_count)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    sentiment_data['mint_address'],
                    sentiment_data['platform'],
                    sentiment_data['content'],
                    sentiment_data['sentiment_score'],
                    sentiment_data['confidence'],
                    sentiment_data['engagement_score'],
                    sentiment_data['author'],
                    sentiment_data['url'],
                    sentiment_data['mentions_count']
                )
            )
            
            # Broadcast sentiment update
            await self.websocket_manager.broadcast_sentiment_update({
                "mint_address": sentiment_data['mint_address'],
                "platform": sentiment_data['platform'],
                "sentiment_score": sentiment_data['sentiment_score'],
                "confidence": sentiment_data['confidence'],
                "timestamp": datetime.utcnow().isoformat()
            })
            
        except Exception as e:
            logger.error(f"Error saving sentiment data: {e}")
    
    async def get_token_sentiment(self, mint_address: str, hours: int = 24) -> Dict:
        """Get aggregated sentiment for a token"""
        try:
            cutoff_time = datetime.utcnow() - timedelta(hours=hours)
            
            sentiment_data = await self.db.execute_query(
                """
                SELECT AVG(sentiment_score) as avg_sentiment,
                       AVG(confidence) as avg_confidence,
                       COUNT(*) as mention_count,
                       SUM(engagement_score) as total_engagement,
                       platform
                FROM sentiment_data 
                WHERE mint_address = ? AND timestamp >= ?
                GROUP BY platform
                """,
                (mint_address, cutoff_time)
            )
            
            if not sentiment_data:
                return {
                    'avg_sentiment': 0.5,
                    'avg_confidence': 0.5,
                    'mention_count': 0,
                    'total_engagement': 0,
                    'platforms': []
                }
            
            # Aggregate across platforms
            total_mentions = sum(row['mention_count'] for row in sentiment_data)
            weighted_sentiment = sum(
                row['avg_sentiment'] * row['mention_count'] 
                for row in sentiment_data
            ) / total_mentions if total_mentions > 0 else 0.5
            
            weighted_confidence = sum(
                row['avg_confidence'] * row['mention_count'] 
                for row in sentiment_data
            ) / total_mentions if total_mentions > 0 else 0.5
            
            total_engagement = sum(row['total_engagement'] for row in sentiment_data)
            
            return {
                'avg_sentiment': weighted_sentiment,
                'avg_confidence': weighted_confidence,
                'mention_count': total_mentions,
                'total_engagement': total_engagement,
                'platforms': [row['platform'] for row in sentiment_data]
            }
            
        except Exception as e:
            logger.error(f"Error getting token sentiment: {e}")
            return {
                'avg_sentiment': 0.5,
                'avg_confidence': 0.5,
                'mention_count': 0,
                'total_engagement': 0,
                'platforms': []
            }
    
    async def get_trending_tokens(self, limit: int = 10) -> List[Dict]:
        """Get trending tokens based on sentiment"""
        try:
            cutoff_time = datetime.utcnow() - timedelta(hours=6)
            
            trending = await self.db.execute_query(
                """
                SELECT mint_address,
                       AVG(sentiment_score) as avg_sentiment,
                       COUNT(*) as mention_count,
                       SUM(engagement_score) as total_engagement
                FROM sentiment_data 
                WHERE timestamp >= ?
                GROUP BY mint_address
                HAVING mention_count >= 3 AND avg_sentiment >= 0.6
                ORDER BY (avg_sentiment * mention_count * total_engagement) DESC
                LIMIT ?
                """,
                (cutoff_time, limit)
            )
            
            return trending
            
        except Exception as e:
            logger.error(f"Error getting trending tokens: {e}")
            return []