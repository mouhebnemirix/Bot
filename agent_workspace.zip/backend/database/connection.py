import aiosqlite
import sqlite3
from typing import List, Dict, Any, Optional
import json
from datetime import datetime, timezone
import logging
import os

logger = logging.getLogger(__name__)

class Database:
    def __init__(self, db_path: str = "data/trading_bot.db"):
        self.db_path = db_path
        self.connection = None
    
    async def initialize(self):
        """Initialize database and create tables"""
        # Ensure data directory exists
        os.makedirs(os.path.dirname(self.db_path), exist_ok=True)
        
        # Create database and tables
        await self.create_tables()
        logger.info(f"Database initialized at {self.db_path}")
    
    async def get_connection(self):
        """Get database connection"""
        return await aiosqlite.connect(self.db_path)
    
    async def create_tables(self):
        """Create all necessary tables"""
        async with await self.get_connection() as db:
            # Enable foreign keys
            await db.execute("PRAGMA foreign_keys = ON")
            
            # Tokens table
            await db.execute("""
                CREATE TABLE IF NOT EXISTS tokens (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    mint_address TEXT UNIQUE NOT NULL,
                    symbol TEXT,
                    name TEXT,
                    decimals INTEGER DEFAULT 9,
                    total_supply REAL,
                    market_cap REAL,
                    price_usd REAL,
                    volume_24h REAL,
                    holders_count INTEGER DEFAULT 0,
                    is_verified BOOLEAN DEFAULT 0,
                    is_meme_coin BOOLEAN DEFAULT 1,
                    liquidity_usd REAL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    metadata TEXT
                )
            """)
            
            # Wallets table
            await db.execute("""
                CREATE TABLE IF NOT EXISTS wallets (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    address TEXT UNIQUE NOT NULL,
                    private_key_encrypted TEXT NOT NULL,
                    name TEXT,
                    balance_sol REAL DEFAULT 0,
                    balance_usd REAL DEFAULT 0,
                    is_active BOOLEAN DEFAULT 1,
                    risk_allocation REAL DEFAULT 10.0,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            # Positions table
            await db.execute("""
                CREATE TABLE IF NOT EXISTS positions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    wallet_id INTEGER NOT NULL,
                    token_id INTEGER NOT NULL,
                    mint_address TEXT NOT NULL,
                    amount REAL NOT NULL,
                    entry_price REAL NOT NULL,
                    current_price REAL,
                    pnl_usd REAL DEFAULT 0,
                    pnl_percentage REAL DEFAULT 0,
                    entry_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    exit_date TIMESTAMP,
                    status TEXT DEFAULT 'open',
                    stop_loss REAL,
                    take_profit REAL,
                    confidence_score REAL,
                    holding_period_target TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            # Trades table
            await db.execute("""
                CREATE TABLE IF NOT EXISTS trades (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    wallet_id INTEGER NOT NULL,
                    token_id INTEGER NOT NULL,
                    mint_address TEXT NOT NULL,
                    trade_type TEXT NOT NULL,
                    amount REAL NOT NULL,
                    price REAL NOT NULL,
                    value_usd REAL NOT NULL,
                    fee_sol REAL,
                    signature TEXT,
                    block_time TIMESTAMP,
                    confidence_score REAL,
                    sentiment_score REAL,
                    ai_signal_strength REAL,
                    execution_time_ms INTEGER,
                    slippage_percentage REAL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            # Market data table
            await db.execute("""
                CREATE TABLE IF NOT EXISTS market_data (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    mint_address TEXT NOT NULL,
                    price_usd REAL NOT NULL,
                    volume_24h REAL,
                    market_cap REAL,
                    price_change_1h REAL,
                    price_change_24h REAL,
                    liquidity_usd REAL,
                    holders_count INTEGER,
                    dex_name TEXT,
                    pool_address TEXT,
                    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            # Sentiment data table
            await db.execute("""
                CREATE TABLE IF NOT EXISTS sentiment_data (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    mint_address TEXT NOT NULL,
                    platform TEXT NOT NULL,
                    content TEXT NOT NULL,
                    sentiment_score REAL NOT NULL,
                    confidence REAL NOT NULL,
                    engagement_score INTEGER DEFAULT 0,
                    author TEXT,
                    url TEXT,
                    mentions_count INTEGER DEFAULT 1,
                    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    processed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            # Trading signals table
            await db.execute("""
                CREATE TABLE IF NOT EXISTS trading_signals (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    mint_address TEXT NOT NULL,
                    signal_type TEXT NOT NULL,
                    action TEXT NOT NULL,
                    strength REAL NOT NULL,
                    confidence REAL NOT NULL,
                    price_target REAL,
                    stop_loss REAL,
                    holding_period TEXT,
                    reasoning TEXT,
                    sentiment_weight REAL,
                    technical_weight REAL,
                    volume_weight REAL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    expires_at TIMESTAMP
                )
            """)
            
            # Portfolio metrics table
            await db.execute("""
                CREATE TABLE IF NOT EXISTS portfolio_metrics (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    wallet_id INTEGER,
                    total_value_usd REAL NOT NULL,
                    total_pnl_usd REAL NOT NULL,
                    total_pnl_percentage REAL NOT NULL,
                    win_rate REAL,
                    total_trades INTEGER DEFAULT 0,
                    winning_trades INTEGER DEFAULT 0,
                    losing_trades INTEGER DEFAULT 0,
                    largest_win_usd REAL,
                    largest_loss_usd REAL,
                    sharpe_ratio REAL,
                    max_drawdown REAL,
                    daily_return REAL,
                    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            # Create indexes for better performance
            await db.execute("CREATE INDEX IF NOT EXISTS idx_tokens_mint ON tokens(mint_address)")
            await db.execute("CREATE INDEX IF NOT EXISTS idx_positions_wallet ON positions(wallet_id)")
            await db.execute("CREATE INDEX IF NOT EXISTS idx_trades_wallet ON trades(wallet_id)")
            await db.execute("CREATE INDEX IF NOT EXISTS idx_market_data_mint ON market_data(mint_address)")
            await db.execute("CREATE INDEX IF NOT EXISTS idx_sentiment_mint ON sentiment_data(mint_address)")
            await db.execute("CREATE INDEX IF NOT EXISTS idx_signals_mint ON trading_signals(mint_address)")
            
            await db.commit()
            logger.info("All database tables created successfully")
    
    async def execute_query(self, query: str, params: tuple = ()) -> List[Dict]:
        """Execute a SELECT query and return results"""
        async with await self.get_connection() as db:
            db.row_factory = aiosqlite.Row
            cursor = await db.execute(query, params)
            rows = await cursor.fetchall()
            return [dict(row) for row in rows]
    
    async def execute_update(self, query: str, params: tuple = ()) -> int:
        """Execute an INSERT, UPDATE, or DELETE query"""
        async with await self.get_connection() as db:
            cursor = await db.execute(query, params)
            await db.commit()
            return cursor.rowcount
    
    async def execute_insert(self, query: str, params: tuple = ()) -> int:
        """Execute an INSERT query and return the last row ID"""
        async with await self.get_connection() as db:
            cursor = await db.execute(query, params)
            await db.commit()
            return cursor.lastrowid
    
    async def get_token_by_mint(self, mint_address: str) -> Optional[Dict]:
        """Get token by mint address"""
        results = await self.execute_query(
            "SELECT * FROM tokens WHERE mint_address = ?",
            (mint_address,)
        )
        return results[0] if results else None
    
    async def insert_token(self, token_data: Dict) -> int:
        """Insert new token"""
        query = """
            INSERT OR REPLACE INTO tokens 
            (mint_address, symbol, name, decimals, total_supply, market_cap, 
             price_usd, volume_24h, holders_count, is_verified, is_meme_coin, 
             liquidity_usd, metadata, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
        """
        
        params = (
            token_data.get('mint_address'),
            token_data.get('symbol'),
            token_data.get('name'),
            token_data.get('decimals', 9),
            token_data.get('total_supply'),
            token_data.get('market_cap'),
            token_data.get('price_usd'),
            token_data.get('volume_24h'),
            token_data.get('holders_count', 0),
            token_data.get('is_verified', False),
            token_data.get('is_meme_coin', True),
            token_data.get('liquidity_usd'),
            json.dumps(token_data.get('metadata', {}))
        )
        
        return await self.execute_insert(query, params)
    
    async def insert_trade(self, trade_data: Dict) -> int:
        """Insert new trade"""
        query = """
            INSERT INTO trades 
            (wallet_id, token_id, mint_address, trade_type, amount, price, 
             value_usd, fee_sol, signature, confidence_score, sentiment_score, 
             ai_signal_strength, execution_time_ms, slippage_percentage)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """
        
        params = (
            trade_data.get('wallet_id'),
            trade_data.get('token_id'),
            trade_data.get('mint_address'),
            trade_data.get('trade_type'),
            trade_data.get('amount'),
            trade_data.get('price'),
            trade_data.get('value_usd'),
            trade_data.get('fee_sol'),
            trade_data.get('signature'),
            trade_data.get('confidence_score'),
            trade_data.get('sentiment_score'),
            trade_data.get('ai_signal_strength'),
            trade_data.get('execution_time_ms'),
            trade_data.get('slippage_percentage')
        )
        
        return await self.execute_insert(query, params)
    
    async def get_active_positions(self, wallet_id: Optional[int] = None) -> List[Dict]:
        """Get active positions"""
        query = "SELECT * FROM positions WHERE status = 'open'"
        params = ()
        
        if wallet_id:
            query += " AND wallet_id = ?"
            params = (wallet_id,)
        
        return await self.execute_query(query, params)
    
    async def get_portfolio_metrics(self, wallet_id: Optional[int] = None) -> List[Dict]:
        """Get latest portfolio metrics"""
        query = """
            SELECT * FROM portfolio_metrics 
            WHERE timestamp >= datetime('now', '-1 day')
            ORDER BY timestamp DESC
        """
        params = ()
        
        if wallet_id:
            query = query.replace('WHERE', 'WHERE wallet_id = ? AND')
            params = (wallet_id,)
        
        return await self.execute_query(query, params)
    
    async def close(self):
        """Close database connection"""
        if self.connection:
            await self.connection.close()
            logger.info("Database connection closed")