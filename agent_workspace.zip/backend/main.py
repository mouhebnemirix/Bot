from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from contextlib import asynccontextmanager
import uvicorn
import asyncio
import json
from datetime import datetime
from typing import List, Dict, Any
import logging
import os

# Import our modules
from database.connection import Database
from trading.engine import TradingEngine
from sentiment.analyzer import SentimentAnalyzer
from blockchain.solana_monitor import SolanaMonitor
from notifications.telegram_bot import TelegramNotifier
from utils.websocket_manager import WebSocketManager
from utils.config import Config
from api import routes

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('logs/trading_bot.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Global instances
db = None
trading_engine = None
sentiment_analyzer = None
solana_monitor = None
telegram_notifier = None
websocket_manager = None

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application startup and shutdown events"""
    global db, trading_engine, sentiment_analyzer, solana_monitor, telegram_notifier, websocket_manager
    
    try:
        # Create necessary directories
        os.makedirs('logs', exist_ok=True)
        os.makedirs('data', exist_ok=True)
        os.makedirs('data/sentiment', exist_ok=True)
        os.makedirs('data/market', exist_ok=True)
        
        logger.info("Starting Solana Trading Bot...")
        
        # Initialize database
        db = Database()
        await db.initialize()
        logger.info("Database initialized")
        
        # Initialize WebSocket manager
        websocket_manager = WebSocketManager()
        
        # Initialize sentiment analyzer
        sentiment_analyzer = SentimentAnalyzer(db, websocket_manager)
        logger.info("Sentiment analyzer initialized")
        
        # Initialize Solana monitor
        solana_monitor = SolanaMonitor(db, websocket_manager)
        logger.info("Solana monitor initialized")
        
        # Initialize trading engine
        trading_engine = TradingEngine(db, websocket_manager, sentiment_analyzer)
        logger.info("Trading engine initialized")
        
        # Initialize Telegram notifier
        telegram_notifier = TelegramNotifier()
        logger.info("Telegram notifier initialized")
        
        # Start background tasks
        asyncio.create_task(sentiment_analyzer.start_monitoring())
        asyncio.create_task(solana_monitor.start_monitoring())
        asyncio.create_task(trading_engine.start_trading())
        
        logger.info("All services started successfully")
        
        yield
        
    except Exception as e:
        logger.error(f"Failed to start application: {e}")
        raise
    finally:
        # Cleanup
        logger.info("Shutting down Solana Trading Bot...")
        if trading_engine:
            await trading_engine.stop()
        if sentiment_analyzer:
            await sentiment_analyzer.stop()
        if solana_monitor:
            await solana_monitor.stop()
        if db:
            await db.close()
        logger.info("Shutdown complete")

# Create FastAPI app
app = FastAPI(
    title="Solana Meme Coin Trading Bot",
    description="High-performance AI-powered trading bot for Solana meme coins",
    version="1.0.0",
    lifespan=lifespan
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Configure appropriately for production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount static files
app.mount("/static", StaticFiles(directory="static"), name="static")

# Include API routes
app.include_router(routes.router, prefix="/api/v1")

# WebSocket endpoint for real-time updates
@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await websocket_manager.connect(websocket)
    try:
        while True:
            # Keep connection alive
            await asyncio.sleep(1)
    except WebSocketDisconnect:
        websocket_manager.disconnect(websocket)

# Health check endpoint
@app.get("/health")
async def health_check():
    return {
        "status": "healthy",
        "timestamp": datetime.utcnow().isoformat(),
        "version": "1.0.0",
        "services": {
            "database": "connected" if db else "disconnected",
            "trading_engine": "running" if trading_engine else "stopped",
            "sentiment_analyzer": "running" if sentiment_analyzer else "stopped",
            "solana_monitor": "running" if solana_monitor else "stopped"
        }
    }

# Root endpoint
@app.get("/")
async def root():
    return {
        "message": "Solana Meme Coin Trading Bot API",
        "docs": "/docs",
        "health": "/health",
        "websocket": "/ws"
    }

if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info"
    )