import logging
from typing import Dict, List, Optional, Any
from datetime import datetime, timedelta
from dataclasses import dataclass

from database.connection import Database
from utils.config import config

logger = logging.getLogger(__name__)

@dataclass
class RiskMetrics:
    total_exposure: float
    position_count: int
    daily_trades: int
    daily_pnl: float
    max_drawdown: float
    risk_ratio: float
    portfolio_heat: float

class RiskManager:
    """Advanced risk management system"""
    
    def __init__(self, db: Database):
        self.db = db
        self.max_portfolio_risk = 0.20  # 20% max portfolio risk
        self.max_position_risk = config.MAX_POSITION_SIZE
        self.max_daily_trades = config.MAX_DAILY_TRADES
        self.max_concurrent_positions = config.MAX_CONCURRENT_POSITIONS
        
        logger.info("Risk manager initialized")
    
    async def can_open_position(self, signal) -> bool:
        """Check if we can open a new position based on risk rules"""
        try:
            # Get current risk metrics
            metrics = await self._calculate_risk_metrics()
            
            # Check position count limit
            if metrics.position_count >= self.max_concurrent_positions:
                logger.info(f"Position count limit reached: {metrics.position_count}")
                return False
            
            # Check daily trade limit
            if metrics.daily_trades >= self.max_daily_trades:
                logger.info(f"Daily trade limit reached: {metrics.daily_trades}")
                return False
            
            # Check portfolio heat (total risk exposure)
            if metrics.portfolio_heat >= self.max_portfolio_risk:
                logger.info(f"Portfolio heat too high: {metrics.portfolio_heat:.2%}")
                return False
            
            # Check signal quality
            if signal.confidence < config.MIN_CONFIDENCE_SCORE:
                logger.info(f"Signal confidence too low: {signal.confidence}")
                return False
            
            if signal.strength < config.MIN_SENTIMENT_SCORE:
                logger.info(f"Signal strength too low: {signal.strength}")
                return False
            
            # Check if we have sufficient balance
            available_balance = await self._get_available_balance()
            min_position_size = config.INITIAL_CAPITAL * 0.01  # 1% minimum
            
            if available_balance < min_position_size:
                logger.info(f"Insufficient balance: ${available_balance:.2f}")
                return False
            
            # Check max drawdown protection
            if metrics.max_drawdown <= -0.15:  # -15% max drawdown
                logger.info(f"Max drawdown protection triggered: {metrics.max_drawdown:.2%}")
                return False
            
            return True
            
        except Exception as e:
            logger.error(f"Error checking position eligibility: {e}")
            return False
    
    async def calculate_position_size(self, signal) -> float:
        """Calculate optimal position size using Kelly Criterion and risk management"""
        try:
            # Get available balance
            available_balance = await self._get_available_balance()
            
            # Base position size (Kelly Criterion adapted)
            win_rate = await self._get_historical_win_rate()
            avg_win = await self._get_average_win()
            avg_loss = await self._get_average_loss()
            
            # Kelly Criterion: f = (bp - q) / b
            # Where: b = avg_win/avg_loss, p = win_rate, q = 1-win_rate
            if avg_loss > 0:
                b = avg_win / avg_loss
                kelly_fraction = (b * win_rate - (1 - win_rate)) / b
                kelly_fraction = max(0, min(kelly_fraction, 0.25))  # Cap at 25%
            else:
                kelly_fraction = 0.02  # Default 2%
            
            # Adjust based on signal confidence
            confidence_multiplier = signal.confidence
            strength_multiplier = signal.strength
            
            # Calculate base position size
            base_size = available_balance * kelly_fraction * confidence_multiplier * strength_multiplier
            
            # Apply risk limits
            max_position = available_balance * self.max_position_risk
            position_size = min(base_size, max_position)
            
            # Ensure minimum viable position
            min_position = config.INITIAL_CAPITAL * 0.005  # 0.5% minimum
            position_size = max(position_size, min_position)
            
            # Final checks
            if position_size > available_balance:
                position_size = available_balance * 0.95  # Leave 5% buffer
            
            logger.info(f"Calculated position size: ${position_size:.2f} (Kelly: {kelly_fraction:.1%}, Available: ${available_balance:.2f})")
            
            return position_size
            
        except Exception as e:
            logger.error(f"Error calculating position size: {e}")
            return 0.0
    
    async def _calculate_risk_metrics(self) -> RiskMetrics:
        """Calculate current portfolio risk metrics"""
        try:
            # Get active positions
            positions = await self.db.get_active_positions()
            
            # Calculate total exposure
            total_exposure = sum(pos.get('amount', 0) * pos.get('current_price', 0) for pos in positions)
            
            # Get today's trades
            today = datetime.utcnow().date()
            daily_trades_result = await self.db.execute_query(
                "SELECT COUNT(*) as count FROM trades WHERE DATE(created_at) = ?",
                (today,)
            )
            daily_trades = daily_trades_result[0]['count'] if daily_trades_result else 0
            
            # Calculate daily P&L
            daily_pnl_result = await self.db.execute_query(
                """
                SELECT SUM(
                    CASE 
                        WHEN trade_type = 'buy' THEN -value_usd
                        WHEN trade_type = 'sell' THEN value_usd
                        ELSE 0
                    END
                ) as daily_pnl
                FROM trades 
                WHERE DATE(created_at) = ?
                """,
                (today,)
            )
            daily_pnl = daily_pnl_result[0]['daily_pnl'] if daily_pnl_result and daily_pnl_result[0]['daily_pnl'] else 0
            
            # Calculate max drawdown
            max_drawdown = await self._calculate_max_drawdown()
            
            # Calculate portfolio heat (risk as % of total portfolio)
            total_portfolio_value = await self._get_total_portfolio_value()
            portfolio_heat = total_exposure / total_portfolio_value if total_portfolio_value > 0 else 0
            
            return RiskMetrics(
                total_exposure=total_exposure,
                position_count=len(positions),
                daily_trades=daily_trades,
                daily_pnl=daily_pnl,
                max_drawdown=max_drawdown,
                risk_ratio=portfolio_heat,
                portfolio_heat=portfolio_heat
            )
            
        except Exception as e:
            logger.error(f"Error calculating risk metrics: {e}")
            return RiskMetrics(0, 0, 0, 0, 0, 0, 0)
    
    async def _get_available_balance(self) -> float:
        """Get available balance for trading"""
        try:
            # Get total wallet balances
            wallets = await self.db.execute_query(
                "SELECT SUM(balance_usd) as total FROM wallets WHERE is_active = 1"
            )
            
            total_balance = wallets[0]['total'] if wallets and wallets[0]['total'] else config.INITIAL_CAPITAL
            
            # Subtract current position values
            positions = await self.db.get_active_positions()
            position_value = sum(pos.get('amount', 0) * pos.get('current_price', 0) for pos in positions)
            
            available = total_balance - position_value
            return max(available, 0)
            
        except Exception as e:
            logger.error(f"Error getting available balance: {e}")
            return config.INITIAL_CAPITAL
    
    async def _get_total_portfolio_value(self) -> float:
        """Get total portfolio value"""
        try:
            # Cash balance
            available_balance = await self._get_available_balance()
            
            # Position values
            positions = await self.db.get_active_positions()
            position_value = sum(pos.get('amount', 0) * pos.get('current_price', 0) for pos in positions)
            
            return available_balance + position_value
            
        except Exception as e:
            logger.error(f"Error getting total portfolio value: {e}")
            return config.INITIAL_CAPITAL
    
    async def _get_historical_win_rate(self) -> float:
        """Calculate historical win rate"""
        try:
            # Get closed positions from last 30 days
            cutoff_date = datetime.utcnow() - timedelta(days=30)
            
            positions = await self.db.execute_query(
                """
                SELECT COUNT(*) as total,
                       SUM(CASE WHEN pnl_usd > 0 THEN 1 ELSE 0 END) as wins
                FROM positions 
                WHERE status = 'closed' AND exit_date >= ?
                """,
                (cutoff_date,)
            )
            
            if positions and positions[0]['total'] > 0:
                win_rate = positions[0]['wins'] / positions[0]['total']
            else:
                win_rate = 0.6  # Default optimistic win rate for new bot
            
            return max(0.1, min(win_rate, 0.9))  # Keep between 10% and 90%
            
        except Exception as e:
            logger.error(f"Error calculating win rate: {e}")
            return 0.6
    
    async def _get_average_win(self) -> float:
        """Get average winning trade amount"""
        try:
            cutoff_date = datetime.utcnow() - timedelta(days=30)
            
            result = await self.db.execute_query(
                """
                SELECT AVG(pnl_usd) as avg_win
                FROM positions 
                WHERE status = 'closed' AND pnl_usd > 0 AND exit_date >= ?
                """,
                (cutoff_date,)
            )
            
            if result and result[0]['avg_win']:
                return float(result[0]['avg_win'])
            else:
                return config.INITIAL_CAPITAL * 0.05  # Default 5% win
            
        except Exception as e:
            logger.error(f"Error calculating average win: {e}")
            return config.INITIAL_CAPITAL * 0.05
    
    async def _get_average_loss(self) -> float:
        """Get average losing trade amount"""
        try:
            cutoff_date = datetime.utcnow() - timedelta(days=30)
            
            result = await self.db.execute_query(
                """
                SELECT AVG(ABS(pnl_usd)) as avg_loss
                FROM positions 
                WHERE status = 'closed' AND pnl_usd < 0 AND exit_date >= ?
                """,
                (cutoff_date,)
            )
            
            if result and result[0]['avg_loss']:
                return float(result[0]['avg_loss'])
            else:
                return config.INITIAL_CAPITAL * 0.02  # Default 2% loss
            
        except Exception as e:
            logger.error(f"Error calculating average loss: {e}")
            return config.INITIAL_CAPITAL * 0.02
    
    async def _calculate_max_drawdown(self) -> float:
        """Calculate maximum drawdown"""
        try:
            # Get portfolio value history (simplified)
            cutoff_date = datetime.utcnow() - timedelta(days=7)
            
            metrics = await self.db.execute_query(
                """
                SELECT total_value_usd, timestamp
                FROM portfolio_metrics 
                WHERE timestamp >= ?
                ORDER BY timestamp
                """,
                (cutoff_date,)
            )
            
            if len(metrics) < 2:
                return 0.0
            
            # Calculate drawdown
            peak = metrics[0]['total_value_usd']
            max_drawdown = 0.0
            
            for metric in metrics:
                current_value = metric['total_value_usd']
                if current_value > peak:
                    peak = current_value
                
                drawdown = (current_value - peak) / peak if peak > 0 else 0
                max_drawdown = min(max_drawdown, drawdown)
            
            return max_drawdown
            
        except Exception as e:
            logger.error(f"Error calculating max drawdown: {e}")
            return 0.0
    
    async def check_stop_loss_conditions(self) -> bool:
        """Check if global stop loss conditions are met"""
        try:
            metrics = await self._calculate_risk_metrics()
            
            # Daily loss limit
            if metrics.daily_pnl < -config.INITIAL_CAPITAL * 0.05:  # -5% daily loss limit
                logger.warning(f"Daily loss limit reached: ${metrics.daily_pnl:.2f}")
                return True
            
            # Max drawdown limit
            if metrics.max_drawdown <= -0.20:  # -20% max drawdown
                logger.warning(f"Max drawdown limit reached: {metrics.max_drawdown:.2%}")
                return True
            
            return False
            
        except Exception as e:
            logger.error(f"Error checking stop loss conditions: {e}")
            return True  # Be safe and stop trading if there's an error
    
    async def get_risk_report(self) -> Dict[str, Any]:
        """Generate comprehensive risk report"""
        try:
            metrics = await self._calculate_risk_metrics()
            
            return {
                "risk_metrics": {
                    "total_exposure": metrics.total_exposure,
                    "position_count": metrics.position_count,
                    "daily_trades": metrics.daily_trades,
                    "daily_pnl": metrics.daily_pnl,
                    "max_drawdown": metrics.max_drawdown,
                    "portfolio_heat": metrics.portfolio_heat
                },
                "limits": {
                    "max_positions": self.max_concurrent_positions,
                    "max_daily_trades": self.max_daily_trades,
                    "max_position_size": self.max_position_risk,
                    "max_portfolio_risk": self.max_portfolio_risk
                },
                "status": {
                    "can_trade": not await self.check_stop_loss_conditions(),
                    "available_balance": await self._get_available_balance(),
                    "total_portfolio_value": await self._get_total_portfolio_value()
                },
                "timestamp": datetime.utcnow().isoformat()
            }
            
        except Exception as e:
            logger.error(f"Error generating risk report: {e}")
            return {"error": str(e)}