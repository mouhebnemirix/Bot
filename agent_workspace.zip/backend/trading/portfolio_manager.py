import asyncio
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
from dataclasses import dataclass

from database.connection import Database
from utils.websocket_manager import WebSocketManager
from utils.config import config

logger = logging.getLogger(__name__)

@dataclass
class PortfolioStats:
    total_value: float
    total_pnl: float
    total_pnl_percentage: float
    win_rate: float
    total_trades: int
    winning_trades: int
    losing_trades: int
    largest_win: float
    largest_loss: float
    sharpe_ratio: float
    max_drawdown: float
    daily_return: float

class PortfolioManager:
    """Portfolio management and performance tracking"""
    
    def __init__(self, db: Database, websocket_manager: WebSocketManager):
        self.db = db
        self.websocket_manager = websocket_manager
        
        logger.info("Portfolio manager initialized")
    
    async def update_metrics(self):
        """Update portfolio metrics and broadcast to clients"""
        try:
            # Calculate current portfolio stats
            stats = await self._calculate_portfolio_stats()
            
            # Save metrics to database
            await self._save_metrics(stats)
            
            # Broadcast update to connected clients
            await self.websocket_manager.broadcast_portfolio_update({
                "stats": stats.__dict__,
                "timestamp": datetime.utcnow().isoformat()
            })
            
            logger.debug(f"Portfolio metrics updated - Total Value: ${stats.total_value:.2f}, P&L: ${stats.total_pnl:.2f} ({stats.total_pnl_percentage:.2f}%)")
            
        except Exception as e:
            logger.error(f"Error updating portfolio metrics: {e}")
    
    async def _calculate_portfolio_stats(self) -> PortfolioStats:
        """Calculate comprehensive portfolio statistics"""
        try:
            # Get current positions
            positions = await self.db.get_active_positions()
            
            # Calculate total portfolio value
            total_value = await self._calculate_total_value(positions)
            
            # Get historical trades
            trades = await self._get_all_trades()
            
            # Calculate P&L from closed positions
            closed_positions = await self._get_closed_positions()
            
            total_pnl = sum(pos.get('pnl_usd', 0) for pos in closed_positions)
            
            # Add unrealized P&L from open positions
            unrealized_pnl = sum(
                (pos.get('current_price', 0) - pos.get('entry_price', 0)) * pos.get('amount', 0)
                for pos in positions
            )
            total_pnl += unrealized_pnl
            
            # Calculate percentage return
            initial_capital = config.INITIAL_CAPITAL
            total_pnl_percentage = (total_pnl / initial_capital) * 100 if initial_capital > 0 else 0
            
            # Calculate win rate
            winning_positions = [pos for pos in closed_positions if pos.get('pnl_usd', 0) > 0]
            losing_positions = [pos for pos in closed_positions if pos.get('pnl_usd', 0) < 0]
            
            total_closed = len(closed_positions)
            winning_count = len(winning_positions)
            losing_count = len(losing_positions)
            
            win_rate = (winning_count / total_closed * 100) if total_closed > 0 else 0
            
            # Calculate largest win/loss
            largest_win = max((pos.get('pnl_usd', 0) for pos in winning_positions), default=0)
            largest_loss = min((pos.get('pnl_usd', 0) for pos in losing_positions), default=0)
            
            # Calculate Sharpe ratio (simplified)
            sharpe_ratio = await self._calculate_sharpe_ratio()
            
            # Calculate max drawdown
            max_drawdown = await self._calculate_max_drawdown()
            
            # Calculate daily return
            daily_return = await self._calculate_daily_return()
            
            return PortfolioStats(
                total_value=total_value,
                total_pnl=total_pnl,
                total_pnl_percentage=total_pnl_percentage,
                win_rate=win_rate,
                total_trades=len(trades),
                winning_trades=winning_count,
                losing_trades=losing_count,
                largest_win=largest_win,
                largest_loss=largest_loss,
                sharpe_ratio=sharpe_ratio,
                max_drawdown=max_drawdown,
                daily_return=daily_return
            )
            
        except Exception as e:
            logger.error(f"Error calculating portfolio stats: {e}")
            return PortfolioStats(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    
    async def _calculate_total_value(self, positions: List[Dict]) -> float:
        """Calculate total portfolio value"""
        try:
            # Cash balance
            wallets = await self.db.execute_query(
                "SELECT SUM(balance_usd) as total FROM wallets WHERE is_active = 1"
            )
            cash_balance = wallets[0]['total'] if wallets and wallets[0]['total'] else config.INITIAL_CAPITAL
            
            # Position values
            position_value = sum(
                pos.get('amount', 0) * pos.get('current_price', 0)
                for pos in positions
            )
            
            return cash_balance + position_value
            
        except Exception as e:
            logger.error(f"Error calculating total value: {e}")
            return config.INITIAL_CAPITAL
    
    async def _get_all_trades(self) -> List[Dict]:
        """Get all trades"""
        try:
            return await self.db.execute_query(
                "SELECT * FROM trades ORDER BY created_at DESC"
            )
        except Exception as e:
            logger.error(f"Error getting trades: {e}")
            return []
    
    async def _get_closed_positions(self) -> List[Dict]:
        """Get all closed positions"""
        try:
            return await self.db.execute_query(
                "SELECT * FROM positions WHERE status = 'closed' ORDER BY exit_date DESC"
            )
        except Exception as e:
            logger.error(f"Error getting closed positions: {e}")
            return []
    
    async def _calculate_sharpe_ratio(self) -> float:
        """Calculate Sharpe ratio (simplified)"""
        try:
            # Get daily returns for last 30 days
            cutoff_date = datetime.utcnow() - timedelta(days=30)
            
            daily_metrics = await self.db.execute_query(
                """
                SELECT daily_return FROM portfolio_metrics 
                WHERE timestamp >= ? AND daily_return IS NOT NULL
                ORDER BY timestamp
                """,
                (cutoff_date,)
            )
            
            if len(daily_metrics) < 5:  # Need at least 5 days of data
                return 0.0
            
            returns = [metric['daily_return'] for metric in daily_metrics]
            
            # Calculate average and standard deviation
            avg_return = sum(returns) / len(returns)
            variance = sum((r - avg_return) ** 2 for r in returns) / len(returns)
            std_dev = variance ** 0.5
            
            # Sharpe ratio (assuming 0% risk-free rate)
            sharpe = avg_return / std_dev if std_dev > 0 else 0
            
            return sharpe
            
        except Exception as e:
            logger.error(f"Error calculating Sharpe ratio: {e}")
            return 0.0
    
    async def _calculate_max_drawdown(self) -> float:
        """Calculate maximum drawdown"""
        try:
            # Get portfolio value history
            cutoff_date = datetime.utcnow() - timedelta(days=30)
            
            metrics = await self.db.execute_query(
                """
                SELECT total_value_usd, timestamp 
                FROM portfolio_metrics 
                WHERE timestamp >= ?
                ORDER BY timestamp
                """,
                (cutoff_date,)
            )
            
            if len(metrics) < 2:
                return 0.0
            
            # Calculate running maximum and drawdown
            peak = metrics[0]['total_value_usd']
            max_drawdown = 0.0
            
            for metric in metrics:
                current_value = metric['total_value_usd']
                
                if current_value > peak:
                    peak = current_value
                
                drawdown = (current_value - peak) / peak * 100 if peak > 0 else 0
                max_drawdown = min(max_drawdown, drawdown)
            
            return max_drawdown
            
        except Exception as e:
            logger.error(f"Error calculating max drawdown: {e}")
            return 0.0
    
    async def _calculate_daily_return(self) -> float:
        """Calculate today's return"""
        try:
            today = datetime.utcnow().date()
            yesterday = today - timedelta(days=1)
            
            # Get today's value
            today_metrics = await self.db.execute_query(
                """
                SELECT total_value_usd FROM portfolio_metrics 
                WHERE DATE(timestamp) = ?
                ORDER BY timestamp DESC LIMIT 1
                """,
                (today,)
            )
            
            # Get yesterday's value
            yesterday_metrics = await self.db.execute_query(
                """
                SELECT total_value_usd FROM portfolio_metrics 
                WHERE DATE(timestamp) = ?
                ORDER BY timestamp DESC LIMIT 1
                """,
                (yesterday,)
            )
            
            if today_metrics and yesterday_metrics:
                today_value = today_metrics[0]['total_value_usd']
                yesterday_value = yesterday_metrics[0]['total_value_usd']
                
                daily_return = ((today_value - yesterday_value) / yesterday_value * 100) if yesterday_value > 0 else 0
                return daily_return
            else:
                return 0.0
                
        except Exception as e:
            logger.error(f"Error calculating daily return: {e}")
            return 0.0
    
    async def _save_metrics(self, stats: PortfolioStats):
        """Save portfolio metrics to database"""
        try:
            await self.db.execute_insert(
                """
                INSERT INTO portfolio_metrics 
                (total_value_usd, total_pnl_usd, total_pnl_percentage, win_rate,
                 total_trades, winning_trades, losing_trades, largest_win_usd,
                 largest_loss_usd, sharpe_ratio, max_drawdown, daily_return)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    stats.total_value,
                    stats.total_pnl,
                    stats.total_pnl_percentage,
                    stats.win_rate,
                    stats.total_trades,
                    stats.winning_trades,
                    stats.losing_trades,
                    stats.largest_win,
                    stats.largest_loss,
                    stats.sharpe_ratio,
                    stats.max_drawdown,
                    stats.daily_return
                )
            )
        except Exception as e:
            logger.error(f"Error saving portfolio metrics: {e}")
    
    async def get_performance_summary(self, days: int = 7) -> Dict[str, Any]:
        """Get performance summary for specified period"""
        try:
            cutoff_date = datetime.utcnow() - timedelta(days=days)
            
            # Get trades in period
            trades = await self.db.execute_query(
                "SELECT * FROM trades WHERE created_at >= ?",
                (cutoff_date,)
            )
            
            # Get closed positions in period
            positions = await self.db.execute_query(
                "SELECT * FROM positions WHERE status = 'closed' AND exit_date >= ?",
                (cutoff_date,)
            )
            
            # Calculate summary
            total_trades = len(trades)
            total_volume = sum(trade.get('value_usd', 0) for trade in trades)
            total_pnl = sum(pos.get('pnl_usd', 0) for pos in positions)
            
            winning_positions = [pos for pos in positions if pos.get('pnl_usd', 0) > 0]
            win_rate = (len(winning_positions) / len(positions) * 100) if positions else 0
            
            return {
                "period_days": days,
                "total_trades": total_trades,
                "total_volume": total_volume,
                "total_pnl": total_pnl,
                "win_rate": win_rate,
                "closed_positions": len(positions),
                "winning_positions": len(winning_positions),
                "avg_trade_size": total_volume / total_trades if total_trades > 0 else 0,
                "avg_pnl_per_position": total_pnl / len(positions) if positions else 0,
                "timestamp": datetime.utcnow().isoformat()
            }
            
        except Exception as e:
            logger.error(f"Error getting performance summary: {e}")
            return {"error": str(e)}
    
    async def get_top_performers(self, limit: int = 10) -> List[Dict]:
        """Get top performing positions"""
        try:
            return await self.db.execute_query(
                """
                SELECT p.*, t.symbol, t.name 
                FROM positions p
                LEFT JOIN tokens t ON p.mint_address = t.mint_address
                WHERE p.status = 'closed'
                ORDER BY p.pnl_percentage DESC
                LIMIT ?
                """,
                (limit,)
            )
        except Exception as e:
            logger.error(f"Error getting top performers: {e}")
            return []
    
    async def get_worst_performers(self, limit: int = 10) -> List[Dict]:
        """Get worst performing positions"""
        try:
            return await self.db.execute_query(
                """
                SELECT p.*, t.symbol, t.name 
                FROM positions p
                LEFT JOIN tokens t ON p.mint_address = t.mint_address
                WHERE p.status = 'closed'
                ORDER BY p.pnl_percentage ASC
                LIMIT ?
                """,
                (limit,)
            )
        except Exception as e:
            logger.error(f"Error getting worst performers: {e}")
            return []