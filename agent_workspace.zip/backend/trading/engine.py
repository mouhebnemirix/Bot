import asyncio
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
import json
import time
from dataclasses import dataclass

from solana.rpc.async_api import AsyncClient
from solders.pubkey import Pubkey
from solders.keypair import Keypair
from solders.transaction import Transaction
from solders.instruction import Instruction

from database.connection import Database
from utils.websocket_manager import WebSocketManager
from utils.config import config
from blockchain.jupiter_integration import JupiterClient
from sentiment.analyzer import SentimentAnalyzer
from trading.risk_manager import RiskManager
from trading.portfolio_manager import PortfolioManager

logger = logging.getLogger(__name__)

@dataclass
class TradingSignal:
    mint_address: str
    action: str  # 'buy' or 'sell'
    confidence: float
    strength: float
    price_target: Optional[float]
    stop_loss: Optional[float]
    holding_period: str
    reasoning: str
    sentiment_score: float
    technical_score: float
    volume_score: float

class TradingEngine:
    def __init__(self, db: Database, websocket_manager: WebSocketManager, sentiment_analyzer: SentimentAnalyzer):
        self.db = db
        self.websocket_manager = websocket_manager
        self.sentiment_analyzer = sentiment_analyzer
        self.risk_manager = RiskManager(db)
        self.portfolio_manager = PortfolioManager(db, websocket_manager)
        self.jupiter_client = JupiterClient()
        
        # Trading state
        self.is_running = False
        self.active_orders = {}
        self.position_monitors = {}
        
        # Solana client
        self.solana_client = AsyncClient(config.SOLANA_RPC_URL)
        
        # Performance metrics
        self.daily_trades = 0
        self.daily_pnl = 0.0
        self.last_reset_date = datetime.utcnow().date()
        
        logger.info("Trading engine initialized")
    
    async def start_trading(self):
        """Start the trading engine"""
        self.is_running = True
        logger.info("Trading engine started")
        
        # Start main trading loop
        asyncio.create_task(self._trading_loop())
        
        # Start position monitoring
        asyncio.create_task(self._monitor_positions())
        
        # Start portfolio updates
        asyncio.create_task(self._update_portfolio_metrics())
        
        # Send startup notification
        await self.websocket_manager.broadcast_alert({
            "type": "info",
            "message": "Trading engine started",
            "timestamp": datetime.utcnow().isoformat()
        })
    
    async def stop(self):
        """Stop the trading engine"""
        self.is_running = False
        await self.solana_client.close()
        logger.info("Trading engine stopped")
    
    async def _trading_loop(self):
        """Main trading loop"""
        while self.is_running:
            try:
                # Reset daily counters if new day
                await self._check_daily_reset()
                
                # Check if we can make more trades today
                if self.daily_trades >= config.MAX_DAILY_TRADES:
                    logger.info(f"Daily trade limit reached: {self.daily_trades}")
                    await asyncio.sleep(3600)  # Wait 1 hour before checking again
                    continue
                
                # Get latest trading signals
                signals = await self._get_trading_signals()
                
                # Process each signal
                for signal in signals:
                    if not self.is_running:
                        break
                    
                    await self._process_trading_signal(signal)
                
                # Wait before next iteration
                await asyncio.sleep(config.PRICE_UPDATE_INTERVAL)
                
            except Exception as e:
                logger.error(f"Error in trading loop: {e}")
                await asyncio.sleep(30)  # Wait 30 seconds before retrying
    
    async def _get_trading_signals(self) -> List[TradingSignal]:
        """Get AI-generated trading signals"""
        try:
            # Get recent sentiment data
            sentiment_data = await self.db.execute_query(
                """
                SELECT mint_address, AVG(sentiment_score) as avg_sentiment, 
                       AVG(confidence) as avg_confidence, COUNT(*) as mention_count
                FROM sentiment_data 
                WHERE timestamp >= datetime('now', '-1 hour')
                GROUP BY mint_address
                HAVING avg_confidence >= ? AND mention_count >= 3
                ORDER BY avg_sentiment DESC, mention_count DESC
                LIMIT 20
                """,
                (config.MIN_CONFIDENCE_SCORE,)
            )
            
            signals = []
            
            for data in sentiment_data:
                # Get token info
                token = await self.db.get_token_by_mint(data['mint_address'])
                if not token:
                    continue
                
                # Get latest market data
                market_data = await self.db.execute_query(
                    """
                    SELECT * FROM market_data 
                    WHERE mint_address = ? 
                    ORDER BY timestamp DESC LIMIT 1
                    """,
                    (data['mint_address'],)
                )
                
                if not market_data:
                    continue
                
                market = market_data[0]
                
                # Calculate technical signals
                technical_score = await self._calculate_technical_score(market)
                volume_score = await self._calculate_volume_score(market)
                
                # Generate composite signal
                composite_score = (
                    data['avg_sentiment'] * config.SENTIMENT_WEIGHT +
                    technical_score * config.TECHNICAL_WEIGHT +
                    volume_score * config.VOLUME_WEIGHT
                )
                
                # Only generate signals above minimum threshold
                if composite_score >= config.MIN_SENTIMENT_SCORE:
                    signal = TradingSignal(
                        mint_address=data['mint_address'],
                        action='buy',  # For now, only buy signals
                        confidence=data['avg_confidence'],
                        strength=composite_score,
                        price_target=market['price_usd'] * 1.2,  # 20% target
                        stop_loss=market['price_usd'] * 0.95,    # 5% stop loss
                        holding_period=self._determine_holding_period(data['avg_sentiment'], technical_score),
                        reasoning=f"Strong sentiment ({data['avg_sentiment']:.2f}) with {data['mention_count']} mentions",
                        sentiment_score=data['avg_sentiment'],
                        technical_score=technical_score,
                        volume_score=volume_score
                    )
                    signals.append(signal)
            
            return signals[:5]  # Limit to top 5 signals
            
        except Exception as e:
            logger.error(f"Error generating trading signals: {e}")
            return []
    
    async def _process_trading_signal(self, signal: TradingSignal):
        """Process a trading signal"""
        try:
            # Check if we already have a position in this token
            existing_positions = await self.db.execute_query(
                "SELECT * FROM positions WHERE mint_address = ? AND status = 'open'",
                (signal.mint_address,)
            )
            
            if existing_positions:
                logger.info(f"Already have open position in {signal.mint_address}")
                return
            
            # Check risk management
            if not await self.risk_manager.can_open_position(signal):
                logger.info(f"Risk manager rejected signal for {signal.mint_address}")
                return
            
            # Calculate position size
            position_size = await self.risk_manager.calculate_position_size(signal)
            
            if position_size <= 0:
                logger.info(f"Position size too small for {signal.mint_address}")
                return
            
            # Execute trade
            trade_result = await self._execute_trade(signal, position_size)
            
            if trade_result:
                # Broadcast trade update
                await self.websocket_manager.broadcast_trade_update({
                    "signal": signal.__dict__,
                    "trade": trade_result,
                    "timestamp": datetime.utcnow().isoformat()
                })
                
                # Increment daily trade counter
                self.daily_trades += 1
                
                logger.info(f"Successfully executed trade for {signal.mint_address}")
            
        except Exception as e:
            logger.error(f"Error processing trading signal: {e}")
    
    async def _execute_trade(self, signal: TradingSignal, position_size: float) -> Optional[Dict]:
        """Execute a trade"""
        try:
            start_time = time.time()
            
            # Get token info
            token = await self.db.get_token_by_mint(signal.mint_address)
            if not token:
                logger.error(f"Token not found: {signal.mint_address}")
                return None
            
            # Get wallet for trading
            wallet = await self._get_trading_wallet()
            if not wallet:
                logger.error("No trading wallet available")
                return None
            
            # Execute trade via Jupiter
            trade_result = await self.jupiter_client.execute_swap(
                input_mint="So11111111111111111111111111111111111111112",  # SOL
                output_mint=signal.mint_address,
                amount=position_size,
                wallet_address=wallet['address']
            )
            
            if not trade_result:
                logger.error(f"Failed to execute trade for {signal.mint_address}")
                return None
            
            execution_time = int((time.time() - start_time) * 1000)
            
            # Record trade in database
            trade_data = {
                'wallet_id': wallet['id'],
                'token_id': token['id'],
                'mint_address': signal.mint_address,
                'trade_type': 'buy',
                'amount': trade_result.get('output_amount', 0),
                'price': trade_result.get('price', 0),
                'value_usd': position_size,
                'fee_sol': trade_result.get('fee', 0),
                'signature': trade_result.get('signature', ''),
                'confidence_score': signal.confidence,
                'sentiment_score': signal.sentiment_score,
                'ai_signal_strength': signal.strength,
                'execution_time_ms': execution_time,
                'slippage_percentage': trade_result.get('slippage', 0)
            }
            
            trade_id = await self.db.insert_trade(trade_data)
            
            # Create position record
            position_data = {
                'wallet_id': wallet['id'],
                'token_id': token['id'],
                'mint_address': signal.mint_address,
                'amount': trade_result.get('output_amount', 0),
                'entry_price': trade_result.get('price', 0),
                'current_price': trade_result.get('price', 0),
                'stop_loss': signal.stop_loss,
                'take_profit': signal.price_target,
                'confidence_score': signal.confidence,
                'holding_period_target': signal.holding_period
            }
            
            await self.db.execute_insert(
                """
                INSERT INTO positions 
                (wallet_id, token_id, mint_address, amount, entry_price, current_price, 
                 stop_loss, take_profit, confidence_score, holding_period_target)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    position_data['wallet_id'],
                    position_data['token_id'],
                    position_data['mint_address'],
                    position_data['amount'],
                    position_data['entry_price'],
                    position_data['current_price'],
                    position_data['stop_loss'],
                    position_data['take_profit'],
                    position_data['confidence_score'],
                    position_data['holding_period_target']
                )
            )
            
            return {**trade_data, 'trade_id': trade_id}
            
        except Exception as e:
            logger.error(f"Error executing trade: {e}")
            return None
    
    async def _monitor_positions(self):
        """Monitor open positions for stop loss and take profit"""
        while self.is_running:
            try:
                # Get all open positions
                positions = await self.db.get_active_positions()
                
                for position in positions:
                    await self._check_position_exit(position)
                
                await asyncio.sleep(10)  # Check every 10 seconds
                
            except Exception as e:
                logger.error(f"Error monitoring positions: {e}")
                await asyncio.sleep(30)
    
    async def _check_position_exit(self, position: Dict):
        """Check if position should be exited"""
        try:
            # Get current price
            current_price = await self.jupiter_client.get_token_price(position['mint_address'])
            
            if not current_price:
                return
            
            # Update current price in database
            await self.db.execute_update(
                "UPDATE positions SET current_price = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?",
                (current_price, position['id'])
            )
            
            should_exit = False
            exit_reason = ""
            
            # Check stop loss
            if position['stop_loss'] and current_price <= position['stop_loss']:
                should_exit = True
                exit_reason = "stop_loss"
            
            # Check take profit
            elif position['take_profit'] and current_price >= position['take_profit']:
                should_exit = True
                exit_reason = "take_profit"
            
            # Check holding period
            elif self._should_exit_by_time(position):
                should_exit = True
                exit_reason = "time_based"
            
            if should_exit:
                await self._exit_position(position, exit_reason, current_price)
            
        except Exception as e:
            logger.error(f"Error checking position exit: {e}")
    
    async def _exit_position(self, position: Dict, reason: str, exit_price: float):
        """Exit a position"""
        try:
            logger.info(f"Exiting position {position['id']} due to {reason}")
            
            # Get wallet info
            wallet = await self.db.execute_query(
                "SELECT * FROM wallets WHERE id = ?",
                (position['wallet_id'],)
            )
            
            if not wallet:
                logger.error(f"Wallet not found for position {position['id']}")
                return
            
            wallet = wallet[0]
            
            # Execute sell trade via Jupiter
            trade_result = await self.jupiter_client.execute_swap(
                input_mint=position['mint_address'],
                output_mint="So11111111111111111111111111111111111111112",  # SOL
                amount=position['amount'],
                wallet_address=wallet['address']
            )
            
            if trade_result:
                # Calculate P&L
                entry_value = position['amount'] * position['entry_price']
                exit_value = float(trade_result.get('output_amount', 0)) * exit_price
                pnl_usd = exit_value - entry_value
                pnl_percentage = (pnl_usd / entry_value) * 100 if entry_value > 0 else 0
                
                # Update position as closed
                await self.db.execute_update(
                    """
                    UPDATE positions 
                    SET status = 'closed', exit_date = CURRENT_TIMESTAMP, 
                        current_price = ?, pnl_usd = ?, pnl_percentage = ?, updated_at = CURRENT_TIMESTAMP
                    WHERE id = ?
                    """,
                    (exit_price, pnl_usd, pnl_percentage, position['id'])
                )
                
                # Record exit trade
                trade_data = {
                    'wallet_id': position['wallet_id'],
                    'token_id': position['token_id'],
                    'mint_address': position['mint_address'],
                    'trade_type': 'sell',
                    'amount': position['amount'],
                    'price': exit_price,
                    'value_usd': exit_value,
                    'fee_sol': trade_result.get('fee', 0),
                    'signature': trade_result.get('signature', ''),
                    'confidence_score': 0,
                    'sentiment_score': 0,
                    'ai_signal_strength': 0,
                    'execution_time_ms': 0,
                    'slippage_percentage': trade_result.get('slippage', 0)
                }
                
                await self.db.insert_trade(trade_data)
                
                # Update daily P&L
                self.daily_pnl += pnl_usd
                
                # Broadcast position update
                await self.websocket_manager.broadcast_trade_update({
                    "type": "position_closed",
                    "position_id": position['id'],
                    "reason": reason,
                    "pnl_usd": pnl_usd,
                    "pnl_percentage": pnl_percentage,
                    "timestamp": datetime.utcnow().isoformat()
                })
                
                logger.info(f"Position {position['id']} closed. P&L: ${pnl_usd:.2f} ({pnl_percentage:.2f}%)")
            
        except Exception as e:
            logger.error(f"Error exiting position: {e}")
    
    async def _calculate_technical_score(self, market_data: Dict) -> float:
        """Calculate technical analysis score"""
        try:
            score = 0.5  # Base score
            
            # Price momentum (24h change)
            if market_data.get('price_change_24h', 0) > 0:
                score += 0.2
            
            # Volume analysis
            if market_data.get('volume_24h', 0) > 10000:  # High volume
                score += 0.2
            
            # Liquidity check
            if market_data.get('liquidity_usd', 0) > 50000:  # Good liquidity
                score += 0.1
            
            return min(score, 1.0)
            
        except Exception:
            return 0.5
    
    async def _calculate_volume_score(self, market_data: Dict) -> float:
        """Calculate volume-based score"""
        try:
            volume_24h = market_data.get('volume_24h', 0)
            
            if volume_24h > 100000:
                return 1.0
            elif volume_24h > 50000:
                return 0.8
            elif volume_24h > 10000:
                return 0.6
            elif volume_24h > 1000:
                return 0.4
            else:
                return 0.2
            
        except Exception:
            return 0.2
    
    def _determine_holding_period(self, sentiment_score: float, technical_score: float) -> str:
        """Determine optimal holding period based on scores"""
        composite = (sentiment_score + technical_score) / 2
        
        if composite >= 0.9:
            return "days"
        elif composite >= 0.7:
            return "hours"
        else:
            return "minutes"
    
    def _should_exit_by_time(self, position: Dict) -> bool:
        """Check if position should be exited based on time"""
        try:
            entry_time = datetime.fromisoformat(position['entry_date'].replace('Z', '+00:00'))
            current_time = datetime.utcnow().replace(tzinfo=entry_time.tzinfo)
            
            holding_period = position.get('holding_period_target', 'hours')
            
            if holding_period == "minutes":
                return (current_time - entry_time) > timedelta(minutes=30)
            elif holding_period == "hours":
                return (current_time - entry_time) > timedelta(hours=6)
            elif holding_period == "days":
                return (current_time - entry_time) > timedelta(days=2)
            
            return False
            
        except Exception:
            return False
    
    async def _get_trading_wallet(self) -> Optional[Dict]:
        """Get available trading wallet"""
        wallets = await self.db.execute_query(
            "SELECT * FROM wallets WHERE is_active = 1 ORDER BY balance_sol DESC LIMIT 1"
        )
        return wallets[0] if wallets else None
    
    async def _check_daily_reset(self):
        """Reset daily counters if new day"""
        current_date = datetime.utcnow().date()
        if current_date > self.last_reset_date:
            self.daily_trades = 0
            self.daily_pnl = 0.0
            self.last_reset_date = current_date
            logger.info("Daily counters reset")
    
    async def _update_portfolio_metrics(self):
        """Update portfolio metrics periodically"""
        while self.is_running:
            try:
                await self.portfolio_manager.update_metrics()
                await asyncio.sleep(config.PORTFOLIO_UPDATE_INTERVAL)
            except Exception as e:
                logger.error(f"Error updating portfolio metrics: {e}")
                await asyncio.sleep(60)