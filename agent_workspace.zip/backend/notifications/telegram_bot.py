import asyncio
import aiohttp
import logging
from typing import Dict, Any, Optional
from datetime import datetime

from utils.config import config

logger = logging.getLogger(__name__)

class TelegramNotifier:
    """Telegram notifications for trading events"""
    
    def __init__(self):
        self.bot_token = config.TELEGRAM_BOT_TOKEN
        self.chat_id = config.TELEGRAM_CHAT_ID
        self.session = None
        self.enabled = bool(self.bot_token and self.chat_id)
        
        if self.enabled:
            logger.info("Telegram notifier initialized and enabled")
        else:
            logger.info("Telegram notifier disabled (no credentials provided)")
    
    async def _get_session(self):
        """Get or create aiohttp session"""
        if not self.session:
            self.session = aiohttp.ClientSession()
        return self.session
    
    async def close(self):
        """Close aiohttp session"""
        if self.session:
            await self.session.close()
    
    async def send_message(self, message: str, parse_mode: str = "HTML") -> bool:
        """Send message to Telegram"""
        if not self.enabled:
            logger.debug(f"Telegram disabled, would send: {message[:100]}...")
            return True
        
        try:
            session = await self._get_session()
            
            url = f"https://api.telegram.org/bot{self.bot_token}/sendMessage"
            
            payload = {
                "chat_id": self.chat_id,
                "text": message[:4096],  # Telegram message limit
                "parse_mode": parse_mode,
                "disable_web_page_preview": True
            }
            
            async with session.post(url, json=payload) as response:
                if response.status == 200:
                    logger.debug("Telegram message sent successfully")
                    return True
                else:
                    error_text = await response.text()
                    logger.error(f"Failed to send Telegram message: {response.status} - {error_text}")
                    return False
                    
        except Exception as e:
            logger.error(f"Error sending Telegram message: {e}")
            return False
    
    async def notify_trade_executed(self, trade_data: Dict[str, Any]):
        """Notify about executed trade"""
        try:
            trade_type = trade_data.get('trade_type', 'unknown').upper()
            symbol = trade_data.get('symbol', 'UNKNOWN')
            amount = trade_data.get('amount', 0)
            price = trade_data.get('price', 0)
            value_usd = trade_data.get('value_usd', 0)
            confidence = trade_data.get('confidence_score', 0)
            sentiment = trade_data.get('sentiment_score', 0)
            
            emoji = "🟢" if trade_type == "BUY" else "🔴"
            
            message = f"""
{emoji} <b>TRADE EXECUTED</b> {emoji}

<b>Action:</b> {trade_type}
<b>Token:</b> {symbol}
<b>Amount:</b> {amount:,.6f}
<b>Price:</b> ${price:.8f}
<b>Value:</b> ${value_usd:.2f}
<b>Confidence:</b> {confidence:.1%}
<b>Sentiment:</b> {sentiment:.1%}

<b>Time:</b> {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')} UTC
            """.strip()
            
            await self.send_message(message)
            
        except Exception as e:
            logger.error(f"Error sending trade notification: {e}")
    
    async def notify_position_closed(self, position_data: Dict[str, Any]):
        """Notify about closed position"""
        try:
            symbol = position_data.get('symbol', 'UNKNOWN')
            pnl_usd = position_data.get('pnl_usd', 0)
            pnl_percentage = position_data.get('pnl_percentage', 0)
            holding_period = position_data.get('holding_period', 'unknown')
            reason = position_data.get('exit_reason', 'unknown')
            
            emoji = "🟢💰" if pnl_usd > 0 else "🔴💸"
            result = "PROFIT" if pnl_usd > 0 else "LOSS"
            
            message = f"""
{emoji} <b>POSITION CLOSED - {result}</b> {emoji}

<b>Token:</b> {symbol}
<b>P&L:</b> ${pnl_usd:.2f} ({pnl_percentage:+.2f}%)
<b>Exit Reason:</b> {reason.replace('_', ' ').title()}
<b>Holding Period:</b> {holding_period}

<b>Time:</b> {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')} UTC
            """.strip()
            
            await self.send_message(message)
            
        except Exception as e:
            logger.error(f"Error sending position notification: {e}")
    
    async def notify_new_token_discovered(self, token_data: Dict[str, Any]):
        """Notify about new token discovery"""
        try:
            symbol = token_data.get('symbol', 'UNKNOWN')
            name = token_data.get('name', 'Unknown Token')
            mint_address = token_data.get('mint_address', '')
            initial_price = token_data.get('price_usd', 0)
            liquidity = token_data.get('liquidity_usd', 0)
            
            message = f"""
🔍 <b>NEW TOKEN DISCOVERED</b> 🔍

<b>Name:</b> {name}
<b>Symbol:</b> {symbol}
<b>Price:</b> ${initial_price:.8f}
<b>Liquidity:</b> ${liquidity:,.0f}
<b>Address:</b> <code>{mint_address[:8]}...{mint_address[-8:]}</code>

<b>Time:</b> {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')} UTC
            """.strip()
            
            await self.send_message(message)
            
        except Exception as e:
            logger.error(f"Error sending new token notification: {e}")
    
    async def notify_high_sentiment_detected(self, sentiment_data: Dict[str, Any]):
        """Notify about high sentiment detected"""
        try:
            symbol = sentiment_data.get('symbol', 'UNKNOWN')
            sentiment_score = sentiment_data.get('sentiment_score', 0)
            platform = sentiment_data.get('platform', 'unknown')
            mentions = sentiment_data.get('mentions_count', 0)
            
            message = f"""
📈 <b>HIGH SENTIMENT DETECTED</b> 📈

<b>Token:</b> {symbol}
<b>Sentiment Score:</b> {sentiment_score:.1%}
<b>Platform:</b> {platform.title()}
<b>Mentions:</b> {mentions}

<b>Time:</b> {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')} UTC
            """.strip()
            
            await self.send_message(message)
            
        except Exception as e:
            logger.error(f"Error sending sentiment notification: {e}")
    
    async def notify_portfolio_milestone(self, milestone_data: Dict[str, Any]):
        """Notify about portfolio milestones"""
        try:
            milestone_type = milestone_data.get('type', 'unknown')
            current_value = milestone_data.get('current_value', 0)
            target_value = milestone_data.get('target_value', 0)
            growth_percentage = milestone_data.get('growth_percentage', 0)
            
            emoji_map = {
                'profit_target': '🏆',
                'loss_limit': '⚠️',
                'daily_goal': '📈',
                'weekly_goal': '🎆',
                'monthly_goal': '🎉'
            }
            
            emoji = emoji_map.get(milestone_type, '📄')
            
            message = f"""
{emoji} <b>PORTFOLIO MILESTONE</b> {emoji}

<b>Type:</b> {milestone_type.replace('_', ' ').title()}
<b>Current Value:</b> ${current_value:.2f}
<b>Target:</b> ${target_value:.2f}
<b>Growth:</b> {growth_percentage:+.2f}%

<b>Time:</b> {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')} UTC
            """.strip()
            
            await self.send_message(message)
            
        except Exception as e:
            logger.error(f"Error sending milestone notification: {e}")
    
    async def notify_system_alert(self, alert_data: Dict[str, Any]):
        """Notify about system alerts"""
        try:
            alert_type = alert_data.get('type', 'info')
            message_text = alert_data.get('message', 'System alert')
            details = alert_data.get('details', '')
            
            emoji_map = {
                'error': '🚨',
                'warning': '⚠️',
                'info': 'ℹ️',
                'success': '✅'
            }
            
            emoji = emoji_map.get(alert_type, '📄')
            
            message = f"""
{emoji} <b>SYSTEM ALERT</b> {emoji}

<b>Type:</b> {alert_type.upper()}
<b>Message:</b> {message_text}
            """
            
            if details:
                message += f"\n<b>Details:</b> {details}"
            
            message += f"\n\n<b>Time:</b> {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')} UTC"
            
            await self.send_message(message.strip())
            
        except Exception as e:
            logger.error(f"Error sending system alert: {e}")
    
    async def notify_daily_summary(self, summary_data: Dict[str, Any]):
        """Send daily trading summary"""
        try:
            total_trades = summary_data.get('total_trades', 0)
            total_pnl = summary_data.get('total_pnl', 0)
            win_rate = summary_data.get('win_rate', 0)
            best_trade = summary_data.get('best_trade', 0)
            worst_trade = summary_data.get('worst_trade', 0)
            portfolio_value = summary_data.get('portfolio_value', 0)
            
            emoji = "📈" if total_pnl > 0 else "📉" if total_pnl < 0 else "📋"
            
            message = f"""
{emoji} <b>DAILY TRADING SUMMARY</b> {emoji}

<b>Total Trades:</b> {total_trades}
<b>Total P&L:</b> ${total_pnl:.2f}
<b>Win Rate:</b> {win_rate:.1f}%
<b>Best Trade:</b> ${best_trade:.2f}
<b>Worst Trade:</b> ${worst_trade:.2f}
<b>Portfolio Value:</b> ${portfolio_value:.2f}

<b>Date:</b> {datetime.utcnow().strftime('%Y-%m-%d')}
            """.strip()
            
            await self.send_message(message)
            
        except Exception as e:
            logger.error(f"Error sending daily summary: {e}")
    
    async def test_connection(self) -> bool:
        """Test Telegram bot connection"""
        if not self.enabled:
            logger.info("Telegram bot is disabled")
            return False
        
        try:
            test_message = f"🤖 Solana Trading Bot Test Message\n\nTime: {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')} UTC"
            success = await self.send_message(test_message)
            
            if success:
                logger.info("Telegram connection test successful")
            else:
                logger.error("Telegram connection test failed")
            
            return success
            
        except Exception as e:
            logger.error(f"Telegram connection test error: {e}")
            return False