import React, { useState, useEffect } from 'react';
import './Dashboard.css';

const Dashboard = () => {
  const [portfolioValue, setPortfolioValue] = useState(1.00);
  const [totalPnL, setTotalPnL] = useState(0.00);
  const [pnlPercentage, setPnlPercentage] = useState(0.00);
  
  // Mock data for demonstration
  const [recentTrades] = useState([
    { id: 1, token: 'BONK', type: 'BUY', amount: '1,000,000', price: '$0.000012', time: '2 min ago', pnl: '+$0.50' },
    { id: 2, token: 'WIF', type: 'SELL', amount: '500', price: '$2.45', time: '5 min ago', pnl: '+$1.20' },
    { id: 3, token: 'PEPE', type: 'BUY', amount: '50,000', price: '$0.000008', time: '12 min ago', pnl: '-$0.15' }
  ]);
  
  const [monitoredTokens] = useState([
    { symbol: 'BONK', price: '$0.000012', change: '+15.2%', volume: '$2.1M', sentiment: 'Bullish' },
    { symbol: 'WIF', price: '$2.45', change: '-3.8%', volume: '$5.7M', sentiment: 'Neutral' },
    { symbol: 'PEPE', price: '$0.000008', change: '+8.1%', volume: '$1.9M', sentiment: 'Bullish' },
    { symbol: 'MYRO', price: '$0.15', change: '+22.5%', volume: '$890K', sentiment: 'Very Bullish' }
  ]);

  useEffect(() => {
    // Simulate real-time updates
    const interval = setInterval(() => {
      setPortfolioValue(prev => prev + (Math.random() - 0.5) * 0.1);
      setTotalPnL(prev => prev + (Math.random() - 0.5) * 0.05);
      setPnlPercentage(prev => prev + (Math.random() - 0.5) * 0.1);
    }, 3000);
    
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="dashboard">
      {/* Header */}
      <header className="dashboard-header">
        <h1 className="dashboard-title">
          <span className="neon-text">SOLANA</span> MEME TRADER
        </h1>
        <div className="status-indicator">
          <div className="status-dot active"></div>
          <span>Bot Active</span>
        </div>
      </header>

      {/* Portfolio Overview */}
      <section className="portfolio-overview">
        <div className="portfolio-card">
          <h3>Portfolio Value</h3>
          <div className="portfolio-value">${portfolioValue.toFixed(2)}</div>
        </div>
        <div className="portfolio-card">
          <h3>Total P&L</h3>
          <div className={`pnl-value ${totalPnL >= 0 ? 'positive' : 'negative'}`}>
            {totalPnL >= 0 ? '+' : ''}${totalPnL.toFixed(2)}
          </div>
        </div>
        <div className="portfolio-card">
          <h3>P&L %</h3>
          <div className={`pnl-percentage ${pnlPercentage >= 0 ? 'positive' : 'negative'}`}>
            {pnlPercentage >= 0 ? '+' : ''}{pnlPercentage.toFixed(2)}%
          </div>
        </div>
        <div className="portfolio-card">
          <h3>Active Positions</h3>
          <div className="active-positions">3</div>
        </div>
      </section>

      {/* Main Content Grid */}
      <div className="main-content">
        {/* Chart Area */}
        <section className="chart-section">
          <div className="section-header">
            <h2>Portfolio Performance</h2>
            <div className="chart-controls">
              <button className="chart-btn active">1H</button>
              <button className="chart-btn">4H</button>
              <button className="chart-btn">1D</button>
              <button className="chart-btn">1W</button>
            </div>
          </div>
          <div className="chart-placeholder">
            <div className="chart-loading">
              <div className="loading-pulse"></div>
              <p>Real-time chart coming soon...</p>
            </div>
          </div>
        </section>

        {/* Monitored Tokens */}
        <section className="monitored-tokens">
          <div className="section-header">
            <h2>Monitored Tokens</h2>
            <span className="refresh-indicator">🔄</span>
          </div>
          <div className="tokens-list">
            {monitoredTokens.map((token, index) => (
              <div key={index} className="token-item">
                <div className="token-info">
                  <span className="token-symbol">{token.symbol}</span>
                  <span className="token-price">{token.price}</span>
                </div>
                <div className="token-metrics">
                  <span className={`token-change ${token.change.includes('+') ? 'positive' : 'negative'}`}>
                    {token.change}
                  </span>
                  <span className="token-volume">{token.volume}</span>
                </div>
                <div className={`sentiment-badge ${token.sentiment.toLowerCase().replace(' ', '-')}`}>
                  {token.sentiment}
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>

      {/* Recent Trades */}
      <section className="recent-trades">
        <div className="section-header">
          <h2>Recent Trades</h2>
          <button className="view-all-btn">View All</button>
        </div>
        <div className="trades-table">
          <div className="table-header">
            <span>Token</span>
            <span>Type</span>
            <span>Amount</span>
            <span>Price</span>
            <span>Time</span>
            <span>P&L</span>
          </div>
          {recentTrades.map(trade => (
            <div key={trade.id} className="trade-row">
              <span className="trade-token">{trade.token}</span>
              <span className={`trade-type ${trade.type.toLowerCase()}`}>{trade.type}</span>
              <span className="trade-amount">{trade.amount}</span>
              <span className="trade-price">{trade.price}</span>
              <span className="trade-time">{trade.time}</span>
              <span className={`trade-pnl ${trade.pnl.includes('+') ? 'positive' : 'negative'}`}>
                {trade.pnl}
              </span>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};

export default Dashboard;